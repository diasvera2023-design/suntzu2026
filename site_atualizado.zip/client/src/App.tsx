import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import Home from "@/pages/home";
import DisciplinaOverview from "@/pages/disciplina-overview";
import TopicDetail from "@/pages/topic-detail";
import NotFound from "@/pages/not-found";
import Bibliografia from "@/pages/bibliografia";
import ArtigoSandro from "@/pages/artigo-sandro";
import Metodologia from "@/pages/metodologia";
import ManualAluno from "@/pages/manual-aluno";
import { penalIII } from "@/lib/penal-data";

function PenalIIITopic({ params }: { params: { topicId: string } }) {
  const topic = penalIII.topics.find((t) => t.id === params.topicId);
  if (!topic) return <NotFound />;
  return <TopicDetail topic={topic} disciplinaNome={penalIII.nome} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/penal-iii">
        <DisciplinaOverview disciplina={penalIII} />
      </Route>
      <Route path="/penal-iii/:topicId">
        {(params) => <PenalIIITopic params={params} />}
      </Route>
      <Route path="/bibliografia" component={Bibliografia} />
      <Route path="/artigo-sandro" component={ArtigoSandro} />
      <Route path="/metodologia" component={Metodologia} />
      <Route path="/manual-aluno" component={ManualAluno} />
      <Route component={NotFound} />
    </Switch>
  );
}

const sidebarStyle = {
  "--sidebar-width": "18rem",
  "--sidebar-width-icon": "3rem",
};

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <SidebarProvider style={sidebarStyle as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar />
              <div className="flex flex-col flex-1 min-w-0">
                <header className="flex items-center justify-between gap-2 p-2 border-b sticky top-0 z-50 bg-background">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <ThemeToggle />
                </header>
                <main className="flex-1 overflow-auto">
                  <Router />
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
