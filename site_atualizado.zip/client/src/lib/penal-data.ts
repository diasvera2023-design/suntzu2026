export interface SubTopic {
  id: string;
  title: string;
  artigos: string;
  fundamentoLegal: string;
  explicacao: string;
  elementosDoTipo?: string[];
  jurisprudencia?: string[];
  observacoes?: string[];
  ppiDisponivel?: string;
}

export interface Topic {
  id: string;
  title: string;
  icon: string;
  descricao: string;
  subtopics: SubTopic[];
}

export interface Disciplina {
  id: string;
  nome: string;
  creditos: number;
  cargaHoraria: number;
  ementa: string;
  topics: Topic[];
  bibliografiaBasica: string[];
  bibliografiaComplementar: string[];
}

export const penalIII: Disciplina = {
  id: "penal-iii",
  nome: "Direito Penal III",
  creditos: 3,
  cargaHoraria: 60,
  ementa:
    "Normas incriminadoras em especie: dos crimes contra a pessoa. Crimes contra a vida. Da lesao corporal. Dos crimes contra a dignidade sexual, Periclitacao da vida e da saude. Dos crimes contra a honra, contra a liberdade pessoal, contra o patrimonio, contra a propriedade imaterial, contra a organizacao do trabalho, contra o sentimento religioso e o respeito aos mortos.",
  bibliografiaBasica: [
    "MIRABETE, J. F.; FABBRINI, R. N. Manual de Direito Penal: Parte Especial - Arts. 121 a 234 do CP. 37. ed. Cotia: Foco, 2024.",
    "GENTIL, Fernando. Direito penal: parte especial. 1. ed. Sao Paulo: Rideel, 2022.",
    "RODRIGUES, Cristiano. Manual de direito penal. 4. ed. Indaiatuba, SP: Foco, 2024.",
  ],
  bibliografiaComplementar: [
    "FAVORETTO, Affonso Celso. Direito penal: parte geral e parte especial. 2. ed. Sao Paulo: Rideel, 2015.",
    "PEREIRA, Gisele Mendes. Direito penal II. 2. ed. Porto Alegre: Educs, 2018.",
    "JESUS, Damasio de. Direito penal: crimes contra a propriedade imaterial. Sao Paulo: Atlas, 2015, v. 3.",
    "GONCALVES, Victor Eduardo Rios. Direito penal: parte especial. (Colecao esquematizado). Sao Paulo: Saraiva Jur, 2024.",
    "ELTZ, Magnum K. de Figueiredo; REIS, Anna C. Gomes dos; BARBOZA, Mayte R. T. Meleto et al. Direito Penal III. Porto Alegre: SAGAH, 2019.",
  ],
  topics: [
    {
      id: "crimes-contra-vida",
      title: "Crimes contra a Vida",
      icon: "Shield",
      descricao:
        "Os crimes contra a vida estao previstos nos arts. 121 a 128 do Codigo Penal. Constituem o nucleo mais grave dos crimes contra a pessoa, pois atingem o bem juridico mais relevante tutelado pelo ordenamento: a vida humana. Sao crimes de competencia do Tribunal do Juri, conforme art. 5, XXXVIII, da CF/88.",
      subtopics: [
        {
          id: "homicidio",
          title: "Homicidio (Art. 121, CP)",
          artigos: "Art. 121, caput, e paragrafos 1 a 7, do Decreto-Lei n. 2.848/1940 (Codigo Penal)",
          fundamentoLegal:
            "Art. 121, caput, CP: 'Matar alguem: Pena - reclusao, de seis a vinte anos.' O homicidio e o tipo penal mais grave do Codigo Penal brasileiro, tutelando o bem juridico vida humana extrauterina.",
          explicacao:
            "O homicidio consiste na conduta de matar alguem, ou seja, eliminar a vida humana extrauterina. E crime comum (pode ser praticado por qualquer pessoa), material (exige resultado naturalistico - a morte), de dano (exige efetiva lesao ao bem juridico) e instantaneo (consuma-se no momento da morte). O sujeito passivo e qualquer pessoa viva, desde o inicio do parto (quando cessa a protecao do crime de aborto) ate a morte encefalica (Lei n. 9.434/97, art. 3). A competencia para julgamento e do Tribunal do Juri (art. 5, XXXVIII, 'd', CF/88), conforme Sumula 721 do STF.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa viva (ser humano nascido)",
            "Conduta: matar (nucleo do tipo) - admite qualquer meio de execucao (crime de forma livre)",
            "Elemento subjetivo: dolo (animus necandi - intencao de matar)",
            "Consumacao: com a morte da vitima (comprovada por exame cadaverico - art. 162, CPP)",
            "Tentativa: admissivel (crime plurissubsistente)",
          ],
          jurisprudencia: [
            "Sumula 721, STF: 'A competencia constitucional do Tribunal do Juri prevalece sobre o foro por prerrogativa de funcao estabelecido exclusivamente pela constituicao estadual.'",
            "STF, HC 73.662/MG: Reconhecimento do homicidio privilegiado em caso de violenta emocao provocada por ato injusto da vitima.",
            "STJ, REsp 1.916.025/SP (2021): Homicidio qualificado pelo feminicidio (art. 121, par. 2-A, CP) - natureza objetiva da qualificadora, podendo ser combinada com qualificadoras subjetivas.",
          ],
          observacoes: [
            "Homicidio simples (caput): pena de 6 a 20 anos de reclusao",
            "Homicidio privilegiado (par. 1): reducao de 1/6 a 1/3 da pena - impelido por motivo de relevante valor social ou moral, ou sob dominio de violenta emocao, logo em seguida a injusta provocacao da vitima",
            "Homicidio qualificado (par. 2): pena de 12 a 30 anos de reclusao - mediante paga ou promessa de recompensa, motivo torpe, motivo futil, meio insidioso ou cruel, etc.",
            "Feminicidio (par. 2-A, incluido pela Lei n. 13.104/2015): homicidio praticado contra a mulher por razoes da condicao de sexo feminino, envolvendo violencia domestica e familiar ou menosprezo ou discriminacao a condicao de mulher",
            "Homicidio culposo (par. 3): pena de 1 a 3 anos de detencao",
            "Aumento de pena (par. 4): pena aumentada de 1/3 se o crime e praticado contra menor de 14 ou maior de 60 anos",
          ],
        },
        {
          id: "homicidio-qualificado",
          title: "Homicidio Qualificado (Art. 121, par. 2, CP)",
          artigos: "Art. 121, par. 2, incisos I a IX, do Decreto-Lei n. 2.848/1940 (Codigo Penal), com alteracoes das Leis n. 13.104/2015, 13.142/2015, 13.964/2019 e 14.344/2022",
          fundamentoLegal:
            "Art. 121, par. 2, CP: 'Se o homicidio e cometido: I - mediante paga ou promessa de recompensa, ou por outro motivo torpe; II - por motivo futil; III - com emprego de veneno, fogo, explosivo, asfixia, tortura ou outro meio insidioso ou cruel, ou de que possa resultar perigo comum; IV - a traicao, de emboscada, ou mediante dissimulacao ou outro recurso que dificulte ou torne impossivel a defesa do ofendido; V - para assegurar a execucao, a ocultacao, a impunidade ou vantagem de outro crime: Pena - reclusao, de doze a trinta anos.'",
          explicacao:
            "O homicidio qualificado (art. 121, par. 2, CP) e a forma mais grave do crime de homicidio, com pena de reclusao de 12 a 30 anos. As qualificadoras se dividem em: (a) subjetivas (relacionadas a motivacao do agente): motivo torpe (inciso I), motivo futil (inciso II) e conexao com outro crime (inciso V); e (b) objetivas (relacionadas ao modo/meio de execucao): emprego de veneno, fogo, explosivo, asfixia, tortura ou meio cruel (inciso III), e traicao, emboscada, dissimulacao ou recurso que dificulte a defesa (inciso IV). O feminicidio (inciso VI, incluido pela Lei n. 13.104/2015) e qualificadora de natureza objetiva, conforme entendimento do STJ (REsp 1.916.025/SP). O inciso VII (incluido pela Lei n. 13.142/2015) qualifica o homicidio praticado contra autoridades e agentes de seguranca publica e seus familiares. O inciso VIII (incluido pela Lei n. 13.964/2019 - Pacote Anticrime) qualifica o homicidio praticado com emprego de arma de fogo de uso restrito ou proibido. O inciso IX (incluido pela Lei n. 14.344/2022 - Lei Henry Borel) qualifica o homicidio contra menor de 14 anos. O homicidio qualificado e crime hediondo (art. 1, I, da Lei n. 8.072/90). E possivel a coexistencia de qualificadoras subjetivas e objetivas (homicidio duplamente ou triplamente qualificado). Conforme entendimento do STJ e do STF, e admissivel o homicidio qualificado-privilegiado, desde que a qualificadora seja de natureza objetiva.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa viva",
            "Conduta: matar alguem nas circunstancias qualificadoras do par. 2",
            "Elemento subjetivo: dolo (animus necandi), acrescido da motivacao ou do meio/modo qualificador",
            "Pena: reclusao de 12 a 30 anos",
            "Consumacao: com a morte da vitima",
            "Tentativa: admissivel",
            "Crime hediondo (Lei n. 8.072/90, art. 1, I)",
          ],
          jurisprudencia: [
            "STJ, REsp 1.916.025/SP (2021): O feminicidio (art. 121, par. 2, VI, CP) e qualificadora de natureza objetiva, pois se refere ao genero da vitima, podendo coexistir com qualificadoras de natureza subjetiva (motivo torpe, futil).",
            "STF, HC 98.265/MS (Rel. Min. Ayres Britto): 'E admissivel a figura do homicidio qualificado-privilegiado, bastando que a qualificadora seja de natureza objetiva.'",
            "Sumula 610, STF: 'Ha crime de latrocinio, quando o homicidio se consuma, ainda que nao realize o agente a subtracao de bens da vitima.' (distincao entre homicidio qualificado pela conexao e latrocinio)",
            "STJ, HC 462.458/SC (2019): Motivo futil e aquele insignificante, desproporcional, que nao guarda relacao razoavel com a reacao do agente. A ciume, por si so, nao configura motivo futil.",
            "STJ, AgRg no AREsp 1.532.247/ES (2020): A torpeza deve ser aferida pela motivacao do agente, nao bastando a mera existencia de conflito entre autor e vitima.",
            "STF, RE 1.322.781/GO (2023, Repercussao Geral, Tema 1.199): O homicidio qualificado-privilegiado nao e crime hediondo, pois a causa de diminuicao de pena do par. 1 do art. 121 do CP afasta a hediondez.",
          ],
          observacoes: [
            "Qualificadoras subjetivas (motivacao): I - paga, promessa de recompensa ou motivo torpe; II - motivo futil; V - conexao com outro crime (teleologica, consequencial ou ocasional)",
            "Qualificadoras objetivas (meio/modo): III - veneno, fogo, explosivo, asfixia, tortura ou meio cruel; IV - traicao, emboscada, dissimulacao ou recurso que dificulte a defesa",
            "Feminicidio (inciso VI, Lei 13.104/2015): qualificadora objetiva - homicidio contra mulher por razoes da condicao de sexo feminino (violencia domestica/familiar ou menosprezo/discriminacao). Par. 2-A define as razoes da condicao de sexo feminino. Par. 7 preve aumento de 1/3 ate metade se praticado durante gestacao, contra menor de 14 ou maior de 60 anos, ou com deficiencia, ou na presenca de descendente ou ascendente da vitima",
            "Contra autoridade/agente de seguranca (inciso VII, Lei 13.142/2015): qualificadora objetiva - homicidio contra integrantes das forcas de seguranca publica e seus familiares, no exercicio da funcao ou em decorrencia dela",
            "Arma de fogo de uso restrito ou proibido (inciso VIII, Lei 13.964/2019 - Pacote Anticrime): qualificadora objetiva",
            "Contra menor de 14 anos (inciso IX, Lei 14.344/2022 - Lei Henry Borel): qualificadora objetiva",
            "Homicidio qualificado-privilegiado: possivel quando qualificadora e objetiva e privilegio e subjetivo (par. 1 + par. 2, III ou IV). Nao e hediondo (STF, RE 1.322.781/GO)",
            "Hediondez: todo homicidio qualificado e crime hediondo (art. 1, I, Lei 8.072/90), exceto quando reconhecido o privilegio (qualificado-privilegiado)",
            "Concurso de qualificadoras: uma qualifica o crime, as demais podem ser usadas como circunstancias agravantes (art. 61, CP) ou como circunstancias judiciais desfavoraveis (art. 59, CP) na dosimetria da pena",
          ],
        },
        {
          id: "infanticidio",
          title: "Infanticidio (Art. 123, CP)",
          artigos: "Art. 123 do Decreto-Lei n. 2.848/1940 (Codigo Penal)",
          fundamentoLegal:
            "Art. 123, CP: 'Matar, sob a influencia do estado puerperal, o proprio filho, durante o parto ou logo apos: Pena - detencao, de dois a seis anos.'",
          explicacao:
            "O infanticidio e crime proprio, so podendo ser praticado pela mae que se encontra sob influencia do estado puerperal (perturbacoes psicofisiologicas decorrentes do parto). Trata-se de um homicidio privilegiado pela situacao especial da parturiente. A doutrina majoritaria (MIRABETE, BITENCOURT) entende que o estado puerperal e elementar do tipo, comunicando-se aos coautores e participes, conforme art. 30 do CP. Exige-se contemporaneidade entre o estado puerperal e a conduta.",
          elementosDoTipo: [
            "Sujeito ativo: mae sob influencia do estado puerperal (crime proprio)",
            "Sujeito passivo: filho nascente ou recem-nascido",
            "Conduta: matar o proprio filho durante o parto ou logo apos",
            "Elemento normativo do tipo: 'sob a influencia do estado puerperal'",
            "Elemento temporal: durante o parto ou logo apos",
          ],
          jurisprudencia: [
            "TJSP, Ap. 993.07.031299-4: O estado puerperal, como elementar do tipo, comunica-se aos concorrentes do crime, nos termos do art. 30 do Codigo Penal.",
            "STJ, HC 229.713/MG: A expressao 'logo apos' no art. 123 do CP deve ser interpretada de forma flexivel, conforme a duracao do estado puerperal.",
          ],
          observacoes: [
            "Crime proprio: so a mae sob estado puerperal pode ser sujeito ativo",
            "Coautoria e participacao: admitidas - o estado puerperal e elementar do tipo e se comunica (art. 30, CP)",
            "Prova do estado puerperal: exige pericia medica (art. 159, CPP)",
            "Distincao do aborto: o infanticidio protege a vida extrauterina (apos o inicio do parto), enquanto o aborto protege a vida intrauterina",
          ],
        },
        {
          id: "aborto",
          title: "Aborto (Arts. 124 a 128, CP)",
          artigos: "Arts. 124 a 128 do Decreto-Lei n. 2.848/1940 (Codigo Penal)",
          fundamentoLegal:
            "Art. 124, CP: 'Provocar aborto em si mesma ou consentir que outrem lho provoque: Pena - detencao, de um a tres anos.' Art. 125, CP: 'Provocar aborto, sem o consentimento da gestante: Pena - reclusao, de tres a dez anos.' Art. 126, CP: 'Provocar aborto com o consentimento da gestante: Pena - reclusao, de um a quatro anos.'",
          explicacao:
            "O aborto consiste na interrupcao da gravidez com a consequente destruicao do produto da concepcao (MIRABETE). O bem juridico tutelado e a vida intrauterina (vida do nascituro). O Codigo Penal criminaliza o autoaborto (art. 124), o aborto provocado por terceiro sem consentimento (art. 125) e com consentimento (art. 126) da gestante. O art. 128 preve as hipoteses de aborto legal: aborto necessario/terapeutico (inciso I - quando nao ha outro meio de salvar a vida da gestante) e aborto sentimental/humanitario (inciso II - gravidez resultante de estupro). O STF, na ADPF 54 (2012), decidiu pela atipicidade da interrupcao da gestacao de feto anencefalo.",
          elementosDoTipo: [
            "Sujeito ativo: a propria gestante (art. 124) ou terceiro (arts. 125 e 126)",
            "Sujeito passivo: o nascituro (feto ou embriao)",
            "Conduta: provocar a interrupcao da gravidez com destruicao do produto da concepcao",
            "Elemento subjetivo: dolo (nao ha previsao de modalidade culposa)",
            "Consumacao: com a morte do feto/embriao",
          ],
          jurisprudencia: [
            "STF, ADPF 54 (Rel. Min. Marco Aurelio, j. 12/04/2012): 'Nao se tipifica crime de aborto a interrupcao terapeutica induzida da gravidez de feto anencefalo.' Voto vencedor: atipicidade da conduta.",
            "STF, HC 124.306/RJ (Rel. Min. Roberto Barroso, 2016): Voto fundamentado na inconstitucionalidade da criminalizacao do aborto no primeiro trimestre de gestacao (obiter dictum).",
            "STJ, RHC 92.429/MG: Confirmacao da necessidade de consentimento valido da gestante para descaracterizar o art. 125 do CP.",
          ],
          observacoes: [
            "Aborto legal (art. 128, I): aborto necessario/terapeutico - quando nao ha outro meio de salvar a vida da gestante. Nao exige autorizacao judicial.",
            "Aborto legal (art. 128, II): aborto sentimental/humanitario - gravidez resultante de estupro, com consentimento da gestante ou de seu representante legal. Nao exige autorizacao judicial nem boletim de ocorrencia (conforme Norma Tecnica do Ministerio da Saude).",
            "Qualificacao pelo resultado (art. 127): se o aborto e seguido de lesao corporal grave, a pena e aumentada de 1/3; se e seguido de morte, e duplicada.",
            "ADPF 54/STF: feto anencefalo - nao configura aborto",
          ],
        },
        {
          id: "instigacao-suicidio",
          title: "Instigacao, Inducao ou Auxilio ao Suicidio ou Automutilacao (Art. 122, CP)",
          artigos: "Art. 122, caput e paragrafos, do Decreto-Lei n. 2.848/1940 (alterado pela Lei n. 13.968/2019)",
          fundamentoLegal:
            "Art. 122, CP (com redacao dada pela Lei n. 13.968/2019): 'Induzir ou instigar alguem a suicidar-se ou a praticar automutilacao ou prestar-lhe auxilio material para que o faca: Pena - reclusao, de 6 (seis) meses a 2 (dois) anos.'",
          explicacao:
            "Com a alteracao promovida pela Lei n. 13.968/2019, o tipo penal do art. 122 do CP foi significativamente ampliado, passando a abranger tambem a automutilacao. A conduta tipica consiste em induzir (fazer surgir a ideia), instigar (reforcar ideia ja existente) ou auxiliar materialmente (fornecer meios) para que alguem se suicide ou pratique automutilacao. A lei estabeleceu penas mais graves quando o resultado e lesao corporal grave ou gravissima (par. 1: reclusao de 1 a 3 anos) e quando ha morte (par. 2: reclusao de 2 a 6 anos). Se o crime e praticado por motivo egoista, se a vitima e menor ou diminuida a capacidade de resistencia, a pena e duplicada (par. 3 e par. 4).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa (que tenha capacidade de discernimento)",
            "Condutas: induzir, instigar ou prestar auxilio material",
            "Elemento subjetivo: dolo (nao se admite forma culposa)",
          ],
          jurisprudencia: [
            "STJ, HC 422.931/SP: Diferenciacao entre participacao em suicidio e homicidio - analise do dominio do fato e autonomia da vitima.",
            "Lei n. 13.968/2019: Alterou o art. 122 do CP para incluir a automutilacao e a instigacao via internet/redes sociais.",
          ],
        },
      ],
    },
    {
      id: "lesao-corporal",
      title: "Lesao Corporal",
      icon: "HeartPulse",
      descricao:
        "A lesao corporal esta prevista no art. 129 do Codigo Penal e consiste em ofender a integridade corporal ou a saude de outrem. E um dos crimes mais recorrentes na pratica forense, com diversas modalidades e qualificadoras.",
      subtopics: [
        {
          id: "lesao-corporal-art129",
          title: "Lesao Corporal - Modalidades (Art. 129, CP)",
          artigos: "Art. 129, caput, e paragrafos 1 a 13, do Decreto-Lei n. 2.848/1940 (Codigo Penal)",
          fundamentoLegal:
            "Art. 129, caput, CP: 'Ofender a integridade corporal ou a saude de outrem: Pena - detencao, de tres meses a um ano.'",
          explicacao:
            "O crime de lesao corporal tutela a integridade fisica e a saude da pessoa humana. E crime de dano, material e comum. O tipo penal preve diversas modalidades conforme a gravidade da ofensa: lesao leve (caput), grave (par. 1), gravissima (par. 2), seguida de morte (par. 3), privilegiada (par. 4 e 5), culposa (par. 6), com violencia domestica (par. 9, com redacao da Lei n. 11.340/2006 - Lei Maria da Penha) e lesao corporal contra a mulher por razoes da condicao de sexo feminino (par. 13, incluido pela Lei n. 14.188/2021).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa (ser humano vivo)",
            "Conduta: ofender a integridade corporal ou a saude - qualquer alteracao anatomica ou funcional do organismo",
            "Elemento subjetivo: dolo (animus laedendi - intencao de lesionar) ou culpa (par. 6)",
            "Consumacao: com a efetiva ofensa a integridade corporal ou saude",
          ],
          jurisprudencia: [
            "Sumula 542, STJ: 'A acao penal relativa ao crime de lesao corporal resultante de violencia domestica contra a mulher e publica incondicionada.'",
            "STF, ADI 4.424/DF (2012): A acao penal nos crimes de lesao corporal praticados no ambito da violencia domestica e familiar contra a mulher e publica incondicionada.",
            "STJ, AgRg no AREsp 1.654.721/GO (2020): A lesao corporal praticada contra a mulher em contexto de violencia domestica, ainda que de natureza leve, e processada mediante acao penal publica incondicionada.",
          ],
          observacoes: [
            "Lesao leve (caput): detencao de 3 meses a 1 ano. Acao penal publica condicionada a representacao (art. 88, Lei 9.099/95), salvo violencia domestica",
            "Lesao grave (par. 1): reclusao de 1 a 5 anos. Incapacidade para ocupacoes habituais por mais de 30 dias; perigo de vida; debilidade permanente de membro, sentido ou funcao; aceleracao de parto",
            "Lesao gravissima (par. 2): reclusao de 2 a 8 anos. Incapacidade permanente para o trabalho; enfermidade incuravel; perda ou inutilizacao de membro, sentido ou funcao; deformidade permanente; aborto",
            "Lesao seguida de morte (par. 3): reclusao de 4 a 12 anos. Crime preterdoloso (dolo na lesao, culpa na morte)",
            "Violencia domestica (par. 9 a 11): pena de detencao de 3 meses a 3 anos, com aumento se praticada contra deficiente",
            "Lesao corporal contra mulher por condicao de sexo feminino (par. 13, Lei 14.188/2021): reclusao de 1 a 4 anos",
          ],
        },
      ],
    },
    {
      id: "periclitacao-vida-saude",
      title: "Periclitacao da Vida e da Saude",
      icon: "AlertTriangle",
      descricao:
        "Os crimes de periclitacao da vida e da saude estao previstos nos arts. 130 a 136 do Codigo Penal. Sao crimes de perigo, ou seja, nao exigem a efetiva lesao ao bem juridico, bastando a exposicao a risco. Distinguem-se dos crimes de dano por tutelarem a incolumidade da pessoa antes que o mal efetivamente se concretize.",
      subtopics: [
        {
          id: "perigo-contagio-venereo",
          title: "Perigo de Contagio Venereo (Art. 130, CP)",
          artigos: "Art. 130 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 130, CP: 'Expor alguem, por meio de relacoes sexuais ou qualquer ato libidinoso, a contagio de molestia venerea, de que sabe ou deve saber que esta contaminado: Pena - detencao, de tres meses a um ano, ou multa.'",
          explicacao:
            "Crime de perigo concreto que tutela a incolumidade fisica. Exige que o agente saiba ou deva saber que esta contaminado por doenca venerea. O consentimento da vitima nao exclui o crime, pois o bem juridico e indisponivel. O paragrafo unico preve forma qualificada quando ha intencao de transmitir a molestia (dolo direto), elevando a pena para reclusao de 1 a 4 anos e multa.",
          elementosDoTipo: [
            "Sujeito ativo: pessoa contaminada por molestia venerea (crime proprio)",
            "Sujeito passivo: qualquer pessoa exposta ao contagio",
            "Conduta: expor alguem a contagio por meio de relacao sexual ou ato libidinoso",
            "Elemento subjetivo: dolo direto ou eventual (sabe ou deve saber)",
          ],
        },
        {
          id: "perigo-contagio-doenca-grave",
          title: "Perigo de Contagio de Molestia Grave (Art. 131, CP)",
          artigos: "Art. 131 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 131, CP: 'Praticar, com o fim de transmitir a outrem molestia grave de que esta contaminado, ato capaz de produzir o contagio: Pena - reclusao, de um a quatro anos, e multa.'",
          explicacao:
            "Diferentemente do art. 130, este tipo penal nao se restringe a doencas venereas, abrangendo qualquer molestia grave. Exige dolo especifico (fim de transmitir). E crime de perigo, consumando-se com a pratica do ato capaz de produzir o contagio, independentemente da efetiva transmissao. Discussao doutrinaria relevante quanto a transmissao intencional do HIV (NUCCI; BITENCOURT).",
          elementosDoTipo: [
            "Sujeito ativo: pessoa contaminada por molestia grave (crime proprio)",
            "Sujeito passivo: qualquer pessoa",
            "Conduta: praticar ato capaz de produzir contagio",
            "Elemento subjetivo: dolo especifico (fim de transmitir)",
          ],
          jurisprudencia: [
            "STJ, HC 160.982/DF: Discussao sobre a tipificacao da transmissao intencional do virus HIV - possibilidade de configuracao do art. 131 ou do art. 129 (lesao corporal gravissima por enfermidade incuravel).",
          ],
        },
        {
          id: "abandono-incapaz",
          title: "Abandono de Incapaz (Art. 133, CP) e Exposicao/Abandono de Recem-nascido (Art. 134, CP)",
          artigos: "Arts. 133 e 134 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 133, CP: 'Abandonar pessoa que esta sob seu cuidado, guarda, vigilancia ou autoridade, e, por qualquer motivo, incapaz de defender-se dos riscos resultantes do abandono: Pena - detencao, de seis meses a tres anos.'",
          explicacao:
            "O abandono de incapaz e crime proprio (sujeito ativo e a pessoa que tem dever de cuidado, guarda, vigilancia ou autoridade). E crime de perigo concreto, exigindo a efetiva situacao de risco ao abandonado. O art. 134 preve a forma especifica de exposicao ou abandono de recem-nascido para ocultar desonra propria, com pena de detencao de 1 a 3 anos. Ambos os crimes admitem formas qualificadas pelo resultado (lesao grave ou morte).",
          elementosDoTipo: [
            "Sujeito ativo: pessoa responsavel pelo cuidado, guarda, vigilancia ou autoridade (crime proprio)",
            "Sujeito passivo: pessoa incapaz de defender-se",
            "Conduta: abandonar (deixar desamparado, sem assistencia)",
            "Elemento subjetivo: dolo (nao se pune a forma culposa)",
          ],
        },
        {
          id: "omissao-socorro",
          title: "Omissao de Socorro (Art. 135, CP)",
          artigos: "Art. 135 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 135, CP: 'Deixar de prestar assistencia, quando possivel faze-lo sem risco pessoal, a crianca abandonada ou extraviada, ou a pessoa invalida ou ferida, ao desamparo ou em grave e iminente perigo; ou nao pedir, nesses casos, o socorro da autoridade publica: Pena - detencao, de um a seis meses, ou multa.'",
          explicacao:
            "A omissao de socorro e crime omissivo proprio (ou puro), pois o tipo penal descreve uma conduta negativa (deixar de prestar assistencia). O agente responde pela simples omissao, sem necessidade de resultado naturalistico. Exige-se que o agente possa prestar socorro sem risco pessoal. O paragrafo unico preve causa de aumento de pena se a omissao resulta em lesao corporal grave (pena aumentada de metade) ou morte (pena triplicada). E relevante a relacao deste tipo com o dever geral de solidariedade (art. 3, I, CF/88).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: crianca abandonada/extraviada, pessoa invalida, ferida ou em grave perigo",
            "Conduta: deixar de prestar assistencia ou de pedir socorro da autoridade publica",
            "Elemento subjetivo: dolo",
            "Requisito: possibilidade de agir sem risco pessoal",
          ],
          jurisprudencia: [
            "STJ, REsp 1.311.402/SC: A omissao de socorro exige que o agente tenha ciencia da situacao de perigo e possibilidade de agir sem risco pessoal.",
          ],
        },
        {
          id: "maus-tratos",
          title: "Maus-tratos (Art. 136, CP)",
          artigos: "Art. 136 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 136, CP: 'Expor a perigo a vida ou a saude de pessoa sob sua autoridade, guarda ou vigilancia, para fim de educacao, ensino, tratamento ou custodia, quer privando-a de alimentacao ou cuidados indispensaveis, quer sujeitando-a a trabalho excessivo ou inadequado, quer abusando de meios de correcao ou disciplina: Pena - detencao, de dois meses a um ano, ou multa.'",
          explicacao:
            "Crime proprio cujo sujeito ativo e quem exerce autoridade, guarda ou vigilancia para fins de educacao, ensino, tratamento ou custodia. O tipo penal preve tres modalidades de conduta: privacao de alimentacao ou cuidados indispensaveis; sujeicao a trabalho excessivo ou inadequado; abuso dos meios de correcao ou disciplina. E crime de perigo concreto. Relaciona-se com o Estatuto da Crianca e do Adolescente (Lei n. 8.069/90) e o Estatuto do Idoso (Lei n. 10.741/2003).",
          elementosDoTipo: [
            "Sujeito ativo: pessoa que exerce autoridade, guarda ou vigilancia (crime proprio)",
            "Sujeito passivo: pessoa subordinada ao sujeito ativo",
            "Conduta: expor a perigo por privacao de cuidados, trabalho excessivo ou abuso de correcao",
            "Elemento subjetivo: dolo, com o especifico fim de educacao, ensino, tratamento ou custodia",
          ],
        },
      ],
    },
    {
      id: "crimes-contra-honra",
      title: "Crimes contra a Honra",
      icon: "Scale",
      descricao:
        "Os crimes contra a honra estao previstos nos arts. 138 a 145 do Codigo Penal. Tutelam a honra da pessoa em suas duas dimensoes: honra objetiva (reputacao - como a pessoa e vista pela sociedade) e honra subjetiva (dignidade e decoro - como a pessoa se ve). A Constituicao Federal, no art. 5, X, assegura a inviolabilidade da honra e da imagem das pessoas.",
      subtopics: [
        {
          id: "calunia",
          title: "Calunia (Art. 138, CP)",
          artigos: "Art. 138, caput e paragrafos, do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 138, CP: 'Caluniar alguem, imputando-lhe falsamente fato definido como crime: Pena - detencao, de seis meses a dois anos, e multa.'",
          explicacao:
            "A calunia e o mais grave dos crimes contra a honra. Consiste em imputar falsamente a alguem fato definido como crime. Exige tres elementos essenciais: (a) imputacao de fato determinado; (b) esse fato deve ser definido como crime (nao contravenao); (c) a imputacao deve ser falsa. A falsidade pode recair sobre a existencia do fato ou sobre a autoria. Admite a exceptio veritatis (prova da verdade - par. 3), salvo nas hipoteses do art. 138, par. 3, I a III. A calunia tambem pode ser praticada contra os mortos (par. 2).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa, inclusive pessoa juridica (STJ, Sumula 227) e mortos (par. 2)",
            "Conduta: caluniar (imputar falsamente fato definido como crime)",
            "Elemento subjetivo: dolo, com consciencia da falsidade da imputacao",
          ],
          jurisprudencia: [
            "Sumula 227, STJ: 'A pessoa juridica pode ser vitima de difamacao, mas nao de injuria e calunia.'",
            "STF, Inq. 3.590/DF: A exceptio veritatis e admissivel na calunia, desde que observadas as restricoes legais do par. 3 do art. 138.",
          ],
          observacoes: [
            "Exceptio veritatis (art. 138, par. 3): admitida, salvo se o ofendido foi absolvido por sentenca irrecorrivel, se o fato e imputado ao Presidente da Republica ou chefe de governo estrangeiro, ou se o crime e de acao privada e o ofendido nao foi condenado",
            "Distincao da difamacao: na calunia se imputa fato criminoso falso; na difamacao se imputa fato ofensivo a reputacao (nao necessariamente criminoso e nao necessariamente falso)",
          ],
        },
        {
          id: "difamacao",
          title: "Difamacao (Art. 139, CP)",
          artigos: "Art. 139 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 139, CP: 'Difamar alguem, imputando-lhe fato ofensivo a sua reputacao: Pena - detencao, de tres meses a um ano, e multa.'",
          explicacao:
            "A difamacao consiste em imputar a alguem fato ofensivo a sua reputacao (honra objetiva). Diferentemente da calunia, o fato imputado nao precisa ser definido como crime, basta que seja desonroso. Alem disso, nao se exige falsidade do fato (mesmo que verdadeiro, configura difamacao). Nao se admite exceptio veritatis, salvo quando o ofendido e funcionario publico e a ofensa e relativa ao exercicio de suas funcoes (art. 139, paragrafo unico).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa, inclusive pessoa juridica (Sumula 227, STJ)",
            "Conduta: difamar (imputar fato ofensivo a reputacao)",
            "Elemento subjetivo: dolo (animus diffamandi)",
          ],
          observacoes: [
            "Exceptio veritatis: admitida apenas quando o ofendido e funcionario publico e a ofensa e relativa ao exercicio da funcao (art. 139, paragrafo unico)",
            "Pessoa juridica: pode ser sujeito passivo (Sumula 227, STJ)",
          ],
        },
        {
          id: "injuria",
          title: "Injuria (Art. 140, CP)",
          artigos: "Art. 140, caput e paragrafos, do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 140, CP: 'Injuriar alguem, ofendendo-lhe a dignidade ou o decoro: Pena - detencao, de um a seis meses, ou multa.'",
          explicacao:
            "A injuria ofende a honra subjetiva da vitima (dignidade e decoro). Nao ha imputacao de fato determinado, mas sim de qualidade negativa. O par. 1 preve o perdao judicial quando a injuria e provocada de forma reprovavel pelo ofendido (retorsao imediata). O par. 2 preve a injuria real (violencia ou vias de fato aviltantes). O par. 3 (com redacao da Lei n. 14.532/2023) preve a injuria racial, com pena de reclusao de 2 a 5 anos, equiparada ao crime de racismo para efeitos legais (imprescritivel e inafiancavel, conforme art. 5, XLII, CF/88).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa fisica (pessoa juridica nao pode ser vitima de injuria - Sumula 227, STJ)",
            "Conduta: injuriar (atribuir qualidade negativa, ofendendo dignidade ou decoro)",
            "Elemento subjetivo: dolo (animus injuriandi)",
          ],
          jurisprudencia: [
            "STF, HC 154.248/DF (2021): A injuria racial configura especie do crime de racismo, sendo, portanto, imprescritivel e inafiancavel.",
            "Lei n. 14.532/2023: Alterou o par. 3 do art. 140 e incluiu a injuria racial como forma de racismo, com pena de reclusao de 2 a 5 anos.",
          ],
          observacoes: [
            "Injuria simples (caput): detencao de 1 a 6 meses ou multa",
            "Perdao judicial (par. 1): quando provocada de forma reprovavel pelo ofendido ou retorsao imediata",
            "Injuria real (par. 2): vias de fato aviltantes - pena de detencao de 3 meses a 1 ano e multa",
            "Injuria racial (par. 3 - Lei 14.532/2023): reclusao de 2 a 5 anos e multa. Crime equiparado a racismo (imprescritivel e inafiancavel, art. 5, XLII, CF/88)",
          ],
        },
        {
          id: "disposicoes-comuns-honra",
          title: "Disposicoes Comuns (Arts. 141 a 145, CP)",
          artigos: "Arts. 141 a 145 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 141, CP: Causas de aumento de pena nos crimes contra a honra. Art. 142, CP: Exclusao do crime (imunidades). Art. 143, CP: Retratacao. Art. 144, CP: Pedido de explicacoes em juizo. Art. 145, CP: Acao penal nos crimes contra a honra.",
          explicacao:
            "O art. 141 preve causas de aumento de pena: aumento de 1/3 se o crime e praticado contra o Presidente da Republica, chefe de governo estrangeiro, funcionario publico no exercicio de suas funcoes, ou na presenca de varias pessoas ou por meio que facilite a divulgacao. O art. 142 estabelece exclusoes do crime (imunidades funcionais e profissionais): ofensa irrogada em juizo, opiniao desfavoravel de critica literaria/artistica/cientifica, e conceito desfavoravel emitido por funcionario publico no cumprimento do dever. O art. 143 admite a retratacao como causa de extincao da punibilidade na calunia e na difamacao. O art. 145 define a acao penal: regra geral e acao penal privada (queixa-crime), salvo injuria racial (acao publica incondicionada) e ofensa contra Presidente da Republica ou chefe de governo estrangeiro (acao publica condicionada a requisicao do Ministro da Justica).",
          elementosDoTipo: [],
          observacoes: [
            "Retratacao (art. 143): so se aplica a calunia e difamacao, extinguindo a punibilidade do caluniador/difamador que se retrata cabalmente antes da sentenca",
            "Acao penal (art. 145): regra = acao penal privada; injuria racial = publica incondicionada; ofensa ao Presidente/chefe estrangeiro = publica condicionada a requisicao",
            "Imunidade judiciaria (art. 142, I): advogados no exercicio da funcao (ver tambem art. 7, par. 2, Lei 8.906/94 - Estatuto da OAB)",
          ],
        },
      ],
    },
    {
      id: "crimes-liberdade-pessoal",
      title: "Crimes contra a Liberdade Pessoal",
      icon: "Lock",
      descricao:
        "Os crimes contra a liberdade pessoal estao previstos nos arts. 146 a 154-B do Codigo Penal. Tutelam a liberdade individual em suas diversas manifestacoes: liberdade de autodeterminacao, liberdade de locomocao, inviolabilidade de domicilio e de segredos. A liberdade pessoal e direito fundamental assegurado pelo art. 5, caput, da CF/88.",
      subtopics: [
        {
          id: "constrangimento-ilegal",
          title: "Constrangimento Ilegal (Art. 146, CP)",
          artigos: "Art. 146 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 146, CP: 'Constranger alguem, mediante violencia ou grave ameaca, ou depois de lhe haver reduzido, por qualquer outro meio, a capacidade de resistencia, a nao fazer o que a lei permite, ou a fazer o que ela nao manda: Pena - detencao, de tres meses a um ano, ou multa.'",
          explicacao:
            "O constrangimento ilegal e crime subsidiario, aplicando-se quando a conduta nao constituir elemento ou circunstancia de crime mais grave (ex.: roubo, extorsao). A conduta tipica consiste em constranger alguem, por violencia, grave ameaca ou outro meio que reduza a capacidade de resistencia, a fazer o que a lei nao manda ou a nao fazer o que ela permite. O par. 3 exclui o crime quando a coacao visa impedir suicidio (exercicio regular de direito).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa com capacidade de autodeterminacao",
            "Conduta: constranger mediante violencia, grave ameaca ou outro meio",
            "Elemento subjetivo: dolo",
          ],
        },
        {
          id: "ameaca",
          title: "Ameaca (Art. 147, CP)",
          artigos: "Art. 147 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 147, CP: 'Ameacar alguem, por palavra, escrito ou gesto, ou qualquer outro meio simbolico, de causar-lhe mal injusto e grave: Pena - detencao, de um a seis meses, ou multa.'",
          explicacao:
            "A ameaca e crime de acao penal publica condicionada a representacao (art. 147, paragrafo unico). O mal prometido deve ser injusto (ilicito) e grave (capaz de intimidar a vitima). Admite qualquer meio de execucao: palavra, escrito, gesto ou outro meio simbolico. A ameaca pode ser direta (contra a propria vitima), indireta (contra pessoa proxima da vitima) ou condicional.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa capaz de compreender a ameaca",
            "Conduta: ameacar de causar mal injusto e grave",
            "Elemento subjetivo: dolo",
            "Acao penal: publica condicionada a representacao",
          ],
        },
        {
          id: "sequestro-carcere",
          title: "Sequestro e Carcere Privado (Art. 148, CP)",
          artigos: "Art. 148 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 148, CP: 'Privar alguem de sua liberdade, mediante sequestro ou carcere privado: Pena - reclusao, de um a tres anos.'",
          explicacao:
            "Tutela a liberdade de locomocao. Sequestro e a retencao da vitima em local amplo; carcere privado e o enclausuramento. E crime permanente, cuja consumacao se protrai no tempo. O par. 1 preve qualificadoras: se a vitima e ascendente, descendente, conjuge, companheiro, ou maior de 60 anos; se mediante internacao em casa de saude ou hospital; se a privacao dura mais de 15 dias; se e praticado contra menor de 18 anos; se resulta a vitima, em razao de maus-tratos ou natureza da detencao, grave sofrimento fisico ou moral. O par. 2 preve causa de aumento de pena se o crime e praticado mediante internacao da vitima.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: qualquer pessoa",
            "Conduta: privar da liberdade de locomocao",
            "Elemento subjetivo: dolo",
            "Natureza: crime permanente",
          ],
          jurisprudencia: [
            "STJ, HC 593.417/SP: No sequestro, por ser crime permanente, o agente encontra-se em flagrante delito enquanto perdurar a privacao da liberdade da vitima (art. 303, CPP).",
          ],
        },
        {
          id: "violacao-domicilio",
          title: "Violacao de Domicilio (Art. 150, CP)",
          artigos: "Art. 150 do Decreto-Lei n. 2.848/1940 c/c Art. 5, XI, CF/88",
          fundamentoLegal:
            "Art. 150, CP: 'Entrar ou permanecer, clandestina ou astuciosamente, ou contra a vontade expressa ou tacita de quem de direito, em casa alheia ou em suas dependencias: Pena - detencao, de um a tres meses, ou multa.'",
          explicacao:
            "A violacao de domicilio tutela a inviolabilidade do domicilio, direito fundamental previsto no art. 5, XI, da CF/88: 'a casa e asilo inviolavel do individuo, ninguem nela podendo penetrar sem consentimento do morador, salvo em caso de flagrante delito ou desastre, ou para prestar socorro, ou, durante o dia, por determinacao judicial.' O conceito de 'casa' para fins penais e ampliado pelo par. 4 do art. 150, abrangendo qualquer compartimento habitado, aposento de habitacao coletiva e compartimento nao aberto ao publico.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum). Se funcionario publico, qualificadora do par. 2",
            "Sujeito passivo: morador (quem exerce o direito de exclusao)",
            "Conduta: entrar ou permanecer, de modo clandestino, astucioso, ou contra a vontade",
            "Elemento subjetivo: dolo",
          ],
          jurisprudencia: [
            "STF, RE 603.616/RO (Repercussao Geral - Tema 280): 'A entrada forcada em domicilio sem mandado judicial so e licita, mesmo em periodo noturno, quando amparada em fundadas razoes, devidamente justificadas a posteriori, que indiquem que dentro da casa ocorre situacao de flagrante delito.'",
          ],
        },
      ],
    },
    {
      id: "crimes-patrimonio",
      title: "Crimes contra o Patrimonio",
      icon: "Wallet",
      descricao:
        "Os crimes contra o patrimonio estao previstos nos arts. 155 a 183 do Codigo Penal. Tutelam o patrimonio em sentido amplo, abrangendo bens moveis e imoveis, direitos e interesses de valor economico. Sao os crimes de maior incidencia no sistema penal brasileiro.",
      subtopics: [
        {
          id: "furto",
          title: "Furto (Arts. 155 e 156, CP)",
          artigos: "Arts. 155 e 156 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 155, CP: 'Subtrair, para si ou para outrem, coisa alheia movel: Pena - reclusao, de um a quatro anos, e multa.'",
          explicacao:
            "O furto consiste na subtracao de coisa alheia movel, com animus furandi (intencao de apossamento definitivo). O par. 1 preve aumento de pena de 1/3 se o crime e praticado durante repouso noturno. O par. 2 preve o furto privilegiado (primario + coisa de pequeno valor = pena de detencao ou multa). O par. 4 qualifica o furto: com destruicao/rompimento de obstaculo, abuso de confianca ou fraude, escalada ou destreza, emprego de chave falsa, concurso de duas ou mais pessoas. O par. 4-B (incluido pela Lei n. 14.155/2021) tipifica o furto mediante fraude eletronica com pena de reclusao de 4 a 8 anos e multa. O art. 155, par. 3, equipara energia eletrica, ou outra de valor economico, a coisa movel.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: proprietario ou possuidor da coisa",
            "Conduta: subtrair (retirar da esfera de vigilancia do possuidor/proprietario)",
            "Objeto material: coisa alheia movel (inclusive energia eletrica - par. 3)",
            "Elemento subjetivo: dolo + animus furandi (intencao de apossamento definitivo)",
          ],
          jurisprudencia: [
            "Sumula 511, STJ: 'E possivel o reconhecimento do privilegio previsto no par. 2 do art. 155 do CP nos casos de crime de furto qualificado, se estiverem presentes a primariedade do agente, o pequeno valor da coisa e a qualificadora for de ordem objetiva.'",
            "STF, HC 123.734/MG (Repercussao Geral): A reincidencia nao impede, por si so, que o juiz reconheca a insignificancia penal da conduta, a luz das circunstancias do caso concreto.",
            "Sumula 567, STJ: 'Sistema de vigilancia realizado por monitoramento eletronico ou por existencia de seguranca no estabelecimento comercial, por si so, nao torna impossivel a configuracao do crime de furto.'",
          ],
          observacoes: [
            "Furto de uso: atipico (nao ha animus furandi, mas sim animus utendi - intencao de devolver apos o uso)",
            "Principio da insignificancia: aplicavel conforme criterios do STF - minima ofensividade, nenhuma periculosidade social, reduzido grau de reprovabilidade e inexpressividade da lesao juridica",
            "Furto de energia eletrica (par. 3): equiparacao legal a coisa movel",
            "Furto eletronico (par. 4-B, Lei 14.155/2021): reclusao de 4 a 8 anos",
          ],
        },
        {
          id: "roubo-extorsao",
          title: "Roubo (Art. 157, CP) e Extorsao (Art. 158, CP)",
          artigos: "Arts. 157 e 158 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 157, CP: 'Subtrair coisa movel alheia, para si ou para outrem, mediante grave ameaca ou violencia a pessoa, ou depois de have-la, por qualquer meio, reduzido a impossibilidade de resistencia: Pena - reclusao, de quatro a dez anos, e multa.'",
          explicacao:
            "O roubo e crime complexo (furto + constrangimento ilegal), que se caracteriza pela subtracao de coisa alheia movel mediante violencia ou grave ameaca. O par. 1 tipifica o roubo improprio (violencia exercida apos a subtracao, para assegurar a impunidade ou detencao da coisa). O par. 2 preve causas de aumento (arma de fogo, concurso de pessoas, transporte de valores, restricao de liberdade da vitima, etc.). O par. 2-A (incluido pela Lei n. 13.654/2018) preve aumento de 2/3 pelo emprego de arma de fogo. O par. 3, I preve o latrocinio (roubo seguido de lesao corporal grave: reclusao de 7 a 18 anos) e o par. 3, II o roubo seguido de morte/latrocinio (reclusao de 20 a 30 anos). A Sumula 610 do STF estabelece que 'ha crime de latrocinio, quando o homicidio se consuma, ainda que nao realize o agente a subtracao de bens da vitima.'",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: proprietario/possuidor e a pessoa constrangida (pode haver duplo sujeito passivo)",
            "Conduta: subtrair mediante violencia ou grave ameaca",
            "Elemento subjetivo: dolo + animus furandi",
          ],
          jurisprudencia: [
            "Sumula 610, STF: 'Ha crime de latrocinio, quando o homicidio se consuma, ainda que nao realize o agente a subtracao de bens da vitima.'",
            "Sumula 582, STJ: 'Consuma-se o crime de roubo com a inversao da posse do bem mediante emprego de violencia ou grave ameaca, ainda que por breve tempo e em seguida a perseguicao imediata ao agente e recuperacao da coisa roubada, sendo prescindivel a posse mansa e pacifica ou desvigiada.'",
          ],
        },
        {
          id: "estelionato",
          title: "Estelionato (Art. 171, CP)",
          artigos: "Art. 171, caput e paragrafos, do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 171, CP: 'Obter, para si ou para outrem, vantagem ilicita, em prejuizo alheio, induzindo ou mantendo alguem em erro, mediante artificio, ardil, ou qualquer outro meio fraudulento: Pena - reclusao, de um a cinco anos, e multa.'",
          explicacao:
            "O estelionato e crime contra o patrimonio praticado mediante fraude. Exige quatro elementos: (1) emprego de meio fraudulento (artificio, ardil ou outro meio); (2) inducao ou manutencao da vitima em erro; (3) obtencao de vantagem ilicita; (4) prejuizo alheio. O par. 2-A (incluido pela Lei n. 14.155/2021) tipifica a fraude eletronica, com pena de reclusao de 4 a 8 anos. O par. 5 (incluido pela Lei n. 13.964/2019 - Pacote Anticrime) estabelece que a acao penal e publica condicionada a representacao, salvo as hipoteses do par. 5 (vitima Administracao Publica, crianca/adolescente, pessoa com deficiencia, maior de 65 anos).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: a pessoa enganada e a que sofre o prejuizo patrimonial (podem ser diferentes)",
            "Conduta: obter vantagem ilicita mediante fraude, induzindo ou mantendo em erro",
            "Elemento subjetivo: dolo + dolo especifico (obter vantagem ilicita)",
          ],
          jurisprudencia: [
            "Sumula 24, STJ: 'Aplica-se ao crime de estelionato, em que figure como vitima entidade autarquica da Previdencia Social, a qualificadora do par. 3 do art. 171 do Codigo Penal.'",
            "STJ, HC 583.837/SC (2020): A acao penal do estelionato, apos a Lei n. 13.964/2019, e publica condicionada a representacao, salvo nos casos previstos no par. 5 do art. 171.",
          ],
        },
        {
          id: "receptacao",
          title: "Receptacao (Art. 180, CP)",
          artigos: "Art. 180 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 180, CP: 'Adquirir, receber, transportar, conduzir ou ocultar, em proveito proprio ou alheio, coisa que sabe ser produto de crime, ou influir para que terceiro, de boa-fe, a adquira, receba ou oculte: Pena - reclusao, de um a quatro anos, e multa.'",
          explicacao:
            "A receptacao e crime acessorio (pressupoe a existencia de um crime antecedente). O tipo penal preve a receptacao propria (caput, primeira parte: adquirir, receber, transportar, conduzir ou ocultar) e a receptacao impropria (caput, segunda parte: influir para que terceiro adquira). O par. 1 tipifica a receptacao qualificada (no exercicio de atividade comercial ou industrial), com pena de reclusao de 3 a 8 anos. O par. 3 preve a receptacao culposa. A receptacao e crime autonomo em relacao ao crime antecedente: a punibilidade da receptacao independe da punibilidade do crime de que proveio a coisa.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa, exceto o autor/participe do crime antecedente (crime comum)",
            "Sujeito passivo: o proprietario da coisa e o Estado",
            "Conduta: adquirir, receber, transportar, conduzir, ocultar ou influir para que terceiro adquira",
            "Elemento subjetivo: dolo (ciencia de que a coisa e produto de crime) ou culpa (par. 3)",
          ],
          jurisprudencia: [
            "Sumula 523, STF: 'No processo penal, a falta da defesa constitui nulidade absoluta, mas a sua deficiencia so o anulara se houver prova de prejuizo para o reu.' (aplicavel ao contexto de receptacao)",
          ],
        },
      ],
    },
    {
      id: "crimes-propriedade-imaterial",
      title: "Crimes contra a Propriedade Imaterial",
      icon: "FileText",
      descricao:
        "Os crimes contra a propriedade imaterial estao previstos nos arts. 184 a 196 do Codigo Penal e em legislacao especial (Lei n. 9.279/96 - propriedade industrial; Lei n. 9.610/98 - direitos autorais). Tutelam os direitos intelectuais do autor de obra literaria, artistica ou cientifica, bem como os direitos de propriedade industrial.",
      subtopics: [
        {
          id: "violacao-direito-autoral",
          title: "Violacao de Direito Autoral (Art. 184, CP)",
          artigos: "Art. 184 do Decreto-Lei n. 2.848/1940 c/c Lei n. 9.610/1998",
          fundamentoLegal:
            "Art. 184, CP: 'Violar direitos de autor e os que lhe sao conexos: Pena - detencao, de 3 (tres) meses a 1 (um) ano, ou multa.'",
          explicacao:
            "O art. 184 do CP tipifica a violacao de direitos autorais (direitos morais e patrimoniais do autor, previstos nos arts. 22 a 29 da Lei n. 9.610/98). O par. 1 qualifica o crime quando ha reproducao total ou parcial com intuito de lucro (reclusao de 2 a 4 anos). O par. 2 qualifica a distribuicao, venda ou exposicao a venda de obra intelectual falsificada. O par. 3 qualifica o oferecimento ao publico, mediante cabo, fibra otica, satelite, ondas ou qualquer outro sistema. O par. 4 preve exclusoes de tipicidade para copias de pequenos trechos ou para uso privado sem intuito de lucro. A CF/88, art. 5, XXVII, assegura aos autores o direito exclusivo de utilizacao, publicacao ou reproducao de suas obras.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: titular dos direitos autorais ou conexos",
            "Conduta: violar direitos de autor (reproduzir, distribuir, etc.)",
            "Elemento subjetivo: dolo",
          ],
          jurisprudencia: [
            "Sumula 502, STJ: 'Presentes a materialidade e a autoria, afigura-se tipica, em relacao ao crime previsto no art. 184, par. 2, do CP, a conduta de expor a venda CDs e DVDs piratas.'",
          ],
        },
      ],
    },
    {
      id: "crimes-organizacao-trabalho",
      title: "Crimes contra a Organizacao do Trabalho",
      icon: "Briefcase",
      descricao:
        "Os crimes contra a organizacao do trabalho estao previstos nos arts. 197 a 207 do Codigo Penal. Tutelam a liberdade de trabalho, a organizacao laboral e os direitos coletivos dos trabalhadores. A competencia para julgamento e, em regra, da Justica Federal quando ha ofensa ao sistema de orgaos e instituicoes que preservam a organizacao geral do trabalho (art. 109, VI, CF/88).",
      subtopics: [
        {
          id: "atentado-liberdade-trabalho",
          title: "Atentado contra a Liberdade de Trabalho e Demais Crimes (Arts. 197 a 207, CP)",
          artigos: "Arts. 197 a 207 do Decreto-Lei n. 2.848/1940 c/c art. 109, VI, CF/88",
          fundamentoLegal:
            "Art. 197, CP: 'Constranger alguem, mediante violencia ou grave ameaca: I - a exercer ou nao exercer arte, oficio, profissao ou industria, ou a trabalhar ou nao trabalhar durante certo periodo ou em determinados dias: Pena - detencao, de um mes a um ano, e multa, alem da pena correspondente a violencia.'",
          explicacao:
            "Estes crimes tutelam o trabalho como valor social (art. 1, IV, CF/88). Incluem: atentado contra a liberdade de trabalho (art. 197), atentado contra a liberdade de contrato de trabalho e boicotagem violenta (art. 198), atentado contra a liberdade de associacao (art. 199), paralisacao de trabalho seguida de violencia ou perturbacao da ordem (art. 200), paralisacao de trabalho de interesse coletivo (art. 201), invasao de estabelecimento industrial, comercial ou agricola e sabotagem (art. 202), frustacao de direito assegurado por lei trabalhista (art. 203), frustacao de lei sobre a nacionalizacao do trabalho (art. 204), exercicio de atividade com infracao de decisao administrativa (art. 205), aliciamento para o fim de emigracao (art. 206) e aliciamento de trabalhadores de um local para outro do territorio nacional (art. 207). O STF definiu que a competencia e da Justica Federal quando o crime ofende o sistema de orgaos e instituicoes de protecao coletiva do trabalho.",
          elementosDoTipo: [
            "Sujeito ativo: varia conforme o tipo penal",
            "Sujeito passivo: trabalhador ou grupo de trabalhadores",
            "Bem juridico: liberdade de trabalho e organizacao laboral",
          ],
          jurisprudencia: [
            "STF, RE 398.041/PA: 'A competencia para julgamento dos crimes contra a organizacao do trabalho e da Justica Federal quando ha ofensa ao sistema de orgaos e instituicoes que preservam, coletivamente, os direitos e deveres dos trabalhadores.'",
            "Sumula 115, TFR: 'Compete a Justica Federal processar e julgar os crimes contra a organizacao do trabalho, quando tenham por objeto a organizacao geral do trabalho ou direitos dos trabalhadores considerados coletivamente.'",
          ],
        },
      ],
    },
    {
      id: "crimes-sentimento-religioso",
      title: "Crimes contra o Sentimento Religioso e o Respeito aos Mortos",
      icon: "Church",
      descricao:
        "Os crimes contra o sentimento religioso e o respeito aos mortos estao previstos nos arts. 208 a 212 do Codigo Penal. Tutelam, respectivamente, a liberdade de crenca e culto religioso (art. 5, VI, CF/88) e o sentimento de reverencia e respeito devidos aos mortos.",
      subtopics: [
        {
          id: "ultraje-culto",
          title: "Ultraje a Culto e Impedimento ou Perturbacao de Ato a ele Relativo (Art. 208, CP)",
          artigos: "Art. 208 do Decreto-Lei n. 2.848/1940 c/c art. 5, VI, CF/88",
          fundamentoLegal:
            "Art. 208, CP: 'Escarnecer de alguem publicamente, por motivo de crenca ou funcao religiosa; impedir ou perturbar cerimonia ou pratica de culto religioso; vilipendiar publicamente ato ou objeto de culto religioso: Pena - detencao, de um mes a um ano, ou multa.'",
          explicacao:
            "O artigo tipifica tres condutas distintas: (1) escarnecer publicamente de alguem por motivo de crenca ou funcao religiosa; (2) impedir ou perturbar cerimonia ou pratica de culto religioso; (3) vilipendiar publicamente ato ou objeto de culto. Tutela a liberdade religiosa consagrada no art. 5, VI, da CF/88: 'e inviolavel a liberdade de consciencia e de crenca, sendo assegurado o livre exercicio dos cultos religiosos e garantida, na forma da lei, a protecao aos locais de culto e a suas liturgias.' O Estado brasileiro e laico (art. 19, I, CF/88), mas protege todas as manifestacoes religiosas.",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: pessoa escarnecida, comunidade religiosa ou o Estado",
            "Conduta: escarnecer, impedir, perturbar ou vilipendiar",
            "Elemento subjetivo: dolo",
          ],
        },
        {
          id: "vilipendio-cadaver",
          title: "Violacao de Sepultura, Destruicao de Cadaver e Vilipendio (Arts. 210 a 212, CP)",
          artigos: "Arts. 210, 211 e 212 do Decreto-Lei n. 2.848/1940",
          fundamentoLegal:
            "Art. 210, CP: 'Violar ou profanar sepultura ou urna funeraria: Pena - reclusao, de um a tres anos, e multa.' Art. 211, CP: 'Destruir, subtrair ou ocultar cadaver ou parte dele: Pena - reclusao, de um a tres anos, e multa.' Art. 212, CP: 'Vilipendiar cadaver ou suas cinzas: Pena - detencao, de um a tres anos, e multa.'",
          explicacao:
            "Estes tipos penais tutelam o sentimento de respeito e piedade que a coletividade devota aos mortos. A violacao de sepultura (art. 210) consiste em violar ou profanar sepultura ou urna funeraria. A destruicao, subtracao ou ocultacao de cadaver (art. 211) pune quem destroi, subtrai ou oculta cadaver ou parte dele. O vilipendio a cadaver (art. 212) pune qualquer ato de desrespeito ou ultraje ao cadaver ou suas cinzas. O bem juridico e supraindividual (sentimento coletivo de respeito aos mortos).",
          elementosDoTipo: [
            "Sujeito ativo: qualquer pessoa (crime comum)",
            "Sujeito passivo: a coletividade (os familiares do morto sao sujeitos passivos secundarios)",
            "Conduta: violar, profanar, destruir, subtrair, ocultar ou vilipendiar",
            "Elemento subjetivo: dolo",
          ],
        },
      ],
    },
  ],
};
