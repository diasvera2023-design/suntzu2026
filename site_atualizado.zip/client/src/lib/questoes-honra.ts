import { type Questao } from "./questoes-vida";

export const questoesHonra: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXX Exame",
    enunciado:
      "Joao afirma publicamente que Pedro roubou dinheiro da empresa onde trabalham. Na verdade, Pedro nao cometeu o roubo. A conduta de Joao configura",
    alternativas: [
      { letra: "a", texto: "difamacao." },
      { letra: "b", texto: "calunia." },
      { letra: "c", texto: "injuria." },
      { letra: "d", texto: "falso testemunho." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Imputar falsamente fato definido como crime (roubo) caracteriza calunia (art. 138). Difamacao seria se o fato nao fosse crime, mas ofensivo a reputacao.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2021",
    enunciado: "No crime de injuria (art. 140), ofende-se",
    alternativas: [
      { letra: "a", texto: "a reputacao da pessoa." },
      { letra: "b", texto: "a dignidade ou o decoro." },
      { letra: "c", texto: "a honra objetiva." },
      { letra: "d", texto: "a imagem publica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A injuria atinge a honra subjetiva (dignidade e decoro). A honra objetiva (reputacao) e protegida pela difamacao.",
  },
  {
    id: 3,
    fonte: "OAB - XXXI Exame",
    enunciado:
      "Maria diz a colegas que Carla e desonesta, pois sonega impostos. Carla realmente sonega. A conduta de Maria configura",
    alternativas: [
      { letra: "a", texto: "calunia." },
      { letra: "b", texto: "difamacao." },
      { letra: "c", texto: "injuria." },
      { letra: "d", texto: "nada, pois e verdade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Imputar fato ofensivo a reputacao (sonegacao), mesmo que verdadeiro, e difamacao (art. 139). Na calunia, a verdade exclui o crime (exceptio veritatis); na difamacao, nao.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2022",
    enunciado:
      "No crime de calunia, admite-se a prova da verdade (exceptio veritatis)",
    alternativas: [
      { letra: "a", texto: "sempre." },
      { letra: "b", texto: "nunca." },
      { letra: "c", texto: "exceto nas hipoteses do par. 3 do art. 138." },
      { letra: "d", texto: "apenas se o ofendido for funcionario publico." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 138, par. 3, veda a prova da verdade quando a imputacao se refere: I - a crime de que o ofendido foi absolvido por sentenca irrecorrivel; II - a crime prescrito ou extinta a punibilidade; III - contra o Presidente da Republica ou chefe de governo estrangeiro.",
  },
  {
    id: 5,
    fonte: "OAB - XXXII Exame",
    enunciado:
      'Carlos, durante discussao, chama Pedro de "ladrao" e "corrupto". Pedro processa Carlos por calunia. Carlos prova que Pedro foi condenado por corrupcao. Nesse caso,',
    alternativas: [
      { letra: "a", texto: "Carlos responde por calunia, pois a ofensa foi publica." },
      { letra: "b", texto: "Carlos nao responde, pois provou a verdade (exceptio veritatis)." },
      { letra: "c", texto: "Carlos responde por difamacao, pois ofendeu a reputacao." },
      { letra: "d", texto: "Carlos responde por injuria real." },
    ],
    respostaCorreta: "b",
    explicacao:
      '"Ladrao" e "corrupto" sao imputacoes de fatos criminosos (calunia). Provada a verdade, aplica-se a exceptio veritatis (art. 138, par. 1). Nao ha crime.',
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2020",
    enunciado:
      "Injuria racial (art. 140, par. 3, apos Lei 14.532/2023) e crime",
    alternativas: [
      { letra: "a", texto: "de acao penal privada." },
      { letra: "b", texto: "de acao penal publica condicionada." },
      { letra: "c", texto: "de acao penal publica incondicionada." },
      { letra: "d", texto: "que admite retratacao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A injuria racial foi equiparada ao crime de racismo (Lei 14.532/2023). Portanto, tem acao penal publica incondicionada, e imprescritivel e inafiancavel (art. 5, XLII, CF).",
  },
  {
    id: 7,
    fonte: "OAB - XXXIII Exame",
    enunciado:
      "Jornal publica reportagem acusando politico de desviar verbas publicas. O politico processa o jornal por calunia. O jornal prova que a acusacao e verdadeira. O jornal",
    alternativas: [
      { letra: "a", texto: "responde por calunia, pois ofendeu honra de funcionario publico." },
      { letra: "b", texto: "nao responde, devido a exceptio veritatis." },
      { letra: "c", texto: "responde por difamacao, pois o fato ofende a reputacao." },
      { letra: "d", texto: "esta protegido pela imunidade profissional." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Calunia admite prova da verdade. Se o jornal prova que o politico realmente desviou verbas (fato criminoso verdadeiro), nao ha crime. Se fosse difamacao, a verdade nao excluiria.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2022",
    enunciado: "No crime de difamacao, o fato imputado",
    alternativas: [
      { letra: "a", texto: "deve ser necessariamente crime." },
      { letra: "b", texto: "deve ser ofensivo a reputacao." },
      { letra: "c", texto: "deve ser falso." },
      { letra: "d", texto: "deve ser contra funcionario publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Difamacao (art. 139) exige imputacao de fato ofensivo a reputacao. Nao precisa ser crime, nem ser falso.",
  },
  {
    id: 9,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      'Durante briga, Joao chama Pedro de "idiota" e "incapaz". A conduta configura',
    alternativas: [
      { letra: "a", texto: "calunia." },
      { letra: "b", texto: "difamacao." },
      { letra: "c", texto: "injuria." },
      { letra: "d", texto: "contravencao de vias de fato." },
    ],
    respostaCorreta: "c",
    explicacao:
      '"Idiota" e "incapaz" sao ofensas a dignidade/decoro (qualidades negativas), nao imputacao de fatos. Caracteriza injuria (art. 140).',
  },
  {
    id: 10,
    fonte: "PC-PR - 2023",
    enunciado: "A pena da injuria racial (art. 140, par. 3) e de",
    alternativas: [
      { letra: "a", texto: "detencao, de 1 a 6 meses, ou multa." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos, e multa." },
      { letra: "c", texto: "reclusao, de 2 a 5 anos." },
      { letra: "d", texto: "reclusao, de 3 a 8 anos." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Apos Lei 14.532/2023, a injuria racial tem pena de reclusao, de 2 a 5 anos. Antes era de 1 a 3 anos.",
  },
  {
    id: 11,
    fonte: "OAB - XXXV Exame",
    enunciado:
      'Advogado, em peticao judicial, acusa testemunha de ser "mentirosa contumaz". A testemunha processa por injuria. O advogado',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, devido a imunidade funcional (art. 142, I)." },
      { letra: "c", texto: "responde apenas se nao provar a verdade." },
      { letra: "d", texto: "responde por difamacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ofensa irrogada em juizo, no exercicio da funcao, esta protegida pela imunidade funcional do art. 142, I, CP, desde que pertinente a discussao.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2021",
    enunciado: "No crime de calunia contra os mortos (art. 138, par. 2),",
    alternativas: [
      { letra: "a", texto: "a acao penal e publica." },
      { letra: "b", texto: "podem propor a acao os parentes em linha reta ou colateral ate 4 grau." },
      { letra: "c", texto: "a pena e a mesma do caput." },
      { letra: "d", texto: "admite-se retratacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A calunia contra mortos pode ser proposta por parentes em linha reta ou colateral ate 4 grau (art. 138, par. 2). A pena e a mesma, e a acao e privada.",
  },
  {
    id: 13,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      'Reporter, em artigo, afirma que empresario tem "conduta antietica e fraudulenta". O empresario processa por difamacao. O reporter prova a veracidade. O reporter',
    alternativas: [
      { letra: "a", texto: "responde por difamacao, pois a verdade nao exclui." },
      { letra: "b", texto: "nao responde, se o empresario for pessoa publica." },
      { letra: "c", texto: "responde por calunia, pois o fato e crime." },
      { letra: "d", texto: "nao responde, devido a liberdade de imprensa." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Na difamacao, a verdade do fato nao exclui o crime (art. 139). So excluiria se o ofendido fosse funcionario publico e a ofensa relacionada ao exercicio da funcao (par. unico).",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2020",
    enunciado: "Injuria real (art. 140, par. 2) ocorre quando",
    alternativas: [
      { letra: "a", texto: "a ofensa e por escrito." },
      { letra: "b", texto: "ha violencia ou vias de fato que se vinculem a injuria." },
      { letra: "c", texto: "a ofensa e praticada por meio de comunicacao em massa." },
      { letra: "d", texto: "a vitima e funcionario publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Injuria real e a ofensa a dignidade/decoro acompanhada de violencia ou vias de fato que se vinculem a ela (par. 2). Ex.: cuspir no rosto + xingar.',
  },
  {
    id: 15,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      'Professor, em aula, critica obra literaria dizendo que "o autor e mediocre e sem talento". O autor processa por injuria. O professor',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, devido a imunidade da critica literaria (art. 142, II)." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde apenas se o autor for pessoa publica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A critica literaria, artistica ou cientifica, mesmo desfavoravel, esta protegida pela imunidade do art. 142, II, desde que nao seja mero ataque pessoal.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado: "No crime de calunia, a imputacao deve ser de",
    alternativas: [
      { letra: "a", texto: "qualquer fato ofensivo." },
      { letra: "b", texto: "fato definido como crime." },
      { letra: "c", texto: "fato que cause dano moral." },
      { letra: "d", texto: "conduta ilicita em geral." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Calunia exige imputacao de fato definido como crime. Contravencao nao basta.",
  },
  {
    id: 17,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      'Maria, em rede social, escreve que "Ana e uma pessima profissional e ja foi demitida por incompetencia". Ana processa por difamacao. Maria prova que Ana realmente foi demitida por incompetencia. Maria',
    alternativas: [
      { letra: "a", texto: "nao responde, pois provou a verdade." },
      { letra: "b", texto: "responde por difamacao, pois a verdade nao exclui." },
      { letra: "c", texto: "responde por injuria." },
      { letra: "d", texto: "responde por calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Difamacao: imputacao de fato ofensivo a reputacao (ser pessima profissional/demitida por incompetencia). A verdade nao exclui o crime, exceto se for funcionario publico e relacionado a funcao.",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado: "A retratacao (art. 143) extingue a punibilidade",
    alternativas: [
      { letra: "a", texto: "em todos os crimes contra a honra." },
      { letra: "b", texto: "apenas na calunia e difamacao." },
      { letra: "c", texto: "apenas na injuria." },
      { letra: "d", texto: "apenas se feita antes da acao penal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A retratacao extingue a punibilidade apenas na calunia e difamacao (art. 143). Na injuria, nao ha previsao.",
  },
  {
    id: 19,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      'Carlos, durante discussao com seguranca, chama-o de "macaco". A conduta configura',
    alternativas: [
      { letra: "a", texto: "injuria simples." },
      { letra: "b", texto: "injuria racial." },
      { letra: "c", texto: "racismo (Lei 7.716/89)." },
      { letra: "d", texto: "difamacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Termo "macaco" com conotacao racial caracteriza injuria racial (art. 140, par. 3), apos Lei 14.532/2023. Difere do crime de racismo, que e mais amplo (discriminacao contra coletividade).',
  },
  {
    id: 20,
    fonte: "MPE-ES - 2021",
    enunciado:
      "No crime de difamacao contra funcionario publico, relativa ao exercicio da funcao,",
    alternativas: [
      { letra: "a", texto: "sempre ha crime." },
      { letra: "b", texto: "admite-se prova da verdade." },
      { letra: "c", texto: "a pena e aumentada." },
      { letra: "d", texto: "a acao penal e publica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 139, paragrafo unico: na difamacao contra funcionario publico, relativa ao exercicio da funcao, admite-se prova da verdade. E excecao a regra da difamacao.",
  },
  {
    id: 21,
    fonte: "OAB - XL Exame",
    enunciado:
      'Jornal publica que politico "desvia dinheiro publico para comprar imoveis no exterior". O politico foi absolvido por sentenca irrecorrivel dessa acusacao. O jornal',
    alternativas: [
      { letra: "a", texto: "pode provar a verdade (exceptio veritatis)." },
      { letra: "b", texto: "nao pode provar a verdade, nos termos do art. 138, par. 3, I." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "esta protegido pela liberdade de imprensa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 138, par. 3, I: nao se admite prova da verdade se a imputacao refere-se a crime de que o ofendido foi absolvido por sentenca irrecorrivel. Ainda que verdadeiro, nao se pode provar.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado: "A pena da calunia e aumentada de 1/3 se praticada",
    alternativas: [
      { letra: "a", texto: "contra parente." },
      { letra: "b", texto: "com violencia." },
      { letra: "c", texto: "na presenca de varias pessoas." },
      { letra: "d", texto: "por meio de escrito." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 141, III: aumento de 1/3 se o crime e cometido na presenca de varias pessoas, ou por meio que facilite a divulgacao.",
  },
  {
    id: 23,
    fonte: "OAB - XLI Exame",
    enunciado:
      'Joao, em briga de bar, da um soco em Pedro e diz "voce e um lixo". Configura',
    alternativas: [
      { letra: "a", texto: "lesao corporal e injuria." },
      { letra: "b", texto: "injuria real." },
      { letra: "c", texto: "difamacao e lesao corporal." },
      { letra: "d", texto: "calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Violencia (soco) + ofensa a dignidade ("lixo") vinculadas caracterizam injuria real (art. 140, par. 2). Ha concurso com lesao corporal, se houver lesao.',
  },
  {
    id: 24,
    fonte: "TJ-MG - 2020",
    enunciado:
      "No crime de injuria, o perdao judicial (art. 140, par. 1) aplica-se quando",
    alternativas: [
      { letra: "a", texto: "a vitima perdoa o agente." },
      { letra: "b", texto: "a injuria e reciproca." },
      { letra: "c", texto: "a injuria e provocada de forma reprovavel pelo ofendido." },
      { letra: "d", texto: "o agente se retrata." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Perdao judicial ocorre quando a injuria e provocada de forma reprovavel pelo ofendido (retorsao imediata). O juiz pode deixar de aplicar a pena.",
  },
  {
    id: 25,
    fonte: "OAB - XLII Exame",
    enunciado:
      'Blogueiro escreve que "o prefeito e corrupto e desvia verbas". O prefeito processa por calunia. O blogueiro prova que o prefeito foi condenado por corrupcao. O blogueiro',
    alternativas: [
      { letra: "a", texto: "responde por calunia, pois ofendeu funcionario publico." },
      { letra: "b", texto: "nao responde, devido a exceptio veritatis." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde por injuria." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Calunia admite prova da verdade. Se provou que o fato criminoso e verdadeiro (condenacao), nao ha crime. O fato de ser funcionario publico nao altera.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2022",
    enunciado:
      "Critica desfavoravel emitida por funcionario publico no cumprimento do dever",
    alternativas: [
      { letra: "a", texto: "sempre configura difamacao." },
      { letra: "b", texto: "esta protegida pela imunidade do art. 142, III." },
      { letra: "c", texto: "so e protegida se for verdadeira." },
      { letra: "d", texto: "da direito a retratacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 142, III: nao constitui crime contra a honra o conceito desfavoravel emitido por funcionario publico no cumprimento do dever (ex.: avaliacao de servidor).",
  },
  {
    id: 27,
    fonte: "OAB - XLIII Exame",
    enunciado:
      'Ana, em rede social, escreve: "Carlos e um estelionatario, ja foi processado varias vezes". Carlos nunca cometeu estelionato. A conduta configura',
    alternativas: [
      { letra: "a", texto: "difamacao." },
      { letra: "b", texto: "calunia." },
      { letra: "c", texto: "injuria." },
      { letra: "d", texto: "falsa comunicacao de crime." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Imputar falsamente fato definido como crime (estelionato) = calunia. Se fosse verdade, ainda seria calunia, mas com exceptio veritatis.",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2021",
    enunciado: "No crime de difamacao, a acao penal e",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "depende da gravidade." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Regra geral: crimes contra a honra tem acao penal privada (queixa-crime), art. 145. Excecoes: injuria racial (publica incondicionada) e ofensa a Presidente/chefe de governo estrangeiro (publica condicionada).",
  },
  {
    id: 29,
    fonte: "OAB - XLIV Exame",
    enunciado:
      'Durante entrevista, jornalista diz que "o governador e incompetente e negligente". O governador processa por injuria. O jornalista',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, pois e opiniao politica protegida." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde por calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Critica politica, mesmo dura, desde que nao seja imputacao de fato criminoso especifico, esta protegida pela liberdade de expressao e imunidade politica. Nao configura injuria se for mera opiniao.",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado: "No crime de calunia, a imputacao falsa pode recair",
    alternativas: [
      { letra: "a", texto: "apenas sobre a existencia do fato." },
      { letra: "b", texto: "apenas sobre a autoria." },
      { letra: "c", texto: "sobre a existencia do fato ou sobre a autoria." },
      { letra: "d", texto: "apenas sobre crimes dolosos." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A falsidade pode ser sobre a existencia do fato (nao aconteceu) ou sobre a autoria (aconteceu, mas nao foi o ofendido).",
  },
  {
    id: 31,
    fonte: "OAB - XLV Exame",
    enunciado:
      'Medico, em relatorio, afirma que paciente tem "tendencias perigosas e comportamento anti-social". O paciente processa por difamacao. O medico',
    alternativas: [
      { letra: "a", texto: "responde por difamacao." },
      { letra: "b", texto: "nao responde, devido a imunidade profissional (art. 142, III)." },
      { letra: "c", texto: "responde por injuria." },
      { letra: "d", texto: "responde apenas se nao for verdade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Conceito desfavoravel emitido por profissional no cumprimento do dever (medico em relatorio) esta protegido pela imunidade do art. 142, III, desde que pertinente.",
  },
  {
    id: 32,
    fonte: "MPE-PI - 2020",
    enunciado:
      "Acao penal por injuria racial (apos Lei 14.532/2023) e",
    alternativas: [
      { letra: "a", texto: "publica condicionada a representacao." },
      { letra: "b", texto: "privada." },
      { letra: "c", texto: "publica incondicionada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Injuria racial equiparou-se ao racismo: acao penal publica incondicionada, imprescritivel, inafiancavel.",
  },
  {
    id: 33,
    fonte: "OAB - XLVI Exame",
    enunciado:
      'Carlos diz a amigos: "Pedro e um covarde, fugiu da briga". Pedro processa por difamacao. Carlos prova que Pedro realmente fugiu. Carlos',
    alternativas: [
      { letra: "a", texto: "nao responde, pois provou a verdade." },
      { letra: "b", texto: "responde por difamacao, pois a verdade nao exclui." },
      { letra: "c", texto: "responde por injuria." },
      { letra: "d", texto: "responde por calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      '"Covarde" e "fugiu da briga" sao fatos ofensivos a reputacao (difamacao). Na difamacao, a verdade nao exclui o crime, salvo se for funcionario publico e relativo a funcao.',
  },
  {
    id: 34,
    fonte: "PC-PE - 2022",
    enunciado: "Ofensa ao Presidente da Republica tem acao penal",
    alternativas: [
      { letra: "a", texto: "privada." },
      { letra: "b", texto: "publica incondicionada." },
      { letra: "c", texto: "publica condicionada a requisicao do Ministro da Justica." },
      { letra: "d", texto: "publica condicionada a representacao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 145, par. 1: ofensa ao Presidente da Republica ou chefe de governo estrangeiro tem acao publica condicionada a requisicao do Ministro da Justica.",
  },
  {
    id: 35,
    fonte: "OAB - XLVII Exame",
    enunciado:
      'Professor, ao reprovar aluno, diz: "voce e burro e nao tem capacidade". O aluno processa por injuria. O professor',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, devido a imunidade funcional." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde apenas se ofendeu em publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Conceito desfavoravel emitido no exercicio da funcao (professor avaliando aluno) esta protegido pela imunidade do art. 142, III, se pertinente ao dever.",
  },
  {
    id: 36,
    fonte: "TJ-AM - 2021",
    enunciado:
      "No crime de difamacao, admite-se a exceptio veritatis",
    alternativas: [
      { letra: "a", texto: "sempre." },
      { letra: "b", texto: "nunca." },
      { letra: "c", texto: "apenas se o ofendido for funcionario publico e a ofensa relativa ao exercicio da funcao." },
      { letra: "d", texto: "apenas se a ofensa for por escrito." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 139, paragrafo unico: na difamacao, so se admite prova da verdade se o ofendido for funcionario publico e a ofensa relativa ao exercicio da funcao.",
  },
  {
    id: 37,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      'Maria, em discussao, chama Joana de "prostituta". Joana processa por injuria. Maria prova que Joana exerce a prostituicao. Maria',
    alternativas: [
      { letra: "a", texto: "nao responde, pois provou a verdade." },
      { letra: "b", texto: "responde por injuria, pois a verdade nao exclui." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde por calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Injuria (ofensa a dignidade) nao admite prova da verdade. Mesmo que Joana seja prostituta, o termo "prostituta" como ofensa configura injuria. A verdade so e admissivel na calunia.',
  },
  {
    id: 38,
    fonte: "MPE-TO - 2023",
    enunciado:
      "Retratacao na calunia extingue a punibilidade se feita",
    alternativas: [
      { letra: "a", texto: "antes do recebimento da queixa." },
      { letra: "b", texto: "antes do transito em julgado." },
      { letra: "c", texto: "a qualquer tempo, mesmo apos condenacao." },
      { letra: "d", texto: "apenas se aceita pela vitima." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Art. 143: a retratacao extingue a punibilidade se feita antes do recebimento da queixa (na calunia e difamacao). Apos, so atenua a pena.",
  },
  {
    id: 39,
    fonte: "OAB - XLIX Exame",
    enunciado:
      'Jornal publica que "o senador recebeu propina". O senador foi absolvido por sentenca irrecorrivel dessa acusacao. O jornal',
    alternativas: [
      { letra: "a", texto: "pode provar a verdade." },
      { letra: "b", texto: "nao pode provar a verdade (art. 138, par. 3, I)." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "esta protegido pela liberdade de imprensa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 138, par. 3, I: nao se admite prova da verdade se a imputacao refere-se a crime de que o ofendido foi absolvido por sentenca irrecorrivel. Ainda que o jornal tenha provas, nao pode usa-las.",
  },
  {
    id: 40,
    fonte: "PC-CE - 2020",
    enunciado:
      "Injuria racial equiparada ao racismo (Lei 14.532/2023) e crime",
    alternativas: [
      { letra: "a", texto: "prescritivel e afiancavel." },
      { letra: "b", texto: "imprescritivel e inafiancavel." },
      { letra: "c", texto: "prescritivel e inafiancavel." },
      { letra: "d", texto: "imprescritivel e afiancavel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Por equiparacao ao racismo (art. 5, XLII, CF), a injuria racial e imprescritivel e inafiancavel.",
  },
  {
    id: 41,
    fonte: "OAB - L Exame",
    enunciado:
      'Carlos, em rede social, escreve: "O deputado e um vagabundo que so rouba o povo". O deputado processa por injuria. Carlos',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, pois e critica politica protegida." },
      { letra: "c", texto: "responde por calunia." },
      { letra: "d", texto: "responde por difamacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      '"Vagabundo" e "rouba o povo" sao criticas genericas politicas, protegidas pela liberdade de expressao, desde que nao haja imputacao de fato criminoso especifico. Nao configura injuria.',
  },
  {
    id: 42,
    fonte: "TJ-PE - 2022",
    enunciado: "Calunia contra morto pode ser proposta por",
    alternativas: [
      { letra: "a", texto: "qualquer pessoa." },
      { letra: "b", texto: "apenas o conjuge." },
      { letra: "c", texto: "parentes em linha reta ou colateral ate 4 grau." },
      { letra: "d", texto: "apenas herdeiros." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 138, par. 2: a queixa pode ser proposta por parentes em linha reta ou colateral ate 4 grau.",
  },
  {
    id: 43,
    fonte: "OAB - LI Exame",
    enunciado:
      'Ana, em conversa privada, diz a amiga: "Maria e uma mentirosa, ja me enganou varias vezes". Maria descobre e processa por difamacao. Ana',
    alternativas: [
      { letra: "a", texto: "nao responde, pois foi conversa privada." },
      { letra: "b", texto: "responde por difamacao." },
      { letra: "c", texto: "responde por injuria." },
      { letra: "d", texto: "responde por calunia." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Difamacao nao exige publicidade. Basta que a imputacao chegue a terceiro (a amiga). Imputar fato ofensivo a reputacao ("mentirosa", "enganou") configura difamacao.',
  },
  {
    id: 44,
    fonte: "MPE-MA - 2021",
    enunciado: "No crime de injuria real, a violencia",
    alternativas: [
      { letra: "a", texto: "deve causar lesao corporal." },
      { letra: "b", texto: "deve ser anterior a ofensa." },
      { letra: "c", texto: "deve vincular-se a injuria." },
      { letra: "d", texto: "pode ser apenas verbal." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A violencia ou vias de fato devem vincular-se a injuria, ou seja, fazer parte do mesmo contexto ofensivo (art. 140, par. 2).",
  },
  {
    id: 45,
    fonte: "OAB - LII Exame",
    enunciado:
      'Blogueiro escreve: "O empresario e sonegador de impostos". O empresario processa por calunia. O blogueiro prova que o empresario foi condenado por sonegacao. O blogueiro',
    alternativas: [
      { letra: "a", texto: "responde por calunia." },
      { letra: "b", texto: "nao responde, devido a exceptio veritatis." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde por injuria." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sonegacao fiscal e crime. Provada a verdade (condenacao), aplica-se a exceptio veritatis da calunia. Nao ha crime.",
  },
  {
    id: 46,
    fonte: "PC-PA - 2023",
    enunciado: "A pena da difamacao e aumentada de 1/3 se praticada",
    alternativas: [
      { letra: "a", texto: "contra menor." },
      { letra: "b", texto: "com emprego de violencia." },
      { letra: "c", texto: "por meio que facilite a divulgacao." },
      { letra: "d", texto: "em local publico." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 141, III: aumento se o crime e cometido por meio que facilite a divulgacao (ex.: internet, radio, TV). E causa comum a todos crimes contra a honra.",
  },
  {
    id: 47,
    fonte: "OAB - LIII Exame",
    enunciado:
      'Advogado, em audiencia, diz a testemunha: "o senhor e um mentiroso contumaz". A testemunha processa por injuria. O advogado',
    alternativas: [
      { letra: "a", texto: "responde por injuria." },
      { letra: "b", texto: "nao responde, devido a imunidade funcional (art. 142, I)." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde apenas se ofendeu em publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ofensa irrogada em juizo, no exercicio da funcao, esta protegida pela imunidade do art. 142, I, desde que pertinente a discussao.",
  },
  {
    id: 48,
    fonte: "TJ-DF - 2022",
    enunciado: "No crime de calunia, a imputacao de fato contravencional",
    alternativas: [
      { letra: "a", texto: "configura calunia." },
      { letra: "b", texto: "configura difamacao." },
      { letra: "c", texto: "configura injuria." },
      { letra: "d", texto: "nao e crime contra a honra." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Calunia exige fato definido como crime. Se for contravencao, e difamacao (art. 139), pois e fato ofensivo a reputacao.",
  },
  {
    id: 49,
    fonte: "OAB - LIV Exame",
    enunciado:
      'Radio divulga que "o medico da cidade e incompetente e ja matou varios pacientes". O medico processa por calunia. A radio prova que o medico teve tres processos por erro medico. A radio',
    alternativas: [
      { letra: "a", texto: "nao responde, pois provou a verdade." },
      { letra: "b", texto: "responde por calunia, pois 'matar' e crime." },
      { letra: "c", texto: "responde por difamacao." },
      { letra: "d", texto: "responde por injuria." },
    ],
    respostaCorreta: "b",
    explicacao:
      '"Matar" e imputacao de crime (homicidio). A radio provou processos por erro medico, nao homicidio. A falsidade persiste. E calunia. A pena pode ser aumentada pelo meio de divulgacao (art. 141, III).',
  },
  {
    id: 50,
    fonte: "MPE-GO - 2023",
    enunciado:
      "Ofensa ao chefe de governo estrangeiro em visita ao Brasil tem acao penal",
    alternativas: [
      { letra: "a", texto: "privada." },
      { letra: "b", texto: "publica incondicionada." },
      { letra: "c", texto: "publica condicionada a requisicao do Ministro da Justica." },
      { letra: "d", texto: "publica condicionada a representacao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 145, par. 1: ofensa a chefe de governo estrangeiro tem acao penal publica condicionada a requisicao do Ministro da Justica, igual ao Presidente da Republica.",
  },
];
