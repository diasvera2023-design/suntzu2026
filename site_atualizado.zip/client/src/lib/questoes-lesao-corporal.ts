import { type Questao } from "./questoes-vida";

export const questoesLesaoCorporal: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXIX Exame",
    enunciado:
      "Durante uma discussao, Joao desfere um soco no rosto de Pedro, que sofre uma fratura no nariz. A conduta de Joao configura",
    alternativas: [
      { letra: "a", texto: "lesao corporal grave, por ter causado debilidade permanente." },
      { letra: "b", texto: "lesao corporal leve, pois nao houve risco de vida." },
      { letra: "c", texto: "lesao corporal grave, por ter sido em face." },
      { letra: "d", texto: "lesao corporal leve, pois fratura no nariz nao e grave." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lesao em face, sem mais elementos, e lesao leve (art. 129, caput). Para ser grave (art. 129, \u00a71\u00ba), precisa preencher um dos incisos (ex.: incapacidade para ocupacoes habituais por mais de 30 dias, perigo de vida, debilidade permanente, etc.). Fratura no nariz, por si so, nao e necessariamente grave.",
  },
  {
    id: 2,
    fonte: "PC-DF - 2021",
    enunciado:
      "Lesao corporal gravissima (art. 129, \u00a72\u00ba) inclui a lesao que causa",
    alternativas: [
      { letra: "a", texto: "incapacidade para o trabalho por 30 dias." },
      { letra: "b", texto: "perigo de vida." },
      { letra: "c", texto: "enfermidade incuravel." },
      { letra: "d", texto: "ofensa a integridade estetica." },
    ],
    respostaCorreta: "c",
    explicacao:
      'Lesao gravissima (art. 129, \u00a72\u00ba) inclui: perda ou inutilizacao de membro, sentido ou funcao; incapacidade permanente para o trabalho; enfermidade incuravel; deformidade permanente; ou aborto. "Perigo de vida" e lesao grave (\u00a71\u00ba, I).',
  },
  {
    id: 3,
    fonte: "OAB - XXX Exame",
    enunciado:
      "Em uma briga de transito, Marcos agride Paulo, que sofre concussao cerebral e fica em coma por uma semana. A lesao e considerada",
    alternativas: [
      { letra: "a", texto: "leve, pois nao houve deformidade." },
      { letra: "b", texto: "grave, por ter causado perigo de vida." },
      { letra: "c", texto: "gravissima, por ter causado enfermidade incuravel." },
      { letra: "d", texto: "culposa, pois nao houve intencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Coma com perigo de vida caracteriza lesao grave pelo art. 129, \u00a71\u00ba, I (perigo de vida). Para ser gravissima, exigiria consequencias mais permanentes (ex.: lesao cerebral permanente incuravel).",
  },
  {
    id: 4,
    fonte: "TJ-SP - 2020",
    enunciado:
      "A lesao corporal culposa (art. 129, \u00a76\u00ba) tem sua pena aumentada de 1/3 se",
    alternativas: [
      { letra: "a", texto: "o agente deixa de prestar socorro." },
      { letra: "b", texto: "a vitima e menor de 14 anos." },
      { letra: "c", texto: "o crime e praticado no transito." },
      { letra: "d", texto: "resulta em lesao grave." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 129, \u00a76\u00ba, preve aumento de pena de 1/3 se, na lesao culposa, o agente nao presta socorro a vitima, nao procura diminuir as consequencias do fato, ou foge para evitar prisao em flagrante.",
  },
  {
    id: 5,
    fonte: "OAB - XXXI Exame",
    enunciado:
      "Maria, apos ser agredida pelo marido, sofre perda permanente da visao de um olho. A lesao e classificada como",
    alternativas: [
      { letra: "a", texto: "lesao corporal grave." },
      { letra: "b", texto: "lesao corporal gravissima." },
      { letra: "c", texto: "lesao corporal seguida de morte." },
      { letra: "d", texto: "lesao corporal com violencia domestica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Perda ou inutilizacao de sentido (visao) e hipotese de lesao gravissima (art. 129, \u00a72\u00ba, I). A violencia domestica (art. 129, \u00a79\u00ba) e qualificadora que pode coexistir, mas a gravidade e definida pelo \u00a72\u00ba.",
  },
  {
    id: 6,
    fonte: "MPE-RS - 2022",
    enunciado:
      "No crime de lesao corporal seguida de morte (art. 129, \u00a73\u00ba), o agente",
    alternativas: [
      { letra: "a", texto: "responde por homicidio doloso." },
      { letra: "b", texto: "tem dolo na lesao e culpa na morte." },
      { letra: "c", texto: "tem culpa tanto na lesao quanto na morte." },
      { letra: "d", texto: "responde por homicidio preterdoloso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lesao seguida de morte e crime preterdoloso: dolo na lesao (qualquer gravidade) e culpa no resultado morte superveniente. Difere do homicidio doloso, onde ha dolo na morte.",
  },
  {
    id: 7,
    fonte: "OAB - XXXII Exame",
    enunciado:
      "Carlos, em briga de bar, fere Luis com um caco de vidro, causando-lhe corte profundo que exige 45 dias de recuperacao, impedindo-o de trabalhar. A lesao e",
    alternativas: [
      { letra: "a", texto: "leve, pois nao ha deformidade." },
      { letra: "b", texto: "grave, por incapacidade laborativa por mais de 30 dias." },
      { letra: "c", texto: "gravissima, por ter usado instrumento cortante." },
      { letra: "d", texto: "qualificada pelo uso de arma." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Incapacidade para as ocupacoes habituais por mais de 30 dias caracteriza lesao grave (art. 129, \u00a71\u00ba, II). O uso de instrumento (caco de vidro) pode ser agravante especifico, mas nao altera a classificacao da gravidade.",
  },
  {
    id: 8,
    fonte: "PC-PR - 2023",
    enunciado:
      "Lesao corporal contra a mulher por razoes da condicao de sexo feminino (art. 129, \u00a713) exige que",
    alternativas: [
      { letra: "a", texto: "a vitima seja mulher e o agente, homem." },
      { letra: "b", texto: "o crime seja cometido no ambito domestico." },
      { letra: "c", texto: "haja motivo relacionado ao genero da vitima." },
      { letra: "d", texto: "a lesao seja grave ou gravissima." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A qualificadora do \u00a713 (incluida pela Lei 14.188/2021) exige que a lesao seja cometida contra a mulher por razoes da condicao de sexo feminino (ex.: violencia de genero, menosprezo a condicao de mulher). Nao exige lesao de determinada gravidade.",
  },
  {
    id: 9,
    fonte: "OAB - XXXIII Exame",
    enunciado:
      "Joao, ao tentar conter uma briga, acaba empurrando Pedro, que cai e fratura o braco, necessitando de gesso por 40 dias. Nao havia intencao de machucar. Joao responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal dolosa grave." },
      { letra: "b", texto: "lesao corporal culposa grave." },
      { letra: "c", texto: "lesao corporal leve culposa." },
      { letra: "d", texto: "nada, pois agiu em estado de necessidade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sem dolo, a lesao e culposa. A gravidade (incapacidade >30 dias) a torna grave. Aplica-se o art. 129, \u00a76\u00ba (lesao culposa), com pena de detencao, de 2 meses a 2 anos, aumentada se for grave.",
  },
  {
    id: 10,
    fonte: "TJ-RJ - 2021",
    enunciado:
      "A lesao corporal privilegiada (art. 129, \u00a74\u00ba) ocorre quando",
    alternativas: [
      { letra: "a", texto: "a vitima e parente do agente." },
      { letra: "b", texto: "o agente age sob violenta emocao, logo apos injusta provocacao." },
      { letra: "c", texto: "o crime e cometido em duelo." },
      { letra: "d", texto: "ha arrependimento eficaz." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A lesao privilegiada (\u00a74\u00ba) exige que o agente cometa o crime sob violenta emocao, logo em seguida a injusta provocacao da vitima. Reduz a pena de 1/6 a 1/3.",
  },
  {
    id: 11,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      "Medico, por impericia, causa a perda da funcao de um rim do paciente durante cirurgia. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima culposa." },
      { letra: "b", texto: "lesao corporal grave dolosa." },
      { letra: "c", texto: "crime de exercicio ilegal da medicina." },
      { letra: "d", texto: "nada, pois assumiu os riscos da cirurgia." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Perda de funcao de orgao (rim) e lesao gravissima (\u00a72\u00ba). Por impericia, e culposa (\u00a76\u00ba). O fato de ser medico nao exclui a responsabilidade, a menos que comprove caso fortuito ou forca maior.",
  },
  {
    id: 12,
    fonte: "MPE-MG - 2020",
    enunciado:
      "No crime de lesao corporal de natureza grave (art. 129, \u00a71\u00ba), a acao penal e",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Lesao corporal grave, gravissima, seguida de morte e com violencia domestica tem acao penal publica incondicionada (art. 129, \u00a711). Lesao leve (caput) e publica condicionada a representacao.",
  },
  {
    id: 13,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Ana, durante discussao com sua vizinha, desfere um tapa que causa um hematoma no rosto. A vizinha nao precisa de tratamento medico. A conduta de Ana configura",
    alternativas: [
      { letra: "a", texto: "lesao corporal leve de acao publica incondicionada." },
      { letra: "b", texto: "injuria real." },
      { letra: "c", texto: "lesao corporal leve de acao publica condicionada a representacao." },
      { letra: "d", texto: "contravencao de vias de fato." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Hematoma sem necessidade de tratamento caracteriza lesao leve (caput). A acao penal e publica condicionada a representacao (\u00a710). Injuria real exige ofensa a honra; vias de fato e contravencao que exige reciprocidade.",
  },
  {
    id: 14,
    fonte: "PC-SP - 2022",
    enunciado:
      "Lesao corporal que causa deformidade permanente configura",
    alternativas: [
      { letra: "a", texto: "lesao grave." },
      { letra: "b", texto: "lesao gravissima." },
      { letra: "c", texto: "lesao qualificada." },
      { letra: "d", texto: "lesao privilegiada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Deformidade permanente e hipotese de lesao gravissima (art. 129, \u00a72\u00ba, IV).",
  },
  {
    id: 15,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Carlos, ao reagir a um assalto, atira no assaltante, causando-lhe lesao que o deixa paraplegico. Na legitima defesa, a lesao",
    alternativas: [
      { letra: "a", texto: "e justificada, nao havendo crime." },
      { letra: "b", texto: "configura lesao gravissima dolosa." },
      { letra: "c", texto: "e excesso punivel como lesao culposa." },
      { letra: "d", texto: "deve ser considerada lesao grave privilegiada." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Na legitima defesa (art. 23, II, CP), o fato e licito, excluindo a ilicitude. Nao ha crime, desde que presentes os requisitos (agressao injusta, necessidade, moderada).",
  },
  {
    id: 16,
    fonte: "TJ-MG - 2019",
    enunciado:
      "A lesao corporal culposa no transito",
    alternativas: [
      { letra: "a", texto: "e sempre absorvida pelo crime do CTB." },
      { letra: "b", texto: "aplica-se o art. 129, \u00a76\u00ba, subsidiariamente." },
      { letra: "c", texto: "e regida exclusivamente pelo CTB." },
      { letra: "d", texto: "so configura crime se houver embriaguez." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Lesao corporal culposa na direcao de veiculo automotor e regida pelo Codigo de Transito Brasileiro (art. 303, CTB), que e lei especial e prevalece sobre o CP (art. 12, CP).",
  },
  {
    id: 17,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Pai, ao disciplinar filho de 10 anos, aplica castigo fisico que causa hematomas. A conduta",
    alternativas: [
      { letra: "a", texto: "e legitima correcao disciplinar." },
      { letra: "b", texto: "configura lesao corporal leve." },
      { letra: "c", texto: "configura violencia domestica." },
      { letra: "d", texto: "e atipica por ser relacao familiar." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Castigo fisico que causa lesao configura lesao corporal. Se ocorre no ambito familiar, tambem configura violencia domestica (art. 129, \u00a79\u00ba). A "palmada pedagogica" nao e causa de exclusao da ilicitude. A alternativa B e a mais completa para fins de concurso.',
  },
  {
    id: 18,
    fonte: "MPE-ES - 2023",
    enunciado:
      "Lesao corporal que causa aborto sem intencao de provoca-lo configura",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima." },
      { letra: "b", texto: "crime de aborto culposo." },
      { letra: "c", texto: "lesao corporal seguida de morte." },
      { letra: "d", texto: "lesao corporal qualificada." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Causar aborto como resultado de lesao corporal, sem dolo no aborto, caracteriza lesao corporal gravissima (art. 129, \u00a72\u00ba, V), nao crime de aborto.",
  },
  {
    id: 19,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Medico, ao realizar cirurgia estetica, causa grande cicatriz deformante no paciente por erro tecnico. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima culposa." },
      { letra: "b", texto: "lesao corporal grave dolosa." },
      { letra: "c", texto: "crime contra a saude publica." },
      { letra: "d", texto: "improbidade administrativa se for medico publico." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Deformidade permanente por impericia medica configura lesao gravissima culposa (\u00a72\u00ba, IV c/c \u00a76\u00ba). Nao ha dolo, pois foi erro tecnico.",
  },
  {
    id: 20,
    fonte: "PC-CE - 2021",
    enunciado:
      "Lesao corporal com uso de arma de fogo (art. 129, \u00a77\u00ba) tem pena",
    alternativas: [
      { letra: "a", texto: "aumentada de 1/3." },
      { letra: "b", texto: "aumentada de metade." },
      { letra: "c", texto: "em dobro." },
      { letra: "d", texto: "de reclusao, nao detencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      'O \u00a77\u00ba estabelece: "Se a lesao e praticada com arma de fogo, a pena e aumentada de metade." E uma causa de aumento especifica.',
  },
  {
    id: 21,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Joao, em briga, fere Pedro com faca, causando lesao que o deixa 20 dias incapaz para o trabalho. A lesao e",
    alternativas: [
      { letra: "a", texto: "leve, pois incapacidade foi inferior a 30 dias." },
      { letra: "b", texto: "grave, por ter sido com arma branca." },
      { letra: "c", texto: "gravissima, por ter risco de vida." },
      { letra: "d", texto: "qualificada pelo uso de arma." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Incapacidade inferior a 30 dias e lesao leve (caput). O uso de faca e causa de aumento de pena (art. 129, \u00a77\u00ba, se for arma de fogo) ou pode configurar qualificadora se houver dolo de utilizar meio cruel, mas nao altera a classificacao da gravidade.",
  },
  {
    id: 22,
    fonte: "TJ-PE - 2022",
    enunciado:
      "A lesao corporal culposa (art. 129, \u00a76\u00ba) tem pena de",
    alternativas: [
      { letra: "a", texto: "detencao, de 3 meses a 1 ano." },
      { letra: "b", texto: "detencao, de 2 meses a 2 anos." },
      { letra: "c", texto: "reclusao, de 1 a 3 anos." },
      { letra: "d", texto: "detencao, de 6 meses a 3 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Pena-base da lesao culposa: detencao, de 2 meses a 2 anos. Aumenta-se se for grave ou gravissima.",
  },
  {
    id: 23,
    fonte: "OAB - XL Exame",
    enunciado:
      "Maria, sob violenta emocao apos ser ofendida por Clara, desfere um soco que causa fratura no dedo da ofensora. Maria responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal grave." },
      { letra: "b", texto: "lesao corporal privilegiada." },
      { letra: "c", texto: "lesao corporal leve." },
      { letra: "d", texto: "lesao corporal com aumento por violenta emocao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lesao cometida sob violenta emocao, logo apos injusta provocacao caracteriza lesao privilegiada (art. 129, \u00a74\u00ba), com reducao de pena de 1/6 a 1/3.",
  },
  {
    id: 24,
    fonte: "MPE-BA - 2023",
    enunciado:
      "No crime de lesao corporal seguida de morte (art. 129, \u00a73\u00ba), a pena e de",
    alternativas: [
      { letra: "a", texto: "reclusao, de 4 a 12 anos." },
      { letra: "b", texto: "reclusao, de 2 a 8 anos." },
      { letra: "c", texto: "detencao, de 2 a 8 anos." },
      { letra: "d", texto: "reclusao, de 6 a 20 anos." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Lesao seguida de morte: reclusao, de 4 a 12 anos (\u00a73\u00ba). E pena mais branda que o homicidio doloso (6 a 20 anos), pois ha apenas culpa na morte.",
  },
  {
    id: 25,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Carlos, dirigindo embriagado, atropela pedestre, que sofre lesoes graves. Carlos responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal grave culposa." },
      { letra: "b", texto: "tentativa de homicidio." },
      { letra: "c", texto: "lesao corporal dolosa grave." },
      { letra: "d", texto: "homicidio culposo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Embriaguez ao volante e imprudencia (culpa). Lesoes graves configuram lesao corporal grave culposa. O crime e do CTB (art. 303), nao do CP.",
  },
  {
    id: 26,
    fonte: "PC-RJ - 2020",
    enunciado:
      "Lesao corporal que causa doenca profissional incuravel configura",
    alternativas: [
      { letra: "a", texto: "lesao grave." },
      { letra: "b", texto: "lesao gravissima." },
      { letra: "c", texto: "lesao culposa." },
      { letra: "d", texto: "lesao com aumento." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Enfermidade incuravel e hipotese de lesao gravissima (art. 129, \u00a72\u00ba, III).",
  },
  {
    id: 27,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Policial, em legitima defesa, atira em assaltante, causando lesao que o deixa cego de um olho. O policial",
    alternativas: [
      { letra: "a", texto: "responde por lesao gravissima em excesso." },
      { letra: "b", texto: "nao comete crime, pois agiu em legitima defesa." },
      { letra: "c", texto: "responde por lesao gravissima dolosa." },
      { letra: "d", texto: "responde por homicidio tentado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Na legitima defesa regular, o fato e licito, mesmo que o resultado seja gravissimo. So havera crime se houver excesso (art. 23, paragrafo unico).",
  },
  {
    id: 28,
    fonte: "TJ-PR - 2021",
    enunciado:
      "A lesao corporal com violencia domestica (art. 129, \u00a79\u00ba) tem pena",
    alternativas: [
      { letra: "a", texto: "aumentada de 1/3." },
      { letra: "b", texto: "aumentada de metade." },
      { letra: "c", texto: "em dobro." },
      { letra: "d", texto: "triplicada." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A pena e aumentada de 1/3 se a lesao e cometida contra ascendente, descendente, irmao, conjuge ou companheiro, ou com quem conviva ou tenha convivido, ou, ainda, prevalecendo-se o agente das relacoes domesticas.",
  },
  {
    id: 29,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Medico, por erro de dosagem, administra medicamento que causa doenca hepatica incuravel no paciente. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima culposa." },
      { letra: "b", texto: "lesao corporal grave dolosa." },
      { letra: "c", texto: "crime de exercicio ilegal da medicina." },
      { letra: "d", texto: "homicidio culposo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Doenca incuravel e lesao gravissima (\u00a72\u00ba, III). Por erro, e culposa (\u00a76\u00ba). Nao ha dolo, nem homicidio (pois nao houve morte).",
  },
  {
    id: 30,
    fonte: "MPE-PI - 2022",
    enunciado:
      "Lesao corporal leve (art. 129, caput) tem acao penal",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lesao leve: acao penal publica condicionada a representacao (\u00a710). O ofendido tem 6 meses para representar.",
  },
  {
    id: 31,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Joao, em discussao, da um soco em Pedro, que cai e bate a cabeca, vindo a falecer. Joao nao quis a morte. Ele responde por",
    alternativas: [
      { letra: "a", texto: "homicidio doloso." },
      { letra: "b", texto: "lesao corporal seguida de morte." },
      { letra: "c", texto: "homicidio culposo." },
      { letra: "d", texto: "lesao corporal grave." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Dolo na lesao (soco) + culpa na morte (queda) = lesao corporal seguida de morte (art. 129, \u00a73\u00ba). Se nao houve lesao visivel antes da queda, pode ser homicidio culposo.",
  },
  {
    id: 32,
    fonte: "PC-MG - 2023",
    enunciado:
      "Lesao corporal que causa incapacidade permanente para o trabalho e",
    alternativas: [
      { letra: "a", texto: "lesao grave." },
      { letra: "b", texto: "lesao gravissima." },
      { letra: "c", texto: "lesao com aumento." },
      { letra: "d", texto: "lesao qualificada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Incapacidade permanente para o trabalho e hipotese de lesao gravissima (art. 129, \u00a72\u00ba, II).",
  },
  {
    id: 33,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Ana, em legitima defesa, ataca agressor, mas excede os limites, causando-lhe lesao grave. Ana responde por",
    alternativas: [
      { letra: "a", texto: "nada, pois agiu em legitima defesa." },
      { letra: "b", texto: "lesao corporal grave em excesso doloso." },
      { letra: "c", texto: "lesao corporal grave culposa." },
      { letra: "d", texto: "homicidio tentado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Excesso na legitima defesa, se doloso, e punivel (art. 23, paragrafo unico). Responde por lesao grave dolosa, com pena diminuida de 1/3 a metade.",
  },
  {
    id: 34,
    fonte: "TJ-SC - 2020",
    enunciado:
      'No crime de lesao corporal, a "ofensa a saude" inclui',
    alternativas: [
      { letra: "a", texto: "apenas doencas fisicas." },
      { letra: "b", texto: "doencas fisicas e perturbacoes psiquicas." },
      { letra: "c", texto: "apenas traumas fisicos." },
      { letra: "d", texto: "doencas contagiosas." },
    ],
    respostaCorreta: "b",
    explicacao:
      '"Ofensa a saude" abrange tanto a saude fisica quanto a saude mental (perturbacoes psiquicas, neurose traumatica, etc.).',
  },
  {
    id: 35,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Carlos, apos ser provocado, desfere varios socos em Paulo, que fica com o braco imobilizado por 35 dias. Carlos responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal grave." },
      { letra: "b", texto: "lesao corporal leve." },
      { letra: "c", texto: "lesao corporal privilegiada." },
      { letra: "d", texto: "lesao corporal com violencia." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Incapacidade >30 dias = lesao grave (\u00a71\u00ba, II). A violenta emocao pode configurar privilegiada (\u00a74\u00ba), mas nao altera a gravidade.",
  },
  {
    id: 36,
    fonte: "MPE-RN - 2021",
    enunciado:
      "Lesao corporal com uso de arma branca (ex.: faca)",
    alternativas: [
      { letra: "a", texto: "sempre configura lesao grave." },
      { letra: "b", texto: "tem aumento de pena como arma de fogo." },
      { letra: "c", texto: "pode configurar meio cruel, qualificando a lesao." },
      { letra: "d", texto: "e lesao gravissima." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O uso de arma branca pode configurar meio cruel (art. 129, \u00a71\u00ba, V), qualificando a lesao como grave, se houver dolo de utilizar meio que cause sofrimento. Nao ha aumento automatico como para arma de fogo (\u00a77\u00ba).",
  },
  {
    id: 37,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Medico, durante parto, causa lesao no bebe que o deixa com paralisia cerebral. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima culposa." },
      { letra: "b", texto: "homicidio culposo." },
      { letra: "c", texto: "lesao corporal dolosa." },
      { letra: "d", texto: "crime de aborto." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Paralisia cerebral e enfermidade incuravel ou incapacidade permanente = lesao gravissima. Por impericia, e culposa. Bebe nascido com vida e sujeito passivo de lesao corporal.",
  },
  {
    id: 38,
    fonte: "PC-PA - 2022",
    enunciado:
      "A lesao corporal culposa com resultado morte",
    alternativas: [
      { letra: "a", texto: "configura homicidio culposo." },
      { letra: "b", texto: "configura lesao corporal seguida de morte." },
      { letra: "c", texto: "e absorvida pelo homicidio." },
      { letra: "d", texto: "tem pena igual a do homicidio culposo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Se o agente age com culpa tanto na conduta quanto no resultado morte, e homicidio culposo (art. 121, \u00a73\u00ba). Lesao seguida de morte exige dolo na lesao + culpa na morte.",
  },
  {
    id: 39,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Paulo, em briga, fere Mario com um taco de baseball, causando lesao que exige 25 dias de recuperacao. A lesao e",
    alternativas: [
      { letra: "a", texto: "leve, com aumento por uso de instrumento." },
      { letra: "b", texto: "grave, por uso de meio cruel." },
      { letra: "c", texto: "gravissima, por risco de vida." },
      { letra: "d", texto: "leve, sem qualificadora." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Incapacidade <30 dias = lesao leve (caput). O uso de taco pode caracterizar meio cruel se houver dolo nisso, mas a questao nao indica que qualificou como grave. Como lesao e leve, nao ha qualificadora de gravidade.",
  },
  {
    id: 40,
    fonte: "TJ-AM - 2023",
    enunciado:
      "Lesao corporal contra idoso (acima de 60 anos) tem",
    alternativas: [
      { letra: "a", texto: "aumento de pena de 1/3." },
      { letra: "b", texto: "pena em dobro." },
      { letra: "c", texto: "qualificadora especifica." },
      { letra: "d", texto: "nenhum agravante especifico." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 129, \u00a78\u00ba, preve aumento de pena de 1/3 se o crime e cometido contra pessoa maior de 60 anos, menor de 18 anos, ou portadora de deficiencia.",
  },
  {
    id: 41,
    fonte: "OAB - XLIX Exame",
    enunciado:
      'Claudia, apos ser chamada de "ladra" por vizinha, desfere um soco que causa fratura no maxilar, com 45 dias de incapacidade. Claudia responde por',
    alternativas: [
      { letra: "a", texto: "lesao corporal grave." },
      { letra: "b", texto: "lesao corporal privilegiada." },
      { letra: "c", texto: "injuria real." },
      { letra: "d", texto: "lesao corporal grave privilegiada." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Incapacidade >30 dias = lesao grave (\u00a71\u00ba, II). A injusta provocacao (injuria) pode gerar violenta emocao, configurando privilegiada (\u00a74\u00ba). Sao aplicaveis cumulativamente.",
  },
  {
    id: 42,
    fonte: "MPE-TO - 2021",
    enunciado:
      "Lesao corporal culposa que resulta em lesao gravissima tem pena",
    alternativas: [
      { letra: "a", texto: "igual a lesao gravissima dolosa." },
      { letra: "b", texto: "aumentada em relacao a lesao culposa simples." },
      { letra: "c", texto: "diminuida por ser culposa." },
      { letra: "d", texto: "de reclusao, nao detencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A pena da lesao culposa aumenta-se se o resultado e lesao grave ou gravissima (art. 129, \u00a76\u00ba, in fine). A pena-base e a mesma (detencao, 2 meses a 2 anos), com aumento.",
  },
  {
    id: 43,
    fonte: "OAB - L Exame",
    enunciado:
      "Policial, ao prender infrator, usa forca excessiva e fratura seu braco. O policial responde por",
    alternativas: [
      { letra: "a", texto: "nada, pois agiu no exercicio da funcao." },
      { letra: "b", texto: "lesao corporal grave em excesso de exacao." },
      { letra: "c", texto: "abuso de autoridade." },
      { letra: "d", texto: "lesao corporal culposa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Excesso na execucao do dever legal (excesso de exacao) e punivel. Fratura com incapacidade >30 dias e lesao grave. Se houve dolo no excesso, e dolosa; se culpa, culposa.",
  },
  {
    id: 44,
    fonte: "PC-GO - 2022",
    enunciado:
      "A lesao corporal com violencia domestica contra a mulher (Lei Maria da Penha)",
    alternativas: [
      { letra: "a", texto: "exige que o agente seja homem." },
      { letra: "b", texto: "tem acao penal publica incondicionada." },
      { letra: "c", texto: "depende de representacao da vitima." },
      { letra: "d", texto: "so se aplica a casados." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lesao com violencia domestica (art. 129, \u00a79\u00ba) tem acao penal publica incondicionada (\u00a711), independentemente do genero do agente. Aplica-se a relacoes familiares ou afetivas.",
  },
  {
    id: 45,
    fonte: "OAB - LI Exame",
    enunciado:
      "Joao, ao defender-se de agressao, fere o agressor com canivete, causando corte que necessita de 15 pontos. A lesao e",
    alternativas: [
      { letra: "a", texto: "grave, por uso de arma branca." },
      { letra: "b", texto: "leve, com aumento por uso de meio cruel." },
      { letra: "c", texto: "gravissima, por risco de vida." },
      { letra: "d", texto: "leve, salvo se qualificada." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Corte com pontos, sem incapacidade >30 dias ou outros elementos, e lesao leve. O uso de canivete pode qualificar como meio cruel (se houve dolo nisso), tornando-a grave (\u00a71\u00ba, V).",
  },
  {
    id: 46,
    fonte: "TJ-DF - 2023",
    enunciado:
      "Lesao corporal que causa perda de funcao de um membro (ex.: braco paralisado) e",
    alternativas: [
      { letra: "a", texto: "lesao grave." },
      { letra: "b", texto: "lesao gravissima." },
      { letra: "c", texto: "lesao com aumento." },
      { letra: "d", texto: "lesao qualificada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Perda ou inutilizacao de funcao de membro e lesao gravissima (art. 129, \u00a72\u00ba, I).",
  },
  {
    id: 47,
    fonte: "OAB - LII Exame",
    enunciado:
      "Medico, por erro de diagnostico, receita medicamento que causa doenca renal cronica no paciente. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima culposa." },
      { letra: "b", texto: "homicidio culposo." },
      { letra: "c", texto: "lesao corporal dolosa." },
      { letra: "d", texto: "crime de exercicio ilegal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Doenca cronica incuravel = lesao gravissima. Erro de diagnostico e culpa (impericia). Nao ha dolo.",
  },
  {
    id: 48,
    fonte: "MPE-PA - 2020",
    enunciado:
      "Lesao corporal com emprego de veneno (art. 129, \u00a71\u00ba, V)",
    alternativas: [
      { letra: "a", texto: "sempre causa lesao grave." },
      { letra: "b", texto: "e qualificadora de meio cruel." },
      { letra: "c", texto: "exige dolo especifico de usar veneno." },
      { letra: "d", texto: "e lesao gravissima." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Emprego de veneno e meio cruel, qualificando a lesao como grave (\u00a71\u00ba, V), desde que haja dolo de utilizar meio que cause sofrimento.",
  },
  {
    id: 49,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Carlos, em discussao, joga agua fervente em Pedro, causando queimaduras de 2\u00ba grau. A lesao e",
    alternativas: [
      { letra: "a", texto: "leve, pois nao ha risco de vida." },
      { letra: "b", texto: "grave, por meio cruel." },
      { letra: "c", texto: "gravissima, por deformidade." },
      { letra: "d", texto: "qualificada por uso de liquido quente." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Agua fervente e meio cruel, qualificando como lesao grave (\u00a71\u00ba, V), independentemente da gravidade da queimadura. Se causar deformidade permanente, sera gravissima (\u00a72\u00ba, IV).",
  },
  {
    id: 50,
    fonte: "PC-MS - 2023",
    enunciado:
      "Lesao corporal praticada em duelo (art. 129, \u00a75\u00ba) tem pena",
    alternativas: [
      { letra: "a", texto: "aumentada de 1/3." },
      { letra: "b", texto: "aumentada de metade." },
      { letra: "c", texto: "diminuida de 1/3 a metade." },
      { letra: "d", texto: "igual a lesao simples." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Lesao em duelo, se nao houver morte, tem pena diminuida de 1/3 a metade (\u00a75\u00ba). E uma causa de diminuicao de pena especifica.",
  },
];
