import { type Questao } from "./questoes-vida";

export const questoesPropriedadeImaterial: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Joao, sem autorizacao, reproduz integralmente um livro best-seller e vende as copias a preco baixo. A conduta configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral qualificada pelo intuito de lucro (art. 184, par. 1, CP)." },
      { letra: "b", texto: "violacao de direito autoral simples." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "concorrencia desleal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Reproduzir obra intelectual com intuito de lucro caracteriza a qualificadora do par. 1 do art. 184, com pena de reclusao de 2 a 4 anos. O lucro nao precisa ser efetivo, basta o intuito.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2022",
    enunciado:
      "No crime de violacao de direito autoral, a exclusao de tipicidade para copia de pequenos trechos (art. 184, par. 4)",
    alternativas: [
      { letra: "a", texto: "aplica-se apenas a obras literarias." },
      { letra: "b", texto: "exige que a copia seja para uso privado." },
      { letra: "c", texto: "permite copia integral se sem fins lucrativos." },
      { letra: "d", texto: "autoriza a reproducao para distribuicao gratuita." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O par. 4 exclui a tipicidade para copia em um so exemplar, de pequenos trechos, para uso privado do copista, sem intuito de lucro. E uma excecao limitada.",
  },
  {
    id: 3,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Maria baixa musicas protegidas por direitos autorais da internet e as compartilha em rede peer-to-peer (P2P) sem fins lucrativos. A conduta configura",
    alternativas: [
      { letra: "a", texto: "crime de violacao de direito autoral qualificado por oferta ao publico (art. 184, par. 3)." },
      { letra: "b", texto: "crime de pirataria nao tipificado." },
      { letra: "c", texto: "uso privado permitido." },
      { letra: "d", texto: "contravencao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Oferecer obra ao publico mediante sistema de compartilhamento (P2P) caracteriza a qualificadora do par. 3, mesmo sem fins lucrativos. O simples compartilhamento configura oferta ao publico.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2023",
    enunciado: "Violar direito de autor consiste em",
    alternativas: [
      { letra: "a", texto: "apenas reproduzir obra sem autorizacao." },
      { letra: "b", texto: "violar direitos morais ou patrimoniais do autor." },
      { letra: "c", texto: "apenas plagiar obra alheia." },
      { letra: "d", texto: "usar obra sem pagar royalties." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O tipo penal abrange violacao de direitos autorais e conexos, incluindo direitos morais (paternidade, integridade) e patrimoniais (reproducao, distribuicao, etc.).",
  },
  {
    id: 5,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Livraria vende exemplares de obra literaria falsificada, sem saber que sao copias piratas. O dono da livraria",
    alternativas: [
      { letra: "a", texto: "responde por violacao de direito autoral qualificada (art. 184, par. 2)." },
      { letra: "b", texto: "nao responde, pois nao tinha ciencia." },
      { letra: "c", texto: "responde por receptacao." },
      { letra: "d", texto: "responde apenas se houver dolo." },
    ],
    respostaCorreta: "d",
    explicacao:
      "O crime exige dolo. Se o dono nao sabia que os exemplares eram falsificados, nao ha tipicidade. Se deveria saber, poderia configurar culpa, mas o tipo nao preve modalidade culposa.",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2021",
    enunciado:
      "Violar direito autoral de obra que ja caiu em dominio publico",
    alternativas: [
      { letra: "a", texto: "e crime, pois os direitos sao perpetuos." },
      { letra: "b", texto: "nao e crime, pois nao ha mais protecao legal." },
      { letra: "c", texto: "e crime apenas se houver plagiarismo." },
      { letra: "d", texto: "e crime contra o patrimonio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Dominio publico ocorre apos 70 anos da morte do autor (art. 41, Lei 9.610/98). A obra deixa de ser protegida por direitos patrimoniais; sua utilizacao nao configura crime.",
  },
  {
    id: 7,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Professor fotocopia capitulos de livro didatico protegido para distribuir a alunos, sem autorizacao. Nao ha fins lucrativos. A conduta",
    alternativas: [
      { letra: "a", texto: "e permitida para fins educacionais." },
      { letra: "b", texto: "configura violacao de direito autoral simples." },
      { letra: "c", texto: "configura violacao qualificada por intuito de lucro." },
      { letra: "d", texto: "e atipica pelo principio da insignificancia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Fotocopiar e distribuir ultrapassa o uso privado do par. 4. Mesmo sem fins lucrativos, viola o direito patrimonial de reproducao. Pode configurar crime simples (caput).",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2023",
    enunciado:
      "O crime de violacao de direito autoral qualificado pelo oferecimento ao publico via internet (art. 184, par. 3)",
    alternativas: [
      { letra: "a", texto: "exige intuito de lucro." },
      { letra: "b", texto: "nao exige intuito de lucro." },
      { letra: "c", texto: "so se aplica a obras musicais." },
      { letra: "d", texto: "exige que a obra seja integral." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A qualificadora do par. 3 (oferta ao publico via cabo, fibra, satelite, ondas ou qualquer outro sistema) nao exige intuito de lucro. Basta a disponibilizacao ao publico.",
  },
  {
    id: 9,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Carlos altera trechos de obra literaria alheia e publica como se fosse de sua autoria. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito moral de autoria (plagiarismo)." },
      { letra: "b", texto: "violacao apenas de direito patrimonial." },
      { letra: "c", texto: "crime de falsidade ideologica." },
      { letra: "d", texto: "ilicito civil, nao penal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Apropriar-se de obra alheia como propria viola o direito moral de paternidade (art. 24, Lei 9.610/98), tipificado no art. 184 do CP. E o plagiarismo.",
  },
  {
    id: 10,
    fonte: "PC-PR - 2022",
    enunciado:
      "Violar direitos conexos a direito autoral refere-se a",
    alternativas: [
      { letra: "a", texto: "direitos de artistas interpretes, produtores fonograficos e emissoras." },
      { letra: "b", texto: "direitos de patente industrial." },
      { letra: "c", texto: "direitos de marca registrada." },
      { letra: "d", texto: "direitos de imagem." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Direitos conexos sao dos artistas interpretes, produtores fonograficos e organismos de radiodifusao (arts. 89 a 95, Lei 9.610/98). Tambem protegidos pelo art. 184.",
  },
  {
    id: 11,
    fonte: "OAB - XL Exame",
    enunciado:
      "Loja vende DVDs piratas de filmes ainda em cartaz. O dono sabe da ilegalidade. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral simples." },
      { letra: "b", texto: "violacao qualificada por distribuicao de obra falsificada (art. 184, par. 2)." },
      { letra: "c", texto: "receptacao." },
      { letra: "d", texto: "concorrencia desleal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Vender obra intelectual falsificada caracteriza a qualificadora do par. 2, com pena de reclusao de 2 a 4 anos. E mais grave que a simples violacao.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2022",
    enunciado:
      "Violar direito autoral de software (programa de computador)",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois software nao e obra intelectual." },
      { letra: "b", texto: "e crime previsto na Lei de Software (Lei 9.609/98)." },
      { letra: "c", texto: "e crime apenas se houver reproducao para venda." },
      { letra: "d", texto: "e crime de propriedade industrial." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Software e protegido por lei especial (Lei 9.609/98), que preve crimes especificos. A violacao tambem pode ser enquadrada no art. 184, CP, mas a lei especial e mais especifica.",
  },
  {
    id: 13,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Radio comunitaria toca musicas protegidas sem autorizacao nem pagamento de direitos autorais. Configura",
    alternativas: [
      { letra: "a", texto: "uso gratuito permitido." },
      { letra: "b", texto: "violacao de direito autoral qualificada por oferta ao publico (art. 184, par. 3)." },
      { letra: "c", texto: "crime apenas se houver lucro." },
      { letra: "d", texto: "ilicito administrativo apenas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Transmissao por radiodifusao (inclusive comunitaria) e oferta ao publico via ondas, caracterizando a qualificadora do par. 3. Nao precisa de fins lucrativos.",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2021",
    enunciado:
      "Reproduzir obra protegida para uso privado, sem intuito de lucro, em um so exemplar",
    alternativas: [
      { letra: "a", texto: "e crime de violacao autoral." },
      { letra: "b", texto: "e atipico (art. 184, par. 4)." },
      { letra: "c", texto: "e crime culposo." },
      { letra: "d", texto: "e contravencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O par. 4 exclui expressamente a tipicidade para copia em um so exemplar, de pequenos trechos, para uso privado do copista, sem intuito de lucro.",
  },
  {
    id: 15,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Site disponibiliza serial numbers (chaves de ativacao) de software pago para download gratuito. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral de software." },
      { letra: "b", texto: "crime de pirataria de hardware." },
      { letra: "c", texto: "ilicito civil apenas." },
      { letra: "d", texto: "crime contra a propriedade industrial." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Disponibilizar meios para burlar protecao de software viola direitos autorais. Enquadra-se na Lei 9.609/98 e no art. 184, CP, como oferta ao publico (par. 3).",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado:
      "Violar direito autoral com intuito de lucro direto ou indireto (art. 184, par. 1)",
    alternativas: [
      { letra: "a", texto: "tem pena de detencao." },
      { letra: "b", texto: "tem pena de reclusao." },
      { letra: "c", texto: "e crime de menor potencial ofensivo." },
      { letra: "d", texto: "e acao penal privada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A qualificadora do par. 1 tem pena de reclusao, de 2 a 4 anos, e multa. E mais grave que o caput (detencao).",
  },
  {
    id: 17,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Artista plastico vende pintura que e copia nao autorizada de obra de outro artista. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral qualificada por intuito de lucro." },
      { letra: "b", texto: "falsificacao de obra de arte (crime contra o patrimonio)." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "concorrencia desleal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Reproduzir obra de arte plastica e vender (intuito de lucro) viola direito patrimonial de reproducao e distribuicao. Configura qualificadora do par. 1.",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado:
      "Violar direito autoral de obra estrangeira no Brasil",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois a protecao e territorial." },
      { letra: "b", texto: "e crime, desde que o pais de origem conceda reciprocidade." },
      { letra: "c", texto: "so e crime se o autor registrar no Brasil." },
      { letra: "d", texto: "e crime apenas para obras de paises do Mercosul." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A protecao a obras estrangeiras no Brasil exige reciprocidade de tratamento (art. 2, Lei 9.610/98). Se o pais de origem protege obras brasileiras, ha protecao aqui.",
  },
  {
    id: 19,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Biblioteca publica fotocopia livro inteiro para disponibilizar a usuarios, sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral, mas ha excecao para bibliotecas." },
      { letra: "b", texto: "violacao qualificada por intuito de lucro." },
      { letra: "c", texto: "uso publico permitido." },
      { letra: "d", texto: "crime de concorrencia desleal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Fotocopiar obra integral ultrapassa os limites do uso privado. Biblioteca publica nao esta automaticamente isenta; precisa de autorizacao ou deve limitar-se a pequenos trechos (art. 46, Lei 9.610/98).",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2022",
    enunciado:
      "Violar direito autoral de obra anonima ou pseudonima",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois nao ha autor identificado." },
      { letra: "b", texto: "e crime, protege-se o editor ou o titular dos direitos." },
      { letra: "c", texto: "so e crime apos identificacao do autor." },
      { letra: "d", texto: "e crime apenas se houver registro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Obras anonimas ou pseudonimas tem protecao autoral. Os direitos sao exercidos pela pessoa que tornar a obra publica (editor), ate que o autor se identifique (art. 18, Lei 9.610/98).",
  },
  {
    id: 21,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Empresa usa logotipo protegido por direitos autorais em sua propaganda, sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "violacao de marca registrada." },
      { letra: "c", texto: "crime de concorrencia desleal." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Logotipo e obra de arte aplicada, protegida por direitos autorais. Usar sem autorizacao viola direito patrimonial de utilizacao. Se registrado como marca, tambem viola Lei 9.279/96.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado:
      "Violar direito autoral de obra arquitetonica (projeto)",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois e propriedade industrial." },
      { letra: "b", texto: "e crime apenas se a obra for construida." },
      { letra: "c", texto: "e crime de violacao de direito autoral." },
      { letra: "d", texto: "e crime de usurpacao de nome comercial." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Projeto arquitetonico e obra intelectual protegida por direitos autorais (art. 7, XI, Lei 9.610/98). Reproduzi-lo sem autorizacao configura violacao.",
  },
  {
    id: 23,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Canal de YouTube monetizado usa trechos de musicas protegidas como fundo de videos, sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "uso permitido como citacao." },
      { letra: "b", texto: "violacao de direito autoral qualificada por oferta ao publico com intuito de lucro." },
      { letra: "c", texto: "crime apenas se a musica for integral." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Canal monetizado tem intuito de lucro. Oferecer ao publico via internet (par. 3) com intuito de lucro (par. 1) configura qualificadoras cumuladas.",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2021",
    enunciado:
      "Violar direito autoral de obra em dominio publico, mas atribuindo autoria falsa",
    alternativas: [
      { letra: "a", texto: "e crime de falsidade ideologica." },
      { letra: "b", texto: "e crime de violacao de direito moral (se o autor for identificavel)." },
      { letra: "c", texto: "nao e crime, pois a obra e de dominio publico." },
      { letra: "d", texto: "e crime contra a propriedade industrial." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Dominio publico extingue direitos patrimoniais, mas direitos morais (como paternidade) sao perpetuos (art. 24, Lei 9.610/98). Atribuir autoria falsa viola direito moral.",
  },
  {
    id: 25,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Estudante baixa artigo cientifico protegido de site pirata para uso em pesquisa pessoal. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral, mas e uso privado." },
      { letra: "b", texto: "violacao qualificada por oferta ao publico." },
      { letra: "c", texto: "crime apenas se compartilhar." },
      { letra: "d", texto: "atipico, pois e para fins educacionais." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Baixar de site pirata e adquirir obra obtida por meio ilicito. Mesmo para uso privado, ha discussao doutrinaria; predomina que o download para uso pessoal pode ser atipico pelo par. 4, mas o acesso a site pirata pode configurar participacao.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2023",
    enunciado:
      "Violacao de direito autoral de musica em festa particular, sem fins lucrativos",
    alternativas: [
      { letra: "a", texto: "e crime, pois qualquer execucao publica exige autorizacao." },
      { letra: "b", texto: "nao e crime, pois festa particular nao e execucao publica." },
      { letra: "c", texto: "e crime apenas se houver cobranca de ingresso." },
      { letra: "d", texto: "e contravencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Festa particular nao configura execucao publica. A Lei 9.610/98 exige autorizacao para execucao publica (art. 68). Em ambiente privado, sem fins lucrativos, nao ha crime.",
  },
  {
    id: 27,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Empresa de streaming paga direitos autorais, mas permite download ilimitado de musicas para uso offline. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "uso permitido dentro da licenca." },
      { letra: "c", texto: "crime apenas se o usuario redistribuir." },
      { letra: "d", texto: "ilicito civil de violacao contratual." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Se a empresa tem licenca que autoriza download para uso offline, nao ha violacao. O uso esta dentro dos termos da licenca contratada.",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2022",
    enunciado:
      "Fabricar e vender produto com marca registrada falsificada (art. 189, Lei 9.279/96) configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "crime contra a propriedade industrial." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "concorrencia desleal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Falsificar marca registrada e crime contra a propriedade industrial (art. 189, Lei 9.279/96). E distinto da violacao de direito autoral.",
  },
  {
    id: 29,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Produtor fonografico que grava musica sem autorizacao do compositor configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "crime contra a propriedade industrial." },
      { letra: "c", texto: "apropriacao indebita." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Gravar musica sem autorizacao do compositor viola direitos patrimoniais do autor (reproducao). Configura violacao de direito autoral (art. 184, CP).",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado:
      "A acao penal no crime de violacao de direito autoral simples (art. 184, caput) e",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O crime de violacao de direito autoral simples (caput) e de acao penal privada (art. 186, I, CP). As qualificadas (par. 1, 2 e 3) sao de acao publica incondicionada.",
  },
  {
    id: 31,
    fonte: "OAB - L Exame",
    enunciado:
      "Joao cria canal na internet onde disponibiliza gratuitamente filmes protegidos por direitos autorais. Configura",
    alternativas: [
      { letra: "a", texto: "violacao qualificada por oferta ao publico (art. 184, par. 3)." },
      { letra: "b", texto: "violacao simples." },
      { letra: "c", texto: "crime apenas se cobrar." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Disponibilizar filmes na internet e oferta ao publico via sistema que permite acesso. Configura par. 3, independente de fins lucrativos.",
  },
  {
    id: 32,
    fonte: "MPE-PR - 2022",
    enunciado:
      "O crime de concorrencia desleal (art. 195, Lei 9.279/96) exige",
    alternativas: [
      { letra: "a", texto: "dano efetivo ao concorrente." },
      { letra: "b", texto: "relacao de concorrencia entre os agentes." },
      { letra: "c", texto: "registro de marca." },
      { letra: "d", texto: "intuito de lucro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A concorrencia desleal exige relacao de concorrencia. Os agentes devem atuar no mesmo segmento de mercado. Nao exige dano efetivo, basta o potencial.",
  },
  {
    id: 33,
    fonte: "OAB - LI Exame",
    enunciado:
      "Artista contratado para show ao vivo grava o espetaculo sem autorizacao do organizador e vende as gravacoes. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral qualificada por intuito de lucro." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "uso permitido, pois e o proprio artista." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Gravar e vender sem autorizacao do titular dos direitos (organizador que contratou) viola direitos patrimoniais. O intuito de lucro qualifica o crime (par. 1).",
  },
  {
    id: 34,
    fonte: "PC-GO - 2023",
    enunciado:
      "Usurpacao de nome alheio ou pseudonimo para fins autorais configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "falsidade ideologica." },
      { letra: "c", texto: "crime de usurpacao de nome ou pseudonimo (art. 185, CP)." },
      { letra: "d", texto: "crime contra a honra." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 185 do CP tipifica a usurpacao de nome ou pseudonimo alheio para introduzir obra no comercio. E crime especifico contra a propriedade imaterial.",
  },
  {
    id: 35,
    fonte: "OAB - LII Exame",
    enunciado:
      "Gravadora lanca album com musica de compositor sem obter autorizacao previa. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "crime contra a propriedade industrial." },
      { letra: "c", texto: "exercicio regular de direito." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Reproducao e distribuicao de obra musical sem autorizacao do compositor viola direitos autorais. A gravadora precisa de licenca previa.",
  },
  {
    id: 36,
    fonte: "TJ-SC - 2022",
    enunciado:
      "Parodia de obra protegida por direitos autorais",
    alternativas: [
      { letra: "a", texto: "e sempre crime." },
      { letra: "b", texto: "e permitida se nao for verdadeira reproducao da obra originaria (art. 47, Lei 9.610/98)." },
      { letra: "c", texto: "so e permitida com autorizacao." },
      { letra: "d", texto: "e crime de concorrencia desleal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A parodia e livre, desde que nao seja verdadeira reproducao da obra originaria nem lhe implique descredito (art. 47, Lei 9.610/98). E excecao legal.",
  },
  {
    id: 37,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Empresa fabrica produto com design industrial protegido (registro de desenho industrial) de concorrente. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "crime contra a propriedade industrial (art. 187, Lei 9.279/96)." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "concorrencia desleal apenas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Fabricar produto com desenho industrial registrado alheio e crime contra a propriedade industrial (art. 187, Lei 9.279/96). O registro no INPI e necessario.",
  },
  {
    id: 38,
    fonte: "MPE-GO - 2023",
    enunciado:
      "Violar patente de invencao (art. 183, Lei 9.279/96) exige",
    alternativas: [
      { letra: "a", texto: "que a patente esteja registrada no INPI." },
      { letra: "b", texto: "apenas que a invencao exista." },
      { letra: "c", texto: "intuito de lucro." },
      { letra: "d", texto: "concorrencia entre as partes." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A protecao penal da patente exige registro no INPI (Instituto Nacional da Propriedade Industrial). Sem registro, nao ha crime contra a propriedade industrial.",
  },
  {
    id: 39,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Fotografo publica foto de pessoa publica em revista, sem autorizacao, mas em contexto jornalistico. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito de imagem." },
      { letra: "b", texto: "nao configura crime, pois ha interesse publico." },
      { letra: "c", texto: "violacao de direito autoral." },
      { letra: "d", texto: "crime contra a honra." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Publicacao de imagem de pessoa publica em contexto jornalistico e de interesse publico nao configura violacao. Ha excludente pelo interesse informativo.",
  },
  {
    id: 40,
    fonte: "PC-BA - 2022",
    enunciado:
      "Divulgar segredo industrial ou comercial (art. 195, XI, Lei 9.279/96) configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "concorrencia desleal." },
      { letra: "c", texto: "crime de violacao de sigilo profissional." },
      { letra: "d", texto: "crime contra a ordem economica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Divulgar segredo industrial ou comercial e modalidade de concorrencia desleal (art. 195, XI, Lei 9.279/96). Crime contra a propriedade industrial.",
  },
  {
    id: 41,
    fonte: "OAB - LV Exame",
    enunciado:
      "Professor grava aula presencial de outro professor e vende as gravacoes. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral qualificada por intuito de lucro." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "uso educacional permitido." },
      { letra: "d", texto: "crime contra a honra." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Aulas presenciais sao obras intelectuais protegidas. Gravar e vender sem autorizacao viola direitos autorais com intuito de lucro (par. 1).",
  },
  {
    id: 42,
    fonte: "TJ-RS - 2021",
    enunciado:
      "Importar obra intelectual fraudulenta para venda no Brasil configura",
    alternativas: [
      { letra: "a", texto: "contrabando." },
      { letra: "b", texto: "violacao de direito autoral qualificada (art. 184, par. 2)." },
      { letra: "c", texto: "receptacao." },
      { letra: "d", texto: "descaminho." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Importar obra fraudulenta para venda caracteriza a qualificadora do par. 2 (distribuicao de copias falsificadas). A intencao de venda demonstra intuito de lucro.",
  },
  {
    id: 43,
    fonte: "OAB - LVI Exame",
    enunciado:
      "Empresa utiliza invencao patenteada de outra empresa sem licenca. A pena prevista no art. 183 da Lei 9.279/96 e",
    alternativas: [
      { letra: "a", texto: "detencao, de 3 meses a 1 ano." },
      { letra: "b", texto: "reclusao, de 1 a 4 anos." },
      { letra: "c", texto: "detencao, de 1 a 3 meses, ou multa." },
      { letra: "d", texto: "reclusao, de 2 a 4 anos." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 183 da Lei 9.279/96 preve pena de detencao, de 3 meses a 1 ano, ou multa, para quem viola patente de invencao.",
  },
  {
    id: 44,
    fonte: "MPE-MT - 2023",
    enunciado:
      "Citacao de passagens de obra alheia para fins de critica (art. 46, III, Lei 9.610/98)",
    alternativas: [
      { letra: "a", texto: "e violacao de direito autoral." },
      { letra: "b", texto: "e uso livre, desde que indicada a fonte." },
      { letra: "c", texto: "so e permitida com autorizacao." },
      { letra: "d", texto: "e crime se houver intuito de lucro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 46, III, da Lei 9.610/98 permite a citacao de passagens para fins de estudo, critica ou polemica, desde que indicada a fonte. E limitacao legal ao direito autoral.",
  },
  {
    id: 45,
    fonte: "OAB - LVII Exame",
    enunciado:
      "Violar direito autoral de fotografia protegida, reproduzindo-a em livro sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral." },
      { letra: "b", texto: "crime contra a imagem." },
      { letra: "c", texto: "uso permitido como ilustracao." },
      { letra: "d", texto: "ilicito civil apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Fotografia e obra intelectual protegida (art. 7, VII, Lei 9.610/98). Reproduzi-la em livro sem autorizacao do fotografo configura violacao de direito autoral.",
  },
  {
    id: 46,
    fonte: "PC-CE - 2023",
    enunciado:
      "Violar direito autoral de obra que esta sob dominio publico em seu pais de origem, mas nao no Brasil",
    alternativas: [
      { letra: "a", texto: "nao e crime, segue a lei do pais de origem." },
      { letra: "b", texto: "e crime, a protecao no Brasil e independente." },
      { letra: "c", texto: "e crime apenas se houver reproducao." },
      { letra: "d", texto: "e atipico por reciprocidade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A protecao no Brasil segue a lei brasileira. Se a obra ainda esta protegida aqui (prazo de 70 anos pos-morte), sua utilizacao nao autorizada e crime, independente do status no pais de origem.",
  },
  {
    id: 47,
    fonte: "OAB - LVIII Exame",
    enunciado:
      "Radio toca musica protegida sem pagar direitos autorais, mas dentro da cota permitida pela lei (ECAD). Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral, pois nao pagou." },
      { letra: "b", texto: "uso permitido, pois esta na cota." },
      { letra: "c", texto: "crime apenas se exceder a cota." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O ECAD gerencia arrecadacao. Se a radio esta dentro das cotas e pagou as taxas devidas, nao ha violacao. Ha permissao legal via sistema de gestao coletiva.",
  },
  {
    id: 48,
    fonte: "TJ-MT - 2022",
    enunciado:
      "Violar direito autoral de obra que tem licenca para uso nao comercial, usando-a em propaganda comercial",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois a obra tem licenca." },
      { letra: "b", texto: "e crime, pois viola a condicao da licenca." },
      { letra: "c", texto: "e crime apenas se nao atribuir autoria." },
      { letra: "d", texto: "e ilicito civil de violacao contratual." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Licenca para uso nao comercial tem condicao restritiva. Usar em propaganda comercial viola a licenca e configura violacao de direitos autorais.",
  },
  {
    id: 49,
    fonte: "OAB - LIX Exame",
    enunciado:
      "Artista plastico vende pintura que inclui elementos protegidos por direitos autorais de fotografo, sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de direito autoral (obra derivada)." },
      { letra: "b", texto: "uso permitido como inspiracao." },
      { letra: "c", texto: "crime apenas se copiar integralmente." },
      { letra: "d", texto: "ilicito civil de plagio." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Incorporar obra protegida (fotografia) em nova obra (pintura) cria obra derivada, exigindo autorizacao. Vender configura intuito de lucro, qualificando o crime.",
  },
  {
    id: 50,
    fonte: "MPE-MA - 2023",
    enunciado:
      "Violar direito autoral de obra que esta sob protecao temporaria de trafico internacional (Convencao de Berna)",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois e trafico internacional." },
      { letra: "b", texto: "e crime, a protecao e imediata nos paises membros." },
      { letra: "c", texto: "e crime apenas se houver registro no pais." },
      { letra: "d", texto: "e crime de contrabando." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Pela Convencao de Berna, obra publicada em pais membro tem protecao automatica nos demais membros. Nao precisa de registro adicional. Violar no Brasil e crime.",
  },
];
