import { type Questao } from "./questoes-vida";

export const questoesPericlitacao: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXX Exame",
    enunciado:
      "Carlos, sabendo que e portador de HIV, mantem relacao sexual sem preservativo com Maria, sem informa-la sobre sua condicao. Maria nao contrai o virus. A conduta de Carlos configura",
    alternativas: [
      { letra: "a", texto: "tentativa de homicidio." },
      { letra: "b", texto: "perigo de contagio venereo (art. 130, CP)." },
      { letra: "c", texto: "perigo de contagio de molestia grave (art. 131, CP)." },
      { letra: "d", texto: "crime impossivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "HIV e considerado molestia venerea para fins do art. 130. O crime se consuma com a exposicao ao perigo, independentemente da transmissao. Como nao havia intencao especifica de transmitir (dolo direto), aplica-se o art. 130, nao o 131.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2021",
    enunciado:
      "No crime de omissao de socorro (art. 135, CP), e necessario que",
    alternativas: [
      { letra: "a", texto: "o agente tenha causado a situacao de perigo." },
      { letra: "b", texto: "a vitima seja conhecida do agente." },
      { letra: "c", texto: "nao haja risco pessoal para o agente prestar socorro." },
      { letra: "d", texto: "o agente seja profissional da saude." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O dever de socorrer existe apenas quando e possivel faze-lo sem risco pessoal (art. 135, caput). Nao exige vinculo anterior, nem que o agente tenha causado o perigo.",
  },
  {
    id: 3,
    fonte: "OAB - XXXI Exame",
    enunciado:
      "Mae, para ocultar sua desonra, abandona recem-nascido em via publica. O bebe e encontrado e salvo. A conduta configura",
    alternativas: [
      { letra: "a", texto: "homicidio tentado." },
      { letra: "b", texto: "abandono de incapaz (art. 133)." },
      { letra: "c", texto: "exposicao ou abandono de recem-nascido (art. 134)." },
      { letra: "d", texto: "infanticidio." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 134 tem tipo especifico para abandono/exposicao de recem-nascido para ocultar desonra propria. Difere do art. 133 (abandono de incapaz em geral). Nao ha dolo de matar, mas sim de abandonar.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2022",
    enunciado:
      "No crime de maus-tratos (art. 136, CP), o sujeito ativo",
    alternativas: [
      { letra: "a", texto: "pode ser qualquer pessoa." },
      { letra: "b", texto: "deve ter vinculo de parentesco com a vitima." },
      { letra: "c", texto: "deve exercer autoridade, guarda ou vigilancia para fins de educacao, ensino, tratamento ou custodia." },
      { letra: "d", texto: "deve ser maior de 18 anos." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Maus-tratos e crime proprio: sujeito ativo e quem exerce autoridade, guarda ou vigilancia para aqueles fins especificos (ex.: pai, professor, enfermeiro, curador).",
  },
  {
    id: 5,
    fonte: "OAB - XXXII Exame",
    enunciado:
      "Joao, sabendo que tem sifilis, mantem relacao sexual com Ana, sem informa-la. Ana contrai a doenca. Joao responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal gravissima." },
      { letra: "b", texto: "perigo de contagio venereo qualificado (paragrafo unico do art. 130)." },
      { letra: "c", texto: "perigo de contagio de molestia grave (art. 131)." },
      { letra: "d", texto: "tentativa de homicidio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Transmissao de doenca venerea com dolo eventual (sabia do risco, assumiu) configura a forma qualificada do art. 130, paragrafo unico (reclusao, 1 a 4 anos), pois ha 'intencao de transmitir a molestia' em sentido amplo (dolo eventual).",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2020",
    enunciado:
      "No crime de abandono de incapaz (art. 133), a incapacidade da vitima",
    alternativas: [
      { letra: "a", texto: "deve ser absoluta e permanente." },
      { letra: "b", texto: "pode ser relativa ou temporaria, decorrente da situacao." },
      { letra: "c", texto: "deve ser atestada por laudo medico." },
      { letra: "d", texto: "exclui a responsabilidade do agente se for mental." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A 'incapacidade de defender-se dos riscos' pode ser fisica, mental ou mesmo situacional (ex.: crianca, idoso, pessoa intoxicada). Nao precisa ser permanente.",
  },
  {
    id: 7,
    fonte: "OAB - XXXIII Exame",
    enunciado:
      "Motorista, ao atropelar pedestre, foge sem prestar socorro. A vitima vem a falecer por falta de atendimento. O motorista responde por",
    alternativas: [
      { letra: "a", texto: "homicidio doloso." },
      { letra: "b", texto: "homicidio culposo com aumento por omissao de socorro." },
      { letra: "c", texto: "homicidio culposo e omissao de socorro." },
      { letra: "d", texto: "omissao de socorro resultante em morte." },
    ],
    respostaCorreta: "b",
    explicacao:
      "No homicidio culposo (art. 121, par. 3), se o agente deixa de prestar socorro, a pena e aumentada. Nao ha concurso com art. 135, pois e causa de aumento especial. O resultado morte nao transforma em doloso.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2022",
    enunciado:
      "Professor, como punicao, deixa aluno sem merenda durante todo o periodo escolar. Configura",
    alternativas: [
      { letra: "a", texto: "lesao corporal." },
      { letra: "b", texto: "maus-tratos (art. 136)." },
      { letra: "c", texto: "abandono de incapaz." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Privar de alimentacao pessoa sob autoridade para fins de educacao caracteriza maus-tratos (art. 136, primeira modalidade). Nao e abandono (que exige desamparo completo).",
  },
  {
    id: 9,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      "Medico, contaminado por tuberculose, atende pacientes sem usar mascara, com intencao de transmitir a doenca. Nenhum paciente se contamina. O medico responde por",
    alternativas: [
      { letra: "a", texto: "tentativa de lesao corporal." },
      { letra: "b", texto: "perigo de contagio de molestia grave (art. 131) consumado." },
      { letra: "c", texto: "perigo de contagio venereo." },
      { letra: "d", texto: "crime impossivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Tuberculose e molestia grave. Com dolo especifico de transmitir (art. 131), o crime se consuma com a pratica do ato capaz de produzir contagio, independente da transmissao efetiva.",
  },
  {
    id: 10,
    fonte: "PC-PR - 2023",
    enunciado:
      "No crime de omissao de socorro, o agente que nao presta assistencia direta, mas pede socorro a autoridade publica",
    alternativas: [
      { letra: "a", texto: "nao pratica o crime." },
      { letra: "b", texto: "pratica o crime na modalidade privilegiada." },
      { letra: "c", texto: "pratica o crime, pois a obrigacao e pessoal." },
      { letra: "d", texto: "so responde se a autoridade nao vier." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 135 da alternativa: prestar assistencia ou pedir socorro da autoridade. Se pede socorro, cumpre o dever. So havera crime se nem uma nem outra conduta for realizada.",
  },
  {
    id: 11,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Pai, ao descobrir que filha adolescente engravidou, a expulsa de casa. A filha, desamparada, passa fome. O pai responde por",
    alternativas: [
      { letra: "a", texto: "abandono material." },
      { letra: "b", texto: "abandono de incapaz (art. 133)." },
      { letra: "c", texto: "maus-tratos." },
      { letra: "d", texto: "exposicao ou abandono de recem-nascido." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A filha adolescente, sob autoridade paterna e em situacao de desamparo, e incapaz de defender-se dos riscos. Configura abandono de incapaz. Nao e maus-tratos, que exige situacao de custodia para fins especificos.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2021",
    enunciado:
      "No crime de perigo de contagio venereo (art. 130), o consentimento da vitima",
    alternativas: [
      { letra: "a", texto: "exclui o crime." },
      { letra: "b", texto: "atenua a pena." },
      { letra: "c", texto: "nao exclui o crime, pois a saude e indisponivel." },
      { letra: "d", texto: "so e relevante se a vitima for maior." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O bem juridico (saude publica e individual) e indisponivel. O consentimento nao afasta a ilicitude, pois nao se pode dispor da propria saude de forma a se expor a risco grave.",
  },
  {
    id: 13,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Enfermeiro, responsavel por idoso acamado, deixa de alimenta-lo por dois dias como castigo. O idoso sofre desidratacao. O enfermeiro responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal culposa." },
      { letra: "b", texto: "maus-tratos (art. 136)." },
      { letra: "c", texto: "abandono de incapaz." },
      { letra: "d", texto: "homicidio tentado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Privar de alimentacao pessoa sob vigilancia para fins de tratamento/custodia caracteriza maus-tratos. O resultado lesao pode ser qualificadora (art. 136, par. 1).",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2020",
    enunciado:
      "No crime de exposicao ou abandono de recem-nascido (art. 134), o motivo",
    alternativas: [
      { letra: "a", texto: "e irrelevante." },
      { letra: "b", texto: "deve ser ocultar desonra propria." },
      { letra: "c", texto: "pode ser qualquer motivo torpe." },
      { letra: "d", texto: "deve ser economico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O tipo exige o fim especial de ocultar desonra propria. Se houver outro motivo, pode configurar art. 133 (abandono de incapaz) ou homicidio.",
  },
  {
    id: 15,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Carlos, portador de hepatite B, doa sangue sem informar sua doenca. A bolsa e descartada antes da transfusao. Carlos responde por",
    alternativas: [
      { letra: "a", texto: "crime impossivel." },
      { letra: "b", texto: "perigo de contagio de molestia grave (art. 131) tentado." },
      { letra: "c", texto: "perigo de contagio de molestia grave consumado." },
      { letra: "d", texto: "nenhum crime, pois nao houve transmissao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Doar sangue sabendo-se portador de molestia grave e ato capaz de produzir contagio. Consuma-se no momento da doacao, independentemente da efetiva transmissao. Hepatite B e molestia grave.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado:
      "No crime de maus-tratos, a pena e aumentada de um terco se",
    alternativas: [
      { letra: "a", texto: "a vitima e menor de 14 anos." },
      { letra: "b", texto: "resulta lesao corporal grave." },
      { letra: "c", texto: "o crime e cometido por funcionario publico." },
      { letra: "d", texto: "ha emprego de violencia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 136, par. 1, preve aumento de pena se do fato resulta lesao corporal de natureza grave. Aumenta mais ainda se resulta morte (par. 2).",
  },
  {
    id: 17,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Motorista, ao ver acidente com vitimas, nao para porque esta atrasado para reuniao. Uma vitima morre por falta de socorro. O motorista responde por",
    alternativas: [
      { letra: "a", texto: "homicidio doloso." },
      { letra: "b", texto: "homicidio culposo." },
      { letra: "c", texto: "omissao de socorro resultante em morte (art. 135, paragrafo unico)." },
      { letra: "d", texto: "nada, pois nao causou o acidente." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Quem nao causa o perigo, mas deixa de prestar socorro quando possivel sem risco, responde por omissao de socorro. Com resultado morte, aplica-se o paragrafo unico (pena triplicada).",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado:
      "No crime de perigo de contagio venereo, a molestia venerea",
    alternativas: [
      { letra: "a", texto: "inclui apenas sifilis e gonorreia." },
      { letra: "b", texto: "inclui qualquer DST, inclusive HIV." },
      { letra: "c", texto: "exclui doencas curaveis." },
      { letra: "d", texto: "deve ser incuravel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O conceito moderno abrange todas as doencas sexualmente transmissiveis, incluindo HIV, sifilis, gonorreia, HPV, etc., conforme entendimento doutrinario e jurisprudencial atualizado.",
  },
  {
    id: 19,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Cuidadora de idoso com Alzheimer o deixa trancado em casa sozinho por 12 horas para ir a uma festa. O idoso sofre desidratacao. A cuidadora responde por",
    alternativas: [
      { letra: "a", texto: "abandono de incapaz com resultado lesao." },
      { letra: "b", texto: "maus-tratos." },
      { letra: "c", texto: "sequestro." },
      { letra: "d", texto: "lesao corporal culposa." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Deixar incapaz (idoso com Alzheimer) desamparado caracteriza abandono de incapaz (art. 133). Com resultado lesao, aplica-se o par. 1 (aumento de pena). E diferente de maus-tratos, que exige privacao de cuidados como metodo (ex.: castigo).",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2021",
    enunciado:
      "No crime de omissao de socorro, o socorro da autoridade publica",
    alternativas: [
      { letra: "a", texto: "deve ser pedido pessoalmente." },
      { letra: "b", texto: "pode ser solicitado por terceiro." },
      { letra: "c", texto: "isenta o agente apenas se for prestado." },
      { letra: "d", texto: "deve ser solicitado imediatamente." },
    ],
    respostaCorreta: "d",
    explicacao:
      "O pedido de socorro a autoridade deve ser imediato, sob pena de configurar omissao. Nao precisa ser pessoal (pode ser por telefone), mas o agente deve tomar a iniciativa.",
  },
  {
    id: 21,
    fonte: "OAB - XL Exame",
    enunciado:
      "Maria, portadora de herpes genital, mantem relacao sexual com Joao sem preservativo, sem informa-lo. Joao nao contrai. Maria responde por",
    alternativas: [
      { letra: "a", texto: "nada, pois herpes nao e grave." },
      { letra: "b", texto: "perigo de contagio venereo." },
      { letra: "c", texto: "lesao corporal tentada." },
      { letra: "d", texto: "crime impossivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Herpes genital e doenca sexualmente transmissivel, enquadrando-se como molestia venerea. A exposicao ao perigo, com conhecimento da doenca, configura art. 130.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado:
      "No crime de abandono de incapaz, a relacao de cuidado pode decorrer de",
    alternativas: [
      { letra: "a", texto: "apenas relacao familiar." },
      { letra: "b", texto: "contrato ou lei." },
      { letra: "c", texto: "apenas dever legal expresso." },
      { letra: "d", texto: "solidariedade moral." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O dever de cuidado pode decorrer de lei, contrato, ou fato voluntario (ex.: quem leva crianca ao passeio assume responsabilidade). Nao apenas relacao familiar.",
  },
  {
    id: 23,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Pedro, ao encontrar crianca perdida em shopping, ignora e segue comprando. A crianca e encontrada por terceiro. Pedro responde por",
    alternativas: [
      { letra: "a", texto: "sequestro." },
      { letra: "b", texto: "omissao de socorro." },
      { letra: "c", texto: "abandono de incapaz." },
      { letra: "d", texto: "nada, pois nao tinha dever de cuidado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Crianca extraviada e hipotese tipica de omissao de socorro (art. 135). Qualquer pessoa tem o dever de prestar assistencia ou pedir socorro da autoridade, se possivel sem risco.",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2020",
    enunciado:
      "No crime de maus-tratos por abuso de meios de correcao, e necessario que",
    alternativas: [
      { letra: "a", texto: "haja lesao corporal." },
      { letra: "b", texto: "o meio seja fisico." },
      { letra: "c", texto: "haja excesso na disciplina." },
      { letra: "d", texto: "a vitima seja menor." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A modalidade 'abusando de meios de correcao ou disciplina' exige excesso, ou seja, uso desproporcional ou inadequado dos meios corretivos. Nao exige lesao, nem que a vitima seja menor.",
  },
  {
    id: 25,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Medico, com COVID-19, atende pacientes sem EPI, sabendo do risco. Dois pacientes contraem a doenca. O medico responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal culposa." },
      { letra: "b", texto: "perigo de contagio de molestia grave (art. 131)." },
      { letra: "c", texto: "crime de epidemia." },
      { letra: "d", texto: "homicidio culposo se houver morte." },
    ],
    respostaCorreta: "b",
    explicacao:
      "COVID-19 e molestia grave. Com dolo eventual (assume o risco de transmitir), configura art. 131. Se houver morte, pode haver concurso com homicidio doloso eventual ou culposo, dependendo do dolo.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2022",
    enunciado:
      "No crime de exposicao ou abandono de recem-nascido, a expressao 'logo apos o parto'",
    alternativas: [
      { letra: "a", texto: "significa ate 24 horas." },
      { letra: "b", texto: "significa ate a alta hospitalar." },
      { letra: "c", texto: "e interpretada de acordo com as circunstancias." },
      { letra: "d", texto: "nao tem significado temporal." },
    ],
    respostaCorreta: "c",
    explicacao:
      "'Logo apos' e expressao elastica, interpretada conforme as circunstancias. A doutrina entende que abrange periodo em que o recem-nascido ainda depende essencialmente dos cuidados imediatos pos-parto.",
  },
  {
    id: 27,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Pai, como castigo, proibe filho de 8 anos de jantar. A crianca passa mal por hipoglicemia. O pai responde por",
    alternativas: [
      { letra: "a", texto: "lesao corporal culposa." },
      { letra: "b", texto: "maus-tratos (art. 136)." },
      { letra: "c", texto: "abandono de incapaz." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Privar de alimentacao como correcao excessiva configura maus-tratos (art. 136, terceira modalidade - abuso de meios de correcao). O resultado agrava a pena.",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2021",
    enunciado:
      "No crime de perigo de contagio venereo, a expressao 'deve saber que esta contaminado' refere-se a",
    alternativas: [
      { letra: "a", texto: "culpa consciente." },
      { letra: "b", texto: "dolo eventual." },
      { letra: "c", texto: "dever objetivo de cuidado." },
      { letra: "d", texto: "erro de tipo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "'Deve saber' implica em dolo eventual: o agente, pelas circunstancias, tem elementos para suspeitar da contaminacao, mas assume o risco. Nao se exige certeza.",
  },
  {
    id: 29,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Motorista, apos atropelar pedestre, leva a vitima ao hospital, mas fornece dados falsos e foge. O pedestre sobrevive. O motorista responde por",
    alternativas: [
      { letra: "a", texto: "homicidio culposo e omissao de socorro." },
      { letra: "b", texto: "homicidio culposo com aumento por fuga (art. 121, par. 3)." },
      { letra: "c", texto: "lesao corporal culposa e omissao de socorro." },
      { letra: "d", texto: "apenas homicidio culposo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Quem causa acidente e foge para evitar prisao em flagrante comete a causa de aumento do art. 121, par. 3 (homicidio culposo) ou art. 303, par. 3, CTB (lesao culposa no transito). Nao ha concurso com art. 135.",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado:
      "No crime de maus-tratos, a sujeicao a trabalho excessivo",
    alternativas: [
      { letra: "a", texto: "exige relacao empregaticia." },
      { letra: "b", texto: "so se aplica a menores." },
      { letra: "c", texto: "pode ocorrer em contexto familiar ou de custodia." },
      { letra: "d", texto: "depende de denuncia da vitima." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Trabalho excessivo como modalidade de maus-tratos aplica-se a qualquer pessoa sob autoridade, guarda ou vigilancia (ex.: filho, aluno, paciente, empregado domestico), nao apenas relacao empregaticia formal.",
  },
  {
    id: 31,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Enfermeira, intencionalmente, aplica injecao com sangue contaminado por HIV em paciente, que nao contrai o virus. A enfermeira responde por",
    alternativas: [
      { letra: "a", texto: "tentativa de homicidio." },
      { letra: "b", texto: "perigo de contagio de molestia grave consumado (art. 131)." },
      { letra: "c", texto: "lesao corporal gravissima tentada." },
      { letra: "d", texto: "crime impossivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Com dolo especifico de transmitir molestia grave (HIV), a pratica do ato capaz (aplicar sangue contaminado) consuma o crime do art. 131, independentemente da contaminacao efetiva.",
  },
  {
    id: 32,
    fonte: "MPE-PI - 2020",
    enunciado:
      "No crime de abandono de incapaz, o aumento de pena pelo resultado morte",
    alternativas: [
      { letra: "a", texto: "transforma o crime em homicidio." },
      { letra: "b", texto: "aplica-se apenas se houver dolo na morte." },
      { letra: "c", texto: "e causa de aumento dentro do mesmo tipo." },
      { letra: "d", texto: "exige nexo causal direto." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O par. 2 do art. 133 preve aumento de pena se do abandono resulta morte. E crime preterdoloso: dolo no abandono + culpa (geralmente) na morte. Nao se transforma em homicidio.",
  },
  {
    id: 33,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Carlos, ao ver pessoa ferida em via publica, nao para porque teme ser assaltado. A vitima morre. Carlos responde por",
    alternativas: [
      { letra: "a", texto: "homicidio culposo." },
      { letra: "b", texto: "omissao de socorro." },
      { letra: "c", texto: "nada, pois havia risco pessoal." },
      { letra: "d", texto: "homicidio doloso por omissao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Se ha risco pessoal concreto (medo de assalto e subjetivo, mas pode ser considerado), nao surge o dever de socorrer. O art. 135 exige possibilidade sem risco pessoal.",
  },
  {
    id: 34,
    fonte: "PC-PE - 2022",
    enunciado:
      "No crime de perigo de contagio venereo, a molestia venerea",
    alternativas: [
      { letra: "a", texto: "deve ser incuravel." },
      { letra: "b", texto: "pode ser assintomatica." },
      { letra: "c", texto: "exclui doencas virais." },
      { letra: "d", texto: "precisa ser comprovada por exame." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A doenca pode estar em fase assintomatica. O que importa e que o agente saiba ou deva saber da contaminacao. A comprovacao posterior e elemento probatorio.",
  },
  {
    id: 35,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Mae, para 'educar', bate em filho de 10 anos com cinta, causando hematomas. A conduta configura",
    alternativas: [
      { letra: "a", texto: "lesao corporal leve." },
      { letra: "b", texto: "maus-tratos (art. 136)." },
      { letra: "c", texto: "exercicio regular do direito de corrigir." },
      { letra: "d", texto: "contravencao de vias de fato." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Bater com cinta como 'correcao' pode configurar abuso de meios de correcao (art. 136), se for excessivo. O Estatuto da Crianca proibe castigo fisico. Pode haver concurso com lesao corporal.",
  },
  {
    id: 36,
    fonte: "TJ-AM - 2021",
    enunciado:
      "No crime de omissao de socorro, a pena e triplicada se",
    alternativas: [
      { letra: "a", texto: "a vitima e menor." },
      { letra: "b", texto: "resulta morte." },
      { letra: "c", texto: "o agente e profissional de saude." },
      { letra: "d", texto: "ha dolo na omissao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Paragrafo unico do art. 135: pena triplicada se da omissao resulta morte. Se resulta lesao grave, aumenta-se da metade.",
  },
  {
    id: 37,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Professor mantem alunos apos o horario como punicao coletiva, sem agua ou alimentacao. Configura",
    alternativas: [
      { letra: "a", texto: "carcere privado." },
      { letra: "b", texto: "maus-tratos." },
      { letra: "c", texto: "abandono de incapaz." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Privar de alimentacao/cuidados indispensaveis a pessoas sob autoridade para fins de ensino caracteriza maus-tratos (primeira modalidade). Nao e carcere, pois nao ha privacao de locomocao.",
  },
  {
    id: 38,
    fonte: "MPE-TO - 2023",
    enunciado:
      "No crime de perigo de contagio de molestia grave (art. 131), o dolo e",
    alternativas: [
      { letra: "a", texto: "eventual." },
      { letra: "b", texto: "direto especifico (fim de transmitir)." },
      { letra: "c", texto: "generico." },
      { letra: "d", texto: "alternativo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 131 exige dolo especifico: 'com o fim de transmitir a outrem molestia grave'. E mais grave que o art. 130, que admite dolo eventual.",
  },
  {
    id: 39,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Cuidador de idoso o deixa sozinho em casa por 3 dias ao viajar. O idoso desidrata e morre. O cuidador responde por",
    alternativas: [
      { letra: "a", texto: "homicidio doloso." },
      { letra: "b", texto: "homicidio culposo." },
      { letra: "c", texto: "abandono de incapaz resultante em morte (art. 133, par. 2)." },
      { letra: "d", texto: "omissao de socorro." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Abandonar incapaz (idoso) e o resultado morte configura art. 133, par. 2. E crime preterdoloso: dolo no abandono, culpa (geralmente) na morte.",
  },
  {
    id: 40,
    fonte: "PC-CE - 2020",
    enunciado:
      "No crime de maus-tratos, o resultado lesao grave",
    alternativas: [
      { letra: "a", texto: "transforma o crime em lesao corporal." },
      { letra: "b", texto: "e causa de aumento de pena no proprio tipo." },
      { letra: "c", texto: "exige dolo na lesao." },
      { letra: "d", texto: "e circunstancia agravante generica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 136, par. 1, preve aumento de pena se do fato resulta lesao corporal de natureza grave. E qualificadora pelo resultado dentro do mesmo tipo.",
  },
  {
    id: 41,
    fonte: "OAB - L Exame",
    enunciado:
      "Maria, portadora de HIV, engravida e transmite o virus ao filho durante o parto. Ela responde por",
    alternativas: [
      { letra: "a", texto: "perigo de contagio venereo contra o recem-nascido." },
      { letra: "b", texto: "lesao corporal gravissima." },
      { letra: "c", texto: "crime de aborto." },
      { letra: "d", texto: "infanticidio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Transmissao vertical do HIV (mae-filho) causa doenca incuravel = lesao corporal gravissima (art. 129, par. 2, III). Nao se aplica art. 130/131, pois nao houve ato de exposicao sexual ou similar.",
  },
  {
    id: 42,
    fonte: "TJ-PE - 2022",
    enunciado:
      "No crime de abandono de incapaz, o aumento de pena se o crime e cometido por ascendente ou descendente",
    alternativas: [
      { letra: "a", texto: "nao existe, e agravante generica." },
      { letra: "b", texto: "e de 1/3 (art. 133, par. 3)." },
      { letra: "c", texto: "duplica a pena." },
      { letra: "d", texto: "e causa de aumento especifica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 133, par. 3, preve aumento de pena de 1/3 se o crime e cometido por ascendente, descendente, conjuge, irmao, tutor ou curador.",
  },
  {
    id: 43,
    fonte: "OAB - LI Exame",
    enunciado:
      "Pedro, ao encontrar pessoa inconsciente na rua, liga para a policia, mas nao fica no local. A pessoa morre. Pedro responde por",
    alternativas: [
      { letra: "a", texto: "omissao de socorro resultante em morte." },
      { letra: "b", texto: "nada, pois pediu socorro." },
      { letra: "c", texto: "homicidio culposo." },
      { letra: "d", texto: "homicidio doloso por omissao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O dever do art. 135 e prestar assistencia ou pedir socorro. Pedir socorro nao exime de prestar assistencia direta se possivel sem risco. Abandonar a vitima pode configurar omissao. Com resultado morte, aplica-se o paragrafo unico.",
  },
  {
    id: 44,
    fonte: "MPE-MA - 2021",
    enunciado:
      "No crime de exposicao ou abandono de recem-nascido, a desonra propria",
    alternativas: [
      { letra: "a", texto: "deve ser real e comprovada." },
      { letra: "b", texto: "e presumida." },
      { letra: "c", texto: "e elemento subjetivo do agente." },
      { letra: "d", texto: "exclui o crime se houver anuencia do pai." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A 'desonra propria' e elemento subjetivo: basta que o agente acredite, mesmo que erroneamente, que sua honra esta em jogo. Nao precisa ser real objetivamente.",
  },
  {
    id: 45,
    fonte: "OAB - LII Exame",
    enunciado:
      "Empregador exige que empregada domestica com doenca trabalhe 16h/dia, agravando sua saude. Configura",
    alternativas: [
      { letra: "a", texto: "maus-tratos." },
      { letra: "b", texto: "exploracao de trabalho analogo a escravidao." },
      { letra: "c", texto: "lesao corporal dolosa." },
      { letra: "d", texto: "crime contra a organizacao do trabalho." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Sujeitar a trabalho excessivo pessoa sob autoridade (empregada) configura maus-tratos (art. 136). Pode haver concurso com crimes trabalhistas.",
  },
  {
    id: 46,
    fonte: "PC-PA - 2023",
    enunciado:
      "No crime de perigo de contagio venereo, a relacao sexual",
    alternativas: [
      { letra: "a", texto: "deve ser completa." },
      { letra: "b", texto: "inclui qualquer ato libidinoso." },
      { letra: "c", texto: "exige penetracao." },
      { letra: "d", texto: "so se aplica a relacoes heterossexuais." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 130 menciona 'relacoes sexuais ou qualquer ato libidinoso', abrangendo contato sexual diverso da relacao sexual completa.",
  },
  {
    id: 47,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Medico, com tuberculose ativa, realiza consultas sem mascara. Varios pacientes contraem. O medico responde por",
    alternativas: [
      { letra: "a", texto: "epidemia." },
      { letra: "b", texto: "perigo de contagio de molestia grave (art. 131) em concurso material." },
      { letra: "c", texto: "lesao corporal gravissima." },
      { letra: "d", texto: "homicidio doloso eventual." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Cada ato de exposicao (consulta) com dolo eventual de transmitir molestia grave (tuberculose) configura um crime do art. 131. Ha concurso material (varios crimes).",
  },
  {
    id: 48,
    fonte: "TJ-DF - 2022",
    enunciado:
      "No crime de maus-tratos, a pena e aumentada ate o dobro se",
    alternativas: [
      { letra: "a", texto: "a vitima e idosa." },
      { letra: "b", texto: "resulta morte." },
      { letra: "c", texto: "o agente e funcionario publico." },
      { letra: "d", texto: "ha crueldade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 136, par. 2: 'Se resulta morte, a pena e aumentada ate o dobro.' E qualificadora pelo resultado mais grave.",
  },
  {
    id: 49,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Joao, ao ver crianca se afogando em piscina, nao socorre porque nao sabe nadar. A crianca morre. Joao responde por",
    alternativas: [
      { letra: "a", texto: "homicidio culposo." },
      { letra: "b", texto: "omissao de socorro." },
      { letra: "c", texto: "nada, pois nao tinha como socorrer sem risco." },
      { letra: "d", texto: "homicidio doloso por omissao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Se nao sabe nadar, socorrer implica risco pessoal. Nao ha dever de socorrer com risco (art. 135). O dever alternativo e pedir socorro, mas a questao nao diz que ele nao pediu.",
  },
  {
    id: 50,
    fonte: "MPE-GO - 2023",
    enunciado:
      "No crime de abandono de incapaz, a consumacao ocorre quando",
    alternativas: [
      { letra: "a", texto: "a vitima sofre lesao." },
      { letra: "b", texto: "a vitima fica em situacao de perigo concreto." },
      { letra: "c", texto: "o agente deixa o local." },
      { letra: "d", texto: "decorrem 24 horas do abandono." },
    ],
    respostaCorreta: "b",
    explicacao:
      "E crime de perigo concreto: consuma-se quando a vitima fica efetivamente exposta a risco decorrente do abandono. Nao exige resultado lesivo.",
  },
];
