import { type Questao } from "./questoes-vida";

export const questoesPatrimonio: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      "Joao subtrai um celular da mesa de um bar enquanto o dono esta distraido. Nao ha violencia. A conduta configura",
    alternativas: [
      { letra: "a", texto: "roubo." },
      { letra: "b", texto: "furto (art. 155, CP)." },
      { letra: "c", texto: "apropriacao indebita." },
      { letra: "d", texto: "furto de coisa comum." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Subtrair coisa alheia movel sem violencia ou grave ameaca caracteriza furto simples (art. 155, caput). E a definicao basica do crime.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2023",
    enunciado:
      "No furto qualificado (art. 155, par. 4), inclui-se a modalidade",
    alternativas: [
      { letra: "a", texto: "furto de coisa de pequeno valor." },
      { letra: "b", texto: "furto praticado durante o dia." },
      { letra: "c", texto: "furto mediante concurso de duas ou mais pessoas." },
      { letra: "d", texto: "furto por pessoa primaria." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 155, par. 4, lista as qualificadoras: destruicao/rompimento de obstaculo; abuso de confianca; destreza; escalada; chave falsa; concurso de duas ou mais pessoas (inciso V); etc.",
  },
  {
    id: 3,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Carlos, mediante ameaca com faca, subtrai a carteira de Pedro. A conduta configura",
    alternativas: [
      { letra: "a", texto: "furto qualificado." },
      { letra: "b", texto: "roubo (art. 157, CP)." },
      { letra: "c", texto: "extorsao." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Subtrair coisa movel alheia mediante grave ameaca (faca) caracteriza roubo (art. 157, caput). Difere do furto pela presenca do meio violento.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2022",
    enunciado: "Furto de energia eletrica (art. 155, par. 3)",
    alternativas: [
      { letra: "a", texto: "e crime contra o patrimonio por equiparacao legal." },
      { letra: "b", texto: "e crime contra a ordem economica." },
      { letra: "c", texto: "nao e crime, e mera infracao administrativa." },
      { letra: "d", texto: "e crime de dano." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O par. 3 equipara energia eletrica, ou qualquer outra energia de valor economico, a coisa movel para fins de furto. E equiparacao legal expressa.",
  },
  {
    id: 5,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Maria, apos furtar bolsa, e perseguida pela vitima. Para escapar, empurra-a, causando lesao leve. Maria responde por",
    alternativas: [
      { letra: "a", texto: "furto e lesao corporal." },
      { letra: "b", texto: "roubo improprio (art. 157, par. 1)." },
      { letra: "c", texto: "latrocinio." },
      { letra: "d", texto: "roubo proprio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Violencia exercida apos a subtracao, para assegurar a impunidade ou a detencao da coisa, configura roubo improprio (art. 157, par. 1).",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2021",
    enunciado: "No estelionato (art. 171), e elemento essencial",
    alternativas: [
      { letra: "a", texto: "a violencia contra a pessoa." },
      { letra: "b", texto: "a fraude (inducao ou manutencao em erro)." },
      { letra: "c", texto: "a subtracao oculta." },
      { letra: "d", texto: "o emprego de arma." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O nucleo do estelionato e a fraude: induzir ou manter alguem em erro mediante artificio, ardil ou qualquer meio fraudulento. E crime de engodo.",
  },
  {
    id: 7,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Joao compra um notebook por preco muito abaixo do mercado, sabendo que foi furtado. A conduta de Joao configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "receptacao (art. 180, CP)." },
      { letra: "c", texto: "favorecimento real." },
      { letra: "d", texto: "crime impossivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Adquirir coisa que sabe ser produto de crime caracteriza receptacao propria (art. 180, caput). O conhecimento e elemento subjetivo.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2023",
    enunciado:
      "Roubo qualificado pelo emprego de arma de fogo (art. 157, par. 2-A) tem",
    alternativas: [
      { letra: "a", texto: "aumento de pena de 1/3." },
      { letra: "b", texto: "aumento de pena de 2/3." },
      { letra: "c", texto: "pena de reclusao de 8 a 15 anos." },
      { letra: "d", texto: "pena de reclusao de 10 a 20 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Lei 13.654/2018 acrescentou par. 2-A: aumento de 2/3 se o crime e cometido com emprego de arma de fogo. Se a arma e de brinquedo ou simulacro, aumento de metade.",
  },
  {
    id: 9,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Ana, por meio de site falso, convence Carlos a transferir R$ 5.000,00 para sua conta, sob promessa de emprestimo que nao existia. Ana configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "estelionato (art. 171)." },
      { letra: "d", texto: "fraude eletronica (art. 171, par. 2-A)." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Criar site falso e artificio fraudulento. Obter vantagem ilicita induzindo erro configura estelionato. Pode tambem se enquadrar no par. 2-A (fraude eletronica), com pena maior.",
  },
  {
    id: 10,
    fonte: "PC-PR - 2023",
    enunciado: "Furto privilegiado (art. 155, par. 2) exige",
    alternativas: [
      { letra: "a", texto: "coisa de pequeno valor e primariedade." },
      { letra: "b", texto: "arrependimento posterior." },
      { letra: "c", texto: "reparacao do dano." },
      { letra: "d", texto: "confissao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O furto privilegiado ocorre quando o agente e primario e o valor da coisa e pequeno (entendido como ate 1/10 do salario minimo). Pena reduzida para detencao ou multa.",
  },
  {
    id: 11,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Ladroes armados roubam carro e, durante fuga, atiram contra policiais, matando um. Respondem por",
    alternativas: [
      { letra: "a", texto: "roubo qualificado e homicidio." },
      { letra: "b", texto: "latrocinio (art. 157, par. 3, II)." },
      { letra: "c", texto: "roubo e homicidio qualificado." },
      { letra: "d", texto: "roubo seguido de lesao corporal grave." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Roubo seguido de morte (ainda que nao haja subtracao efetiva) configura latrocinio (art. 157, par. 3, II), com pena de 20 a 30 anos. Sumula 610 do STF.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2022",
    enunciado:
      "Receptacao qualificada (art. 180, par. 1) ocorre quando o crime e cometido",
    alternativas: [
      { letra: "a", texto: "por funcionario publico." },
      { letra: "b", texto: "no exercicio de atividade comercial ou industrial." },
      { letra: "c", texto: "em concurso de agentes." },
      { letra: "d", texto: "contra idoso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A qualificadora e exercicio de atividade comercial ou industrial (ex.: lojista que compra mercadoria furtada). Pena de 3 a 8 anos.",
  },
  {
    id: 13,
    fonte: "OAB - XL Exame",
    enunciado:
      "Carlos, sem permissao, 'puxa' energia eletrica da rede vizinha para sua casa. Configura",
    alternativas: [
      { letra: "a", texto: "furto de energia (art. 155, par. 3)." },
      { letra: "b", texto: "dano." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "apropriacao indebita." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Subtrair energia eletrica e furto por equiparacao (par. 3). A conduta de 'puxar' energia caracteriza subtracao.",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2021",
    enunciado: "No roubo, a violencia pode ser",
    alternativas: [
      { letra: "a", texto: "apenas fisica." },
      { letra: "b", texto: "apenas moral." },
      { letra: "c", texto: "fisica ou moral." },
      { letra: "d", texto: "apenas contra a pessoa." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A violencia no roubo pode ser fisica ou moral (grave ameaca). Deve ser contra a pessoa, nao contra coisas.",
  },
  {
    id: 15,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Joao, mediante ameaca de revelar segredo intimo, obriga Maria a lhe dar R$ 10.000,00. Joao configura",
    alternativas: [
      { letra: "a", texto: "roubo." },
      { letra: "b", texto: "extorsao (art. 158, CP)." },
      { letra: "c", texto: "chantagem." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Obter vantagem economica mediante grave ameaca (revelar segredo) caracteriza extorsao (art. 158). Difere do roubo, que exige subtracao de coisa movel.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado: "Furto noturno (art. 155, par. 1) tem",
    alternativas: [
      { letra: "a", texto: "aumento de pena de 1/3." },
      { letra: "b", texto: "pena em dobro." },
      { letra: "c", texto: "qualificadora especifica." },
      { letra: "d", texto: "pena minima aumentada." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Furto praticado durante o repouso noturno tem aumento de pena de 1/3 (par. 1). Considera-se repouso noturno o periodo de descanso habitual, nao apenas a noite.",
  },
  {
    id: 17,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Ana vende a Carlos um celular que sabe ter sido furtado. Carlos nao sabe da origem. Ana configura",
    alternativas: [
      { letra: "a", texto: "receptacao propria." },
      { letra: "b", texto: "receptacao impropria (art. 180, caput, segunda parte)." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "favorecimento real." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Influir para que terceiro de boa-fe adquira coisa de origem criminosa configura receptacao impropria (segunda parte do caput).",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado:
      "Roubo com restricao a liberdade da vitima (art. 157, par. 2, II)",
    alternativas: [
      { letra: "a", texto: "e causa de aumento de pena." },
      { letra: "b", texto: "transforma o crime em sequestro." },
      { letra: "c", texto: "e qualificadora autonoma." },
      { letra: "d", texto: "exige dolo especifico." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Restringir a liberdade da vitima (ex.: amarrar, trancar) e causa de aumento de pena de 1/3 a 2/3 (par. 2, II). Nao e crime autonomo.",
  },
  {
    id: 19,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Carlos, mediante falsa identidade, aluga carro e depois o vende. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "roubo." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "apropriacao indebita." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Usar falsa identidade e artificio fraudulento. Obter a posse do carro para depois vende-lo caracteriza estelionato (obtencao de vantagem ilicita mediante fraude).",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2022",
    enunciado: "Furto de coisa de valor infimo (ex.: uma bala)",
    alternativas: [
      { letra: "a", texto: "e crime pelo principio da bagatela." },
      { letra: "b", texto: "e furto privilegiado." },
      { letra: "c", texto: "pode ser considerado atipico pelo principio da insignificancia." },
      { letra: "d", texto: "e contravencao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Pelo principio da insignificancia (ou bagatela), ofensa minima ao patrimonio pode ser considerada atipica, desde que nao haja periculosidade social.",
  },
  {
    id: 21,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Ladroes, em concurso, roubam caminhao transportando valores. Configura",
    alternativas: [
      { letra: "a", texto: "roubo simples." },
      { letra: "b", texto: "roubo qualificado (art. 157, par. 2, III)." },
      { letra: "c", texto: "extorsao." },
      { letra: "d", texto: "latrocinio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Roubo de veiculo transportando valores e causa de aumento (par. 2, III). Concurso de agentes tambem e qualificadora.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado: "Receptacao culposa (art. 180, par. 3) exige que o agente",
    alternativas: [
      { letra: "a", texto: "saiba da origem criminosa." },
      { letra: "b", texto: "deva saber da origem criminosa." },
      { letra: "c", texto: "tenha duvida sobre a origem." },
      { letra: "d", texto: "seja comerciante." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Receptacao culposa ocorre quando o agente deveria saber, mas nao sabe, que a coisa e produto de crime. E modalidade culposa com pena menor.",
  },
  {
    id: 23,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Medico, apos atender paciente, subtrai dinheiro de sua bolsa. Configura",
    alternativas: [
      { letra: "a", texto: "furto qualificado por abuso de confianca (art. 155, par. 4, II)." },
      { letra: "b", texto: "furto simples." },
      { letra: "c", texto: "apropriacao indebita." },
      { letra: "d", texto: "roubo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Subtrair coisa alheia de pessoa que, pelas circunstancias, deposita confianca no agente (medico-paciente) configura furto qualificado por abuso de confianca.",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2021",
    enunciado:
      "Estelionato contra pessoa com mais de 65 anos (art. 171, par. 5)",
    alternativas: [
      { letra: "a", texto: "tem acao penal publica incondicionada." },
      { letra: "b", texto: "tem acao penal publica condicionada a representacao." },
      { letra: "c", texto: "tem acao penal privada." },
      { letra: "d", texto: "e crime de menor potencial ofensivo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Apos o Pacote Anticrime (Lei 13.964/2019), o par. 5 do art. 171 tornou publica incondicionada a acao penal quando a vitima e maior de 65 anos, crianca/adolescente, pessoa com deficiencia, ou a Administracao Publica.",
  },
  {
    id: 25,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Joao, mediante violencia, obriga Pedro a assinar cheque em seu favor. Joao configura",
    alternativas: [
      { letra: "a", texto: "roubo." },
      { letra: "b", texto: "extorsao." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "falsidade ideologica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Obter vantagem (cheque) mediante violencia caracteriza extorsao (art. 158). Roubo exige subtracao de coisa movel.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2023",
    enunciado:
      "Furto mediante fraude eletronica (art. 155, par. 4-B) tem pena de",
    alternativas: [
      { letra: "a", texto: "reclusao, de 1 a 4 anos." },
      { letra: "b", texto: "reclusao, de 2 a 6 anos." },
      { letra: "c", texto: "reclusao, de 4 a 8 anos." },
      { letra: "d", texto: "reclusao, de 3 a 10 anos." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Lei 14.155/2021 acrescentou par. 4-B: furto mediante fraude eletronica (ex.: clonagem de cartao) tem pena de reclusao, de 4 a 8 anos, e multa.",
  },
  {
    id: 27,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Ana, empregada domestica, leva para casa roupas da patroa sem permissao, mas com intencao de devolver depois. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "uso indevido de coisa alheia." },
      { letra: "d", texto: "nao ha crime, pois havia intencao de devolver." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Animus furandi (intencao de apossamento) existe mesmo que temporario. Subtrair para usar e devolver caracteriza furto, pois ha afastamento da coisa sem vontade do dono.",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2022",
    enunciado:
      "Roubo com emprego de arma de brinquedo (art. 157, par. 2-A, paragrafo unico)",
    alternativas: [
      { letra: "a", texto: "nao configura roubo." },
      { letra: "b", texto: "tem aumento de pena de 2/3." },
      { letra: "c", texto: "tem aumento de pena de metade." },
      { letra: "d", texto: "e roubo simples." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Se a arma e de brinquedo ou simulacro, o aumento e de metade (paragrafo unico do par. 2-A). Se for arma de fogo real, aumento de 2/3.",
  },
  {
    id: 29,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Carlos recebe de amigo um relogio para guardar, sem saber que foi furtado. Dias depois, descobre a origem e resolve vende-lo. Configura",
    alternativas: [
      { letra: "a", texto: "receptacao desde o inicio." },
      { letra: "b", texto: "receptacao a partir da descoberta." },
      { letra: "c", texto: "favorecimento real." },
      { letra: "d", texto: "nao ha crime, pois recebeu de boa-fe." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A receptacao exige ciencia da origem criminosa. No momento da descoberta, se mantem a coisa e a vende, passa a ter dolo. Configura receptacao a partir dai.",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado: "Furto de coisa achada",
    alternativas: [
      { letra: "a", texto: "nao e furto, pois nao ha dono certo." },
      { letra: "b", texto: "e furto se o agente sabe quem e o dono." },
      { letra: "c", texto: "e apropriacao indebita." },
      { letra: "d", texto: "e crime contra a honestidade." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Coisa achada: se o agente sabe quem e o dono ou pode facilmente descobrir, e se apropria, configura apropriacao indebita (art. 169, II), nao furto.",
  },
  {
    id: 31,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Carlos, gerente de banco, transfere valores de contas de clientes para sua conta pessoal. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao indebita (art. 168)." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "peculato." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O gerente tem a posse dos valores por confianca. Apropriar-se deles, invertendo o animus da posse, configura apropriacao indebita. Se fosse servidor publico, seria peculato.",
  },
  {
    id: 32,
    fonte: "MPE-PR - 2022",
    enunciado:
      "Extorsao mediante sequestro (art. 159) e crime",
    alternativas: [
      { letra: "a", texto: "instantaneo." },
      { letra: "b", texto: "permanente." },
      { letra: "c", texto: "habitual." },
      { letra: "d", texto: "instantaneo de efeitos permanentes." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Extorsao mediante sequestro e crime permanente: a consumacao se protrai enquanto durar a privacao da liberdade da vitima. Admite flagrante a qualquer momento.",
  },
  {
    id: 33,
    fonte: "OAB - L Exame",
    enunciado:
      "Joao emite cheque sem provisao de fundos para pagar compra. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "estelionato (art. 171, par. 2, VI)." },
      { letra: "c", texto: "apropriacao indebita." },
      { letra: "d", texto: "fraude contra credores." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Emitir cheque sem provisao de fundos e forma especifica de estelionato prevista no art. 171, par. 2, VI (fraude no pagamento por meio de cheque).",
  },
  {
    id: 34,
    fonte: "PC-GO - 2023",
    enunciado:
      "No latrocinio, a competencia para julgamento e",
    alternativas: [
      { letra: "a", texto: "do Tribunal do Juri." },
      { letra: "b", texto: "do juiz singular." },
      { letra: "c", texto: "da Justica Federal." },
      { letra: "d", texto: "do juiz de execucoes penais." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sumula 603 do STF: a competencia para o processo e julgamento de latrocinio e do juiz singular e nao do Tribunal do Juri, pois nao e crime doloso contra a vida.",
  },
  {
    id: 35,
    fonte: "OAB - LI Exame",
    enunciado:
      "Ana encontra carteira com documentos e dinheiro no chao. Leva para casa e gasta o dinheiro. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao de coisa achada (art. 169, II)." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "nao ha crime." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Apropriar-se de coisa alheia achada, sem devolver ao dono ou entregar a autoridade, configura apropriacao de coisa achada (art. 169, paragrafo unico, II).",
  },
  {
    id: 36,
    fonte: "TJ-SC - 2022",
    enunciado:
      "No furto, o arrependimento posterior (art. 16, CP) exige",
    alternativas: [
      { letra: "a", texto: "reparacao do dano ate o recebimento da denuncia." },
      { letra: "b", texto: "reparacao do dano a qualquer tempo." },
      { letra: "c", texto: "confissao." },
      { letra: "d", texto: "devolucao imediata." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O arrependimento posterior (art. 16) exige reparacao do dano ou restituicao da coisa ate o recebimento da denuncia, por ato voluntario. Reduz a pena de 1/3 a 2/3.",
  },
  {
    id: 37,
    fonte: "OAB - LII Exame",
    enunciado:
      "Roubo seguido de lesao corporal grave (art. 157, par. 3, I) tem pena de",
    alternativas: [
      { letra: "a", texto: "reclusao de 4 a 10 anos." },
      { letra: "b", texto: "reclusao de 7 a 18 anos." },
      { letra: "c", texto: "reclusao de 20 a 30 anos." },
      { letra: "d", texto: "reclusao de 5 a 15 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 157, par. 3, I: se da violencia resulta lesao corporal grave, a pena e de reclusao de 7 a 18 anos e multa.",
  },
  {
    id: 38,
    fonte: "MPE-GO - 2023",
    enunciado:
      "A extorsao se consuma com",
    alternativas: [
      { letra: "a", texto: "a obtencao da vantagem." },
      { letra: "b", texto: "o constrangimento da vitima." },
      { letra: "c", texto: "o emprego de violencia." },
      { letra: "d", texto: "a entrega do dinheiro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sumula 96 do STJ: 'O crime de extorsao consuma-se independentemente da obtencao da vantagem indevida.' Basta o constrangimento mediante violencia ou grave ameaca.",
  },
  {
    id: 39,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Carlos, taxista, ao perceber que passageiro esqueceu mala no carro, nao a devolve e vende os pertences. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "receptacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O taxista teve a posse licita da mala (esquecida no carro). Inverter o animus e vender os pertences configura apropriacao indebita (art. 168).",
  },
  {
    id: 40,
    fonte: "PC-BA - 2022",
    enunciado:
      "No crime de dano (art. 163), a acao penal e",
    alternativas: [
      { letra: "a", texto: "publica incondicionada em todos os casos." },
      { letra: "b", texto: "privada, salvo quando praticado por motivo egoista ou contra patrimonio publico." },
      { letra: "c", texto: "publica condicionada a representacao." },
      { letra: "d", texto: "sempre privada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O crime de dano simples e de acao penal privada (art. 167). Porem, quando qualificado (art. 163, paragrafo unico), a acao penal e publica incondicionada.",
  },
  {
    id: 41,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Joao, mediante fraude, obtem financiamento bancario usando documentos falsos. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "estelionato." },
      { letra: "c", texto: "apropriacao indebita." },
      { letra: "d", texto: "falsificacao de documento apenas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Usar documentos falsos para obter financiamento e artificio fraudulento que induz o banco em erro. Configura estelionato (art. 171). A falsificacao pode ser absorvida (Sumula 17 do STJ).",
  },
  {
    id: 42,
    fonte: "TJ-RS - 2021",
    enunciado:
      "No roubo, a grave ameaca deve ser",
    alternativas: [
      { letra: "a", texto: "apenas verbal." },
      { letra: "b", texto: "apenas com arma." },
      { letra: "c", texto: "qualquer meio capaz de intimidar a vitima." },
      { letra: "d", texto: "apenas fisica." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A grave ameaca no roubo pode ser por qualquer meio capaz de intimidar: verbal, gestual, exibicao de arma, simulacao de porte, etc.",
  },
  {
    id: 43,
    fonte: "OAB - LV Exame",
    enunciado:
      "Ana, caixa de supermercado, subtrai dinheiro do caixa durante o expediente. Configura",
    alternativas: [
      { letra: "a", texto: "furto qualificado por abuso de confianca." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "peculato." },
      { letra: "d", texto: "furto simples." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ana nao tem a posse do dinheiro, apenas a detencion vigiada. Subtrair configura furto qualificado por abuso de confianca (art. 155, par. 4, II), pois a relacao de emprego gera confianca.",
  },
  {
    id: 44,
    fonte: "MPE-MT - 2023",
    enunciado:
      "Extorsao mediante sequestro com resultado morte (art. 159, par. 3) tem pena de",
    alternativas: [
      { letra: "a", texto: "reclusao de 12 a 20 anos." },
      { letra: "b", texto: "reclusao de 24 a 30 anos." },
      { letra: "c", texto: "reclusao de 20 a 30 anos." },
      { letra: "d", texto: "reclusao de 15 a 25 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 159, par. 3: se resulta morte, a pena e de reclusao de 24 a 30 anos. E uma das penas mais graves do Codigo Penal.",
  },
  {
    id: 45,
    fonte: "OAB - LVI Exame",
    enunciado:
      "Funcionario de empresa de entregas se apropria de encomenda que deveria entregar ao destinatario. Configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "apropriacao indebita." },
      { letra: "c", texto: "estelionato." },
      { letra: "d", texto: "roubo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O funcionario tem a posse da encomenda para entrega (posse licita). Apropriar-se dela, invertendo o animus, configura apropriacao indebita (art. 168).",
  },
  {
    id: 46,
    fonte: "PC-CE - 2023",
    enunciado:
      "Roubo mediante reducao da capacidade de resistencia (art. 157, caput)",
    alternativas: [
      { letra: "a", texto: "exige violencia fisica." },
      { letra: "b", texto: "inclui uso de sonifero." },
      { letra: "c", texto: "so se aplica a pessoas com deficiencia." },
      { letra: "d", texto: "e roubo improprio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Reduzir a capacidade de resistencia 'por qualquer meio' inclui sonifero, embriaguez forcada, hipnose, etc. E uma das modalidades do roubo proprio.",
  },
  {
    id: 47,
    fonte: "OAB - LVII Exame",
    enunciado:
      "Carlos vende a Pedro um titulo de capitalizacao falso como se fosse verdadeiro. Pedro paga. Carlos configura",
    alternativas: [
      { letra: "a", texto: "furto." },
      { letra: "b", texto: "estelionato." },
      { letra: "c", texto: "falsificacao de documento." },
      { letra: "d", texto: "apropriacao indebita." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Vender documento falso como verdadeiro e artificio fraudulento que induz erro. Obter vantagem (dinheiro) caracteriza estelionato.",
  },
  {
    id: 48,
    fonte: "TJ-MT - 2022",
    enunciado:
      "Furto de coisa de valor cultural (art. 155, par. 4, VII)",
    alternativas: [
      { letra: "a", texto: "e qualificadora." },
      { letra: "b", texto: "tem pena aumentada de 1/3." },
      { letra: "c", texto: "e crime contra o patrimonio cultural." },
      { letra: "d", texto: "e furto simples." },
    ],
    respostaCorreta: "a",
    explicacao:
      "E qualificadora do par. 4, inciso VII: furto de coisa de valor artistico, arqueologico ou historico. Pena do furto qualificado.",
  },
  {
    id: 49,
    fonte: "OAB - LVIII Exame",
    enunciado:
      "Joao, mediante ameaca de processar por calunia, obriga Pedro a lhe dar R$ 5.000,00. Joao configura",
    alternativas: [
      { letra: "a", texto: "roubo." },
      { letra: "b", texto: "extorsao." },
      { letra: "c", texto: "chantagem." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ameacar com mal injusto (processar por calunia falsa) para obter vantagem economica caracteriza extorsao (art. 158).",
  },
  {
    id: 50,
    fonte: "MPE-MA - 2023",
    enunciado:
      "Furto de veiculo automotor para uso momentaneo (joyride)",
    alternativas: [
      { letra: "a", texto: "e furto simples." },
      { letra: "b", texto: "e uso indevido de veiculo." },
      { letra: "c", texto: "e apropriacao indebita." },
      { letra: "d", texto: "nao e crime." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Subtrair veiculo para uso temporario ainda configura furto, pois ha animus furandi (apossamento) ainda que transitorio. O Codigo Penal nao distingue pelo tempo de posse.",
  },
];
