export interface MetodologiaTopico {
  id: string;
  titulo: string;
  icon: string;
  descricao: string;
  conteudo: string;
  objetivos: string[];
  aplicacaoPratica: string;
  autoresReferencia: string[];
  fundamentacao?: string[];
}

export const metodologiaTopicos: MetodologiaTopico[] = [
  {
    id: "metodologias-ativas",
    titulo: "Metodologias Ativas de Aprendizagem",
    icon: "Lightbulb",
    descricao:
      "As metodologias ativas colocam o aluno como protagonista do processo de ensino-aprendizagem, superando o modelo tradicional de aulas exclusivamente expositivas. No ensino juridico, essa abordagem e fundamental para desenvolver o pensamento critico necessario a pratica do Direito.",
    conteudo:
      "As metodologias ativas de aprendizagem representam uma mudanca paradigmatica no ensino superior, especialmente no Direito. Em vez do modelo tradicional em que o professor transmite conhecimento e o aluno recebe passivamente, as metodologias ativas promovem a participacao efetiva do estudante na construcao do saber. Fundamentadas em teoricos como Paulo Freire (Pedagogia da Autonomia), Jean Piaget (construtivismo) e Lev Vygotsky (sociointeracionismo), essas abordagens partem do principio de que a aprendizagem e mais significativa quando o aluno e desafiado a resolver problemas reais, debater, pesquisar e aplicar conceitos de forma pratica. No ambito do Direito Penal, isso significa analisar casos concretos, jurisprudencia e situacoes hipoteticas que exijam raciocinio juridico autonomo.",
    objetivos: [
      "Desenvolver autonomia e protagonismo do aluno no processo de aprendizagem",
      "Estimular o pensamento critico e a capacidade de argumentacao juridica",
      "Promover a aprendizagem significativa atraves da conexao teoria-pratica",
      "Preparar o aluno para a resolucao de problemas reais da pratica juridica",
      "Fomentar habilidades de pesquisa, comunicacao e trabalho colaborativo",
    ],
    aplicacaoPratica:
      "No estudo dos Crimes contra a Vida (arts. 121-128, CP), o professor pode apresentar um caso real julgado pelo Tribunal do Juri, dividir a turma em grupos de acusacao e defesa, e promover um juri simulado. Os alunos devem pesquisar a legislacao, doutrina e jurisprudencia aplicaveis, desenvolvendo peticoes e sustentacoes orais.",
    autoresReferencia: [
      "FREIRE, Paulo. Pedagogia da Autonomia. Sao Paulo: Paz e Terra, 2019.",
      "MORAN, Jose Manuel. Metodologias ativas para uma educacao inovadora. Porto Alegre: Penso, 2018.",
      "BERBEL, Neusi Aparecida Navas. As metodologias ativas e a promocao da autonomia de estudantes. Semina: Ciencias Sociais e Humanas, v. 32, n. 1, 2011.",
    ],
    fundamentacao: [
      "Art. 3, XIII, da Resolucao CNE/CES n. 5/2018 - Diretrizes Curriculares do Curso de Direito: formacao que estimule a capacidade de raciocinio juridico, de argumentacao, de persuasao e de reflexao critica.",
      "Art. 2, par. 1, da LDB (Lei 9.394/96): a educacao devera vincular-se ao mundo do trabalho e a pratica social.",
    ],
  },
  {
    id: "aprendizagem-baseada-problemas",
    titulo: "Aprendizagem Baseada em Problemas (ABP)",
    icon: "Target",
    descricao:
      "A ABP (ou PBL - Problem Based Learning) e uma estrategia pedagogica que utiliza problemas reais ou simulados como ponto de partida para a aprendizagem. No Direito Penal, os casos praticos sao a materia-prima ideal para essa metodologia.",
    conteudo:
      "A Aprendizagem Baseada em Problemas (ABP) foi desenvolvida inicialmente na Universidade de McMaster (Canada) na decada de 1960, para o ensino de Medicina, e posteriormente adaptada para diversas areas, incluindo o Direito. Nessa abordagem, o professor apresenta um problema concreto (caso penal, situacao fatica) antes de expor a teoria. Os alunos devem identificar questoes juridicas, levantar hipoteses, pesquisar fontes normativas e doutrinarias, e propor solucoes fundamentadas. O ciclo da ABP no Direito Penal segue etapas: (1) apresentacao do caso/problema; (2) identificacao dos fatos juridicamente relevantes; (3) levantamento de hipoteses de tipificacao; (4) pesquisa individual e coletiva; (5) discussao em grupo; (6) sintese e fundamentacao da solucao. O papel do professor e de tutor/facilitador, orientando sem fornecer respostas prontas.",
    objetivos: [
      "Desenvolver a capacidade de analise e resolucao de casos penais concretos",
      "Integrar teoria e pratica no estudo da tipificacao penal",
      "Estimular a pesquisa autonoma de legislacao, doutrina e jurisprudencia",
      "Promover o trabalho colaborativo e a construcao coletiva do conhecimento",
      "Preparar o aluno para a atividade profissional forense",
    ],
    aplicacaoPratica:
      "Caso pratico: 'Maria, enfermeira, ao administrar medicamento ao paciente Jose, confunde os frascos e injeta substancia letal. Jose falece.' Os alunos devem analisar: trata-se de homicidio culposo (art. 121, par. 3, CP) ou negligencia sem dolo? Ha erro de tipo (art. 20, CP)? Qual a pena aplicavel? Ha causa de aumento (art. 121, par. 4, CP)?",
    autoresReferencia: [
      "RIBEIRO, Luis Roberto de Camargo. Aprendizagem Baseada em Problemas (PBL): uma experiencia no ensino superior. Sao Carlos: EdUFSCar, 2010.",
      "GHIRARDI, Jose Garcez. O instante do encontro: questoes fundamentais para o ensino juridico. Sao Paulo: FGV, 2012.",
      "RODRIGUES, Horacio Wanderlei. Ensino juridico e direito alternativo. Sao Paulo: Academica, 1993.",
    ],
  },
  {
    id: "sala-aula-invertida",
    titulo: "Sala de Aula Invertida (Flipped Classroom)",
    icon: "RotateCcw",
    descricao:
      "Na sala de aula invertida, o aluno estuda o conteudo teorico previamente (em casa) e utiliza o tempo em sala para atividades praticas, debates e resolucao de problemas, otimizando o tempo presencial para aprendizagem ativa.",
    conteudo:
      "A Sala de Aula Invertida (Flipped Classroom) foi popularizada por Jonathan Bergmann e Aaron Sams (2012). No modelo tradicional, o professor expoe o conteudo em sala e o aluno pratica em casa. Na sala invertida, essa logica se inverte: o conteudo teorico e disponibilizado previamente (textos, videos, podcasts, artigos doutrinarios) e o tempo presencial e dedicado a atividades de aprofundamento. No ensino do Direito Penal, isso significa que o aluno chega a aula ja tendo lido os artigos do Codigo Penal, a doutrina e os julgados sobre o tema. Em sala, o professor conduz analises de casos, debates sobre jurisprudencia divergente, simulacoes de audiencias e atividades que exigem aplicacao pratica do conteudo estudado. Essa abordagem permite que o professor identifique dificuldades especificas dos alunos e dedique mais tempo a explicacoes aprofundadas dos pontos mais complexos.",
    objetivos: [
      "Otimizar o tempo presencial para atividades praticas e interativas",
      "Promover o estudo previo e a responsabilidade do aluno pela aprendizagem",
      "Permitir que o professor atue como mediador e facilitador",
      "Possibilitar atendimento individualizado as dificuldades dos alunos",
      "Aprofundar a analise critica de casos e jurisprudencia em sala de aula",
    ],
    aplicacaoPratica:
      "Antes da aula sobre Lesao Corporal (art. 129, CP), o professor disponibiliza: leitura dos arts. 129 e paragrafos; video-aula sobre as modalidades de lesao; e um caso pratico para analise. Em sala, os alunos discutem a tipificacao do caso, debatem as circunstancias qualificadoras e analisam jurisprudencia do STJ sobre o tema.",
    autoresReferencia: [
      "BERGMANN, Jonathan; SAMS, Aaron. Sala de Aula Invertida: uma metodologia ativa de aprendizagem. Rio de Janeiro: LTC, 2016.",
      "VALENTE, Jose Armando. Blended learning e as mudancas no ensino superior. Campinas: Unicamp, 2014.",
      "BACICH, Lilian; MORAN, Jose. Metodologias ativas para uma educacao inovadora. Porto Alegre: Penso, 2018.",
    ],
  },
  {
    id: "avaliacao-formativa",
    titulo: "Avaliacao Formativa e Continua",
    icon: "ClipboardCheck",
    descricao:
      "A avaliacao formativa e um processo continuo que acompanha a aprendizagem do aluno ao longo da disciplina, oferecendo feedback constante para aprimoramento, em oposicao a avaliacao meramente somativa (prova final).",
    conteudo:
      "A avaliacao formativa, conceituada por Benjamin Bloom (1971) e desenvolvida por Philippe Perrenoud (1999), e um modelo avaliativo que ocorre durante todo o processo de ensino-aprendizagem, e nao apenas ao final. No ensino do Direito Penal, isso significa avaliar o aluno continuamente atraves de diversas atividades: quizzes sobre cada topico estudado, analises de casos praticos, participacao em debates, elaboracao de pecas processuais, apresentacoes de seminarios e portfolios reflexivos. O objetivo nao e apenas atribuir nota, mas fornecer feedback que permita ao aluno identificar seus pontos fortes e fracos, ajustar suas estrategias de estudo e aprofundar areas deficitarias. Os quizzes desta plataforma funcionam como instrumento de avaliacao formativa: o aluno recebe correcao automatica com explicacao detalhada, podendo refazer as questoes e acompanhar sua evolucao.",
    objetivos: [
      "Acompanhar o progresso do aluno de forma continua e sistematica",
      "Oferecer feedback imediato e construtivo para aprimoramento",
      "Identificar dificuldades de aprendizagem precocemente",
      "Diversificar os instrumentos avaliativos alem da prova tradicional",
      "Promover a autoavaliacao e a metacognicao do estudante",
    ],
    aplicacaoPratica:
      "Apos cada topico de Direito Penal III (ex.: Crimes contra a Honra), o aluno realiza o quiz correspondente com 50 questoes. O sistema mostra imediatamente quais questoes acertou e errou, com explicacao fundamentada. O professor pode analisar o desempenho da turma e reforcar os pontos com maior indice de erro.",
    autoresReferencia: [
      "PERRENOUD, Philippe. Avaliacao: da excelencia a regulacao das aprendizagens. Porto Alegre: Artmed, 1999.",
      "LUCKESI, Cipriano Carlos. Avaliacao da aprendizagem escolar. Sao Paulo: Cortez, 2011.",
      "HOFFMANN, Jussara. Avaliacao mediadora: uma pratica em construcao da pre-escola a universidade. Porto Alegre: Mediacao, 2009.",
    ],
  },
  {
    id: "aprendizagem-colaborativa",
    titulo: "Aprendizagem Colaborativa e Cooperativa",
    icon: "Users",
    descricao:
      "A aprendizagem colaborativa e uma estrategia em que os alunos trabalham juntos para construir conhecimento, resolver problemas e desenvolver habilidades interpessoais essenciais a pratica juridica.",
    conteudo:
      "A aprendizagem colaborativa, fundamentada nas teorias de Vygotsky (Zona de Desenvolvimento Proximal) e nas pesquisas dos irmaos Johnson (1999), propoe que a interacao entre pares potencializa a aprendizagem. No Direito Penal, essa abordagem e particularmente eficaz: os alunos podem formar grupos de estudo para analisar tipos penais, debater jurisprudencia conflitante, simular audiencias e preparar peticoes coletivamente. A diferenca entre aprendizagem colaborativa e cooperativa e sutil: na colaborativa, o grupo trabalha junto na mesma tarefa; na cooperativa, cada membro tem uma funcao especifica que contribui para o resultado final. Ambas desenvolvem habilidades fundamentais para o jurista: argumentacao, negociacao, escuta ativa, lideranca e trabalho em equipe. Atividades como juri simulado, moot courts, analise coletiva de casos e seminarios tematicos sao exemplos praticos dessas metodologias no ensino penal.",
    objetivos: [
      "Desenvolver habilidades de trabalho em equipe e comunicacao interpessoal",
      "Promover a construcao coletiva do conhecimento juridico",
      "Estimular o debate e a confrontacao de ideias de forma respeitosa",
      "Preparar o aluno para a pratica profissional colaborativa (escritorios, tribunais)",
      "Valorizar a diversidade de perspectivas na interpretacao do Direito",
    ],
    aplicacaoPratica:
      "Juri simulado sobre feminicidio (art. 121, par. 2-A, CP): a turma e dividida em acusacao, defesa, jurados, juiz e assistentes. Cada grupo pesquisa e prepara suas teses com base na legislacao, doutrina e jurisprudencia. O debate em plenario desenvolve oratoria, argumentacao e conhecimento pratico do procedimento do Tribunal do Juri.",
    autoresReferencia: [
      "TORRES, Patricia Lupion. Laboratorio on-line de aprendizagem: uma experiencia de aprendizagem colaborativa. Curitiba: PUCPR, 2004.",
      "JOHNSON, David; JOHNSON, Roger. Cooperation and Competition: Theory and Research. Edina: Interaction Book, 1989.",
      "VYGOTSKY, Lev. A Formacao Social da Mente. Sao Paulo: Martins Fontes, 2007.",
    ],
  },
  {
    id: "estudo-caso-juridico",
    titulo: "Estudo de Caso Juridico (Case Method)",
    icon: "FileSearch",
    descricao:
      "O metodo de estudo de caso, originario da Harvard Law School, consiste na analise aprofundada de casos reais ou ficticios para extrair principios juridicos, desenvolver raciocinio analitico e aplicar conceitos a situacoes concretas.",
    conteudo:
      "O metodo de estudo de caso (case method) foi introduzido no ensino juridico por Christopher Columbus Langdell na Harvard Law School em 1870, e continua sendo uma das metodologias mais eficazes para o ensino do Direito. No Brasil, essa abordagem ganhou forca com as novas Diretrizes Curriculares (Resolucao CNE/CES n. 5/2018), que enfatizam a formacao pratica. No Direito Penal, o estudo de caso envolve a analise detalhada de decisoes judiciais (acoradaos do STF e STJ, sentencas de Tribunais do Juri) para compreender como os tribunais aplicam os tipos penais, as excludentes de ilicitude e culpabilidade, e as circunstancias modificadoras da pena. O aluno aprende a 'pensar como jurista', identificando os fatos relevantes, as questoes juridicas envolvidas, os argumentos de cada parte e a fundamentacao da decisao. Essa habilidade e essencial para a advocacia, magistratura e ministerio publico.",
    objetivos: [
      "Desenvolver o raciocinio juridico analitico e a capacidade de interpretacao",
      "Conectar a teoria do Direito Penal a pratica dos tribunais",
      "Exercitar a identificacao de questoes juridicas em situacoes concretas",
      "Analisar criticamente decisoes judiciais e suas fundamentacoes",
      "Preparar o aluno para a elaboracao de pecas processuais fundamentadas",
    ],
    aplicacaoPratica:
      "Analise do HC 124.306/RJ (STF, 2016) sobre a descriminalizacao do aborto ate o 3 mes. Os alunos devem identificar: o tipo penal discutido (arts. 124-126, CP), os argumentos constitucionais invocados, a fundamentacao do voto, as implicacoes para a dogmatica penal e as criticas doutrinarias ao julgado.",
    autoresReferencia: [
      "RAMOS, Luciana de Oliveira. Ensino juridico no Brasil: reformas e perspectivas. Sao Paulo: Saraiva, 2019.",
      "GHIRARDI, Jose Garcez (org.). Metodos de Ensino em Direito: conceitos para um debate. Sao Paulo: Saraiva, 2009.",
      "GARNER, Bryan A. Making Your Case: The Art of Persuading Judges. Chicago: West Publishing, 2008.",
    ],
  },
];
