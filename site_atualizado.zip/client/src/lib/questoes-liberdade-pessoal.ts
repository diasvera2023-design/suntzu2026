import { type Questao } from "./questoes-vida";

export const questoesLiberdadePessoal: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXXII Exame",
    enunciado:
      "Policial, sem mandado judicial, entra na casa de suspeito durante a noite para realizar busca. Nao ha flagrante delito. A conduta configura",
    alternativas: [
      { letra: "a", texto: "abuso de autoridade." },
      { letra: "b", texto: "violacao de domicilio (art. 150, CP)." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "exercicio regular de direito." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A entrada em casa alheia sem consentimento do morador, fora das hipoteses legais (flagrante, desastre, socorro ou determinacao judicial durante o dia), configura violacao de domicilio. A ausencia de mandado e o horario noturno agravam a ilicitude.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2022",
    enunciado:
      "Joao, para cobrar divida, ameaca Pedro dizendo que 'vai quebrar seus bracos se nao pagar'. A conduta de Joao configura",
    alternativas: [
      { letra: "a", texto: "extorsao." },
      { letra: "b", texto: "constrangimento ilegal." },
      { letra: "c", texto: "ameaca (art. 147, CP)." },
      { letra: "d", texto: "exercicio regular de direito." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Prometer mal injusto e grave ('quebrar bracos') caracteriza ameaca (art. 147). Se houvesse exigencia de vantagem economica sob ameaca, seria extorsao.",
  },
  {
    id: 3,
    fonte: "OAB - XXXIII Exame",
    enunciado:
      "Medico, para evitar que paciente com depressao grave cometa suicidio, aplica sedativo e o mantem amarrado a maca por algumas horas. Em relacao ao medico,",
    alternativas: [
      { letra: "a", texto: "configura sequestro e carcere privado." },
      { letra: "b", texto: "ha exercicio regular de direito (art. 146, par. 3)." },
      { letra: "c", texto: "configura constrangimento ilegal." },
      { letra: "d", texto: "ha estado de necessidade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 146, par. 3, exclui o crime de constrangimento ilegal quando a coacao e exercida para impedir suicidio. E exercicio regular de direito, desde que os meios sejam razoaveis e proporcionais.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2023",
    enunciado:
      "No crime de violacao de domicilio, a expressao 'casa alheia' abrange, nos termos do par. 4 do art. 150,",
    alternativas: [
      { letra: "a", texto: "apenas a residencia familiar." },
      { letra: "b", texto: "qualquer compartimento habitado, aposento de habitacao coletiva e compartimento nao aberto ao publico." },
      { letra: "c", texto: "apenas imoveis residenciais." },
      { letra: "d", texto: "qualquer propriedade cercada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O conceito penal de 'casa' e amplo (art. 150, par. 4): qualquer compartimento habitado, aposento ocupado de habitacao coletiva e compartimento nao aberto ao publico, onde alguem exerce profissao ou atividade.",
  },
  {
    id: 5,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      "Carlos, durante discussao, segura o braco de Maria impedindo que ela saia do local. Maria quer ir embora. A conduta de Carlos configura",
    alternativas: [
      { letra: "a", texto: "sequestro." },
      { letra: "b", texto: "carcere privado." },
      { letra: "c", texto: "constrangimento ilegal (art. 146)." },
      { letra: "d", texto: "ameaca." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Impedir alguem de fazer o que a lei permite (sair do local) mediante violencia (segurar o braco) caracteriza constrangimento ilegal. Nao ha privacao de liberdade em local determinado (sequestro/carcere).",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2021",
    enunciado: "No crime de ameaca, o mal prometido deve ser",
    alternativas: [
      { letra: "a", texto: "qualquer mal, mesmo justo." },
      { letra: "b", texto: "injusto e grave." },
      { letra: "c", texto: "apenas fisico." },
      { letra: "d", texto: "iminente." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A ameaca exige promessa de mal injusto e grave (art. 147). 'Injusto' = ilicito; 'grave' = capaz de intimidar a vitima.",
  },
  {
    id: 7,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Policial, portando mandado judicial de busca e apreensao valido, entra em residencia durante o dia, mas o morador se opoe verbalmente. A conduta do policial",
    alternativas: [
      { letra: "a", texto: "configura violacao de domicilio." },
      { letra: "b", texto: "nao configura crime, pois ha determinacao judicial." },
      { letra: "c", texto: "configura abuso de autoridade." },
      { letra: "d", texto: "configura constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A determinacao judicial durante o dia e causa de exclusao da ilicitude (art. 150, par. 1, II). A vontade do morador e irrelevante nesse caso.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2023",
    enunciado:
      "Sequestro qualificado pelo resultado de grave sofrimento fisico ou moral da vitima (art. 148, par. 1, V)",
    alternativas: [
      { letra: "a", texto: "exige dolo no resultado." },
      { letra: "b", texto: "e crime preterdoloso." },
      { letra: "c", texto: "e crime qualificado pelo resultado." },
      { letra: "d", texto: "transforma-se em tortura." },
    ],
    respostaCorreta: "c",
    explicacao:
      "As qualificadoras do par. 1 do art. 148 sao elementos objetivos que agravam a pena. A de inciso V ('resulta a vitima grave sofrimento') e qualificadora pelo resultado, geralmente preterdolosa (dolo na privacao + culpa no resultado).",
  },
  {
    id: 9,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Empregador, para coagir empregado a trabalhar horas extras sem pagamento, ameaca demiti-lo. A conduta configura",
    alternativas: [
      { letra: "a", texto: "ameaca." },
      { letra: "b", texto: "constrangimento ilegal." },
      { letra: "c", texto: "reducao a condicao analoga a de escravo." },
      { letra: "d", texto: "exercicio regular de direito." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ameacar com demissao para coagir a fazer o que a lei nao manda (trabalhar sem pagamento) caracteriza constrangimento ilegal (art. 146). A ameaca de demissao, se injusta, pode configurar grave ameaca.",
  },
  {
    id: 10,
    fonte: "PC-PR - 2022",
    enunciado: "No crime de carcere privado, a privacao da liberdade",
    alternativas: [
      { letra: "a", texto: "deve ser em local amplo." },
      { letra: "b", texto: "deve ser em local fechado (clausura)." },
      { letra: "c", texto: "pode ser tanto em local amplo quanto fechado." },
      { letra: "d", texto: "exige movimento da vitima." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Carcere privado e a privacao da liberdade em local fechado (clausura). Sequestro e a privacao em local amplo. Ambos estao no art. 148.",
  },
  {
    id: 11,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Ana, apos termino conturbado, manda mensagens para ex-namorado dizendo 'vou postar suas fotos intimas na internet'. O ex-namorado se intimida. A conduta de Ana configura",
    alternativas: [
      { letra: "a", texto: "extorsao." },
      { letra: "b", texto: "ameaca." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "injuria." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Prometer mal injusto e grave (expor intimidade) para intimidar caracteriza ameaca (art. 147). Se houvesse exigencia de vantagem ('pague para nao divulgar'), seria extorsao.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2022",
    enunciado: "No crime de constrangimento ilegal, a violencia",
    alternativas: [
      { letra: "a", texto: "deve ser fisica." },
      { letra: "b", texto: "pode ser moral." },
      { letra: "c", texto: "exclui a grave ameaca." },
      { letra: "d", texto: "deve causar lesao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A violencia no art. 146 pode ser fisica ou moral. Junto com 'grave ameaca' e 'reducao da capacidade de resistencia', sao os meios executorios do crime.",
  },
  {
    id: 13,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Pai, como punicao, tranca filho de 15 anos no quarto por 24 horas. O filho nao sofre lesoes. A conduta configura",
    alternativas: [
      { letra: "a", texto: "carcere privado." },
      { letra: "b", texto: "maus-tratos." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "exercicio regular do poder familiar." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Privar alguem de liberdade mediante enclausuramento (quarto) caracteriza carcere privado (art. 148). O poder familiar nao autoriza privacao de liberdade.",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2021",
    enunciado: "A acao penal no crime de ameaca e",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ameaca tem acao penal publica condicionada a representacao (art. 147, paragrafo unico). A vitima tem 6 meses para representar.",
  },
  {
    id: 15,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Porteiro de predio impede a entrada de entregador que deseja deixar encomenda, sem justificativa. O entregador processa por constrangimento ilegal. O porteiro",
    alternativas: [
      { letra: "a", texto: "responde por constrangimento ilegal." },
      { letra: "b", texto: "nao responde, pois esta exercendo sua funcao." },
      { letra: "c", texto: "responde por violacao de domicilio." },
      { letra: "d", texto: "responde apenas se houve violencia." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Impedir alguem de fazer o que a lei permite (entrar em area comum para entregar) sem justificativa legal caracteriza constrangimento ilegal. O exercicio da funcao nao autoriza ato ilegal.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado:
      "Sequestro qualificado por ser praticado contra menor de 18 anos (art. 148, par. 1, IV)",
    alternativas: [
      { letra: "a", texto: "exige que o agente saiba da menoridade." },
      { letra: "b", texto: "e presuncao absoluta." },
      { letra: "c", texto: "e qualificadora objetiva." },
      { letra: "d", texto: "duplica a pena." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A menoridade da vitima e qualificadora objetiva: basta a condicao, independentemente do conhecimento do agente. Aumenta a pena de 1/6 a 1/3.",
  },
  {
    id: 17,
    fonte: "OAB - XL Exame",
    enunciado:
      "Medico, sem consentimento, entra no quarto de hospital onde paciente esta internado, fora do horario de visita. O paciente se opoe. O medico",
    alternativas: [
      { letra: "a", texto: "pode entrar, pois e profissional de saude." },
      { letra: "b", texto: "configura violacao de domicilio." },
      { letra: "c", texto: "configura constrangimento ilegal." },
      { letra: "d", texto: "nao comete crime, pois hospital e publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O quarto de hospital e 'casa alheia' para fins penais (art. 150, par. 4). A entrada sem consentimento, fora das hipoteses de necessidade terapeutica, configura violacao de domicilio.",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2021",
    enunciado:
      "No crime de constrangimento ilegal, a expressao 'reduzir a capacidade de resistencia' abrange",
    alternativas: [
      { letra: "a", texto: "apenas embriaguez forcada." },
      { letra: "b", texto: "qualquer meio que torne a vitima incapaz de opor resistencia." },
      { letra: "c", texto: "apenas hipnose." },
      { letra: "d", texto: "apenas uso de drogas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Reduzir a capacidade de resistencia e clausula geral que abrange qualquer meio que torne a vitima incapaz de reagir (ex.: embriaguez, sonifero, surpresa, hipnose).",
  },
  {
    id: 19,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Carlos, para evitar que amigo bebado dirija, toma sua chave do carro e o impede de sair. O amigo se irrita, mas nao ha violencia. Carlos",
    alternativas: [
      { letra: "a", texto: "comete carcere privado." },
      { letra: "b", texto: "comete constrangimento ilegal." },
      { letra: "c", texto: "age em estado de necessidade." },
      { letra: "d", texto: "exerce regular direito de impedir crime." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Impedir alguem de dirigir embriagado (crime de transito) caracteriza estado de necessidade (art. 24, CP) ou exercicio regular de direito. Nao ha ilicitude.",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2022",
    enunciado: "A pena do sequestro ou carcere privado simples e de",
    alternativas: [
      { letra: "a", texto: "detencao, de 1 a 3 anos." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "reclusao, de 2 a 6 anos." },
      { letra: "d", texto: "detencao, de 6 meses a 2 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 148, caput: pena de reclusao, de 1 a 3 anos. As qualificadoras do par. 1 aumentam a pena de 1/6 a 1/3.",
  },
  {
    id: 21,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Empregada domestica e trancada pela patroa no quarto de servico por 12 horas como castigo. A empregada nao sofre lesoes. A patroa responde por",
    alternativas: [
      { letra: "a", texto: "maus-tratos." },
      { letra: "b", texto: "carcere privado." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "reducao a condicao analoga a de escravo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Enclausuramento como castigo configura carcere privado (art. 148). Pode haver concurso com maus-tratos (art. 136).",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado:
      "No crime de violacao de domicilio, a permanencia contra a vontade do morador",
    alternativas: [
      { letra: "a", texto: "exige que a vontade seja expressa." },
      { letra: "b", texto: "pode ser contra vontade tacita." },
      { letra: "c", texto: "so configura crime se houver entrada clandestina." },
      { letra: "d", texto: "e atipica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O crime pode ser por entrada ou permanencia contra vontade expressa ou tacita (art. 150). Vontade tacita e a presumida (ex.: visita que se recusa a sair apos ser solicitada).",
  },
  {
    id: 23,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Joao, durante briga, ameaca Pedro com uma faca dizendo 'vou te matar'. Pedro foge. Joao nao o persegue. Joao responde por",
    alternativas: [
      { letra: "a", texto: "tentativa de homicidio." },
      { letra: "b", texto: "ameaca." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "porte ilegal de arma." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ameaca com arma e promessa de morte configura crime de ameaca consumado (art. 147). Nao ha inicio de execucao de homicidio, pois Pedro fugiu antes.",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2020",
    enunciado: "Sequestro praticado contra conjuge (art. 148, par. 1, I)",
    alternativas: [
      { letra: "a", texto: "e crime de acao penal condicionada." },
      { letra: "b", texto: "e qualificadora que aumenta a pena." },
      { letra: "c", texto: "e causa de diminuicao de pena." },
      { letra: "d", texto: "e atenuante." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ser ascendente, descendente, conjuge ou companheiro e qualificadora que aumenta a pena de 1/6 a 1/3 (par. 1, I).",
  },
  {
    id: 25,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Seguranca de banco impede cliente de gravar video no interior da agencia, alegando regras internas. O cliente processa por constrangimento ilegal. O seguranca",
    alternativas: [
      { letra: "a", texto: "responde, pois impediu exercicio de direito." },
      { letra: "b", texto: "nao responde, pois ha proibicao legal de gravar em bancos." },
      { letra: "c", texto: "responde apenas se usou violencia." },
      { letra: "d", texto: "nao responde, pois agiu no exercicio da funcao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Gravar em local publico (agencia bancaria) e direito, salvo lei que restrinja. Regra interna nao tem forca para criar ilicito penal. Impedir sem base legal caracteriza constrangimento ilegal.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2023",
    enunciado: "No crime de ameaca, o meio de execucao pode ser",
    alternativas: [
      { letra: "a", texto: "apenas verbal." },
      { letra: "b", texto: "apenas escrito." },
      { letra: "c", texto: "palavra, escrito, gesto ou qualquer meio simbolico." },
      { letra: "d", texto: "apenas fisico." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 147: ameacar por palavra, escrito ou gesto, ou qualquer outro meio simbolico. Inclui mensagens eletronicas, simbolos, etc.",
  },
  {
    id: 27,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Vizinho entra no quintal de outro para pegar bola de futebol, sem autorizacao, durante o dia. O morador esta em casa. A conduta configura",
    alternativas: [
      { letra: "a", texto: "violacao de domicilio." },
      { letra: "b", texto: "invasao de propriedade." },
      { letra: "c", texto: "exercicio regular de direito." },
      { letra: "d", texto: "esbulho possessorio." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Quintal e extensao da casa para fins penais. Entrada sem autorizacao, contra vontade do morador, configura violacao de domicilio (art. 150).",
  },
  {
    id: 28,
    fonte: "PC-GO - 2022",
    enunciado: "O crime de constrangimento ilegal e crime",
    alternativas: [
      { letra: "a", texto: "formal." },
      { letra: "b", texto: "material." },
      { letra: "c", texto: "de mera conduta." },
      { letra: "d", texto: "de perigo abstrato." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Constrangimento ilegal e crime material: exige resultado (a vitima efetivamente fazer ou deixar de fazer algo). Sem resultado, ha tentativa.",
  },
  {
    id: 29,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "No crime de ameaca, e necessario que a vitima efetivamente se intimide?",
    alternativas: [
      { letra: "a", texto: "Sim, e crime material." },
      { letra: "b", texto: "Nao, basta a idoneidade da ameaca." },
      { letra: "c", texto: "Sim, e preciso prova de dano psicologico." },
      { letra: "d", texto: "Nao, e crime de mera conduta." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A doutrina majoritaria (MIRABETE, NUCCI) entende que basta a idoneidade da ameaca (potencial intimidatorio), nao sendo necessario que a vitima efetivamente se intimide. E crime formal.",
  },
  {
    id: 30,
    fonte: "TJ-BA - 2023",
    enunciado:
      "No crime de violacao de domicilio praticado durante a noite, a pena e",
    alternativas: [
      { letra: "a", texto: "a mesma do tipo simples." },
      { letra: "b", texto: "aumentada de 1/3." },
      { letra: "c", texto: "duplicada." },
      { letra: "d", texto: "triplicada." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 150, par. 1: se o crime e cometido durante a noite ou em lugar ermo, ou com emprego de violencia ou de arma, ou por duas ou mais pessoas, a pena e de detencao de 1 a 3 anos (forma qualificada).",
  },
  {
    id: 31,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Professor ameaca reprovar aluno se este nao retirar reclamacao na ouvidoria. A conduta configura",
    alternativas: [
      { letra: "a", texto: "exercicio regular de direito." },
      { letra: "b", texto: "constrangimento ilegal." },
      { letra: "c", texto: "ameaca." },
      { letra: "d", texto: "abuso de autoridade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Coagir alguem a nao fazer o que a lei permite (reclamar na ouvidoria) mediante grave ameaca (reprovacao injusta) configura constrangimento ilegal (art. 146).",
  },
  {
    id: 32,
    fonte: "MPE-PR - 2021",
    enunciado:
      "Sequestro em que a vitima e mantida presa por mais de 15 dias (art. 148, par. 1, III) configura",
    alternativas: [
      { letra: "a", texto: "crime autonomo." },
      { letra: "b", texto: "qualificadora." },
      { letra: "c", texto: "causa de diminuicao de pena." },
      { letra: "d", texto: "agravante generica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A duracao superior a 15 dias e qualificadora do sequestro/carcere privado (art. 148, par. 1, III), elevando a pena de reclusao de 2 a 5 anos.",
  },
  {
    id: 33,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Cobrador ameaca devedor dizendo 'vou protestar seu nome'. O devedor se sente ameacado. O cobrador",
    alternativas: [
      { letra: "a", texto: "comete ameaca." },
      { letra: "b", texto: "comete constrangimento ilegal." },
      { letra: "c", texto: "nao comete crime, pois protestar e direito do credor." },
      { letra: "d", texto: "comete extorsao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Protestar titulo e exercicio regular de direito do credor. Nao configura ameaca porque o mal prometido e justo (legal). Ameaca exige mal injusto.",
  },
  {
    id: 34,
    fonte: "PC-RJ - 2022",
    enunciado:
      "A violacao de domicilio e crime de acao penal",
    alternativas: [
      { letra: "a", texto: "privada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "publica incondicionada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A violacao de domicilio (art. 150) e crime de acao penal publica incondicionada. Nao depende de representacao da vitima.",
  },
  {
    id: 35,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Funcionario publico que, abusando do cargo, pratica violacao de domicilio tem a pena",
    alternativas: [
      { letra: "a", texto: "igual a do tipo simples." },
      { letra: "b", texto: "aumentada de 1/3." },
      { letra: "c", texto: "duplicada." },
      { letra: "d", texto: "de reclusao de 1 a 4 anos, alem da pena do abuso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 150, par. 2: se o crime e cometido por funcionario publico, fora dos casos legais, ou com inobservancia das formalidades legais, a pena e aumentada de 1/3.",
  },
  {
    id: 36,
    fonte: "TJ-SC - 2023",
    enunciado:
      "No constrangimento ilegal, se a coacao e exercida para impedir suicidio, ha",
    alternativas: [
      { letra: "a", texto: "crime consumado." },
      { letra: "b", texto: "exclusao da ilicitude." },
      { letra: "c", texto: "exclusao da tipicidade (art. 146, par. 3)." },
      { letra: "d", texto: "atenuante." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 146, par. 3, I, exclui o crime (exclusao da tipicidade) quando a coacao visa impedir suicidio. Nao se trata de exclusao da ilicitude, mas sim de fato atipico por disposicao legal expressa.",
  },
  {
    id: 37,
    fonte: "OAB - L Exame",
    enunciado:
      "Locador troca a fechadura do imovel enquanto o inquilino esta fora, impedindo sua entrada. O locador responde por",
    alternativas: [
      { letra: "a", texto: "exercicio regular de direito." },
      { letra: "b", texto: "violacao de domicilio." },
      { letra: "c", texto: "constrangimento ilegal." },
      { letra: "d", texto: "esbulho possessorio apenas." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Impedir o inquilino de entrar em sua moradia (fazer o que a lei permite) configura constrangimento ilegal. O locador deve buscar a via judicial para retomar o imovel.",
  },
  {
    id: 38,
    fonte: "MPE-GO - 2022",
    enunciado:
      "O crime de ameaca admite tentativa?",
    alternativas: [
      { letra: "a", texto: "Sim, sempre." },
      { letra: "b", texto: "Nao, por ser crime formal." },
      { letra: "c", texto: "Sim, quando praticado por escrito." },
      { letra: "d", texto: "Nao, por ser crime habitual." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A tentativa de ameaca e possivel quando praticada por escrito (carta interceptada, mensagem nao entregue). Na forma verbal, a consumacao e instantanea, dificultando o fracionamento do iter criminis.",
  },
  {
    id: 39,
    fonte: "OAB - LI Exame",
    enunciado:
      "Marido tranca esposa em casa e sai para trabalhar, levando as chaves. A esposa fica presa por 8 horas. A conduta configura",
    alternativas: [
      { letra: "a", texto: "constrangimento ilegal." },
      { letra: "b", texto: "carcere privado." },
      { letra: "c", texto: "maus-tratos." },
      { letra: "d", texto: "ameaca." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Privar a liberdade de locomocao mediante enclausuramento (casa trancada) configura carcere privado (art. 148). Pode haver qualificadora por ser contra conjuge (par. 1, I).",
  },
  {
    id: 40,
    fonte: "PC-BA - 2023",
    enunciado:
      "O sequestro ou carcere privado e crime",
    alternativas: [
      { letra: "a", texto: "instantaneo." },
      { letra: "b", texto: "permanente." },
      { letra: "c", texto: "instantaneo de efeitos permanentes." },
      { letra: "d", texto: "habitual." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sequestro/carcere privado e crime permanente: a consumacao se protrai no tempo enquanto durar a privacao da liberdade. Admite flagrante a qualquer momento (art. 303, CPP).",
  },
  {
    id: 41,
    fonte: "OAB - LII Exame",
    enunciado:
      "Pessoa instala camera escondida na residencia do vizinho sem autorizacao. A conduta pode configurar",
    alternativas: [
      { letra: "a", texto: "violacao de domicilio." },
      { letra: "b", texto: "invasao de dispositivo informatico." },
      { letra: "c", texto: "exercicio regular de direito." },
      { letra: "d", texto: "constrangimento ilegal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Instalar camera escondida em residencia alheia pode configurar violacao de domicilio (art. 150), pois ha invasao da esfera privada do lar sem consentimento do morador.",
  },
  {
    id: 42,
    fonte: "TJ-RS - 2021",
    enunciado:
      "No crime de constrangimento ilegal, a pena e aumentada de 1/3 quando",
    alternativas: [
      { letra: "a", texto: "a vitima e menor de 18 anos." },
      { letra: "b", texto: "concorrem mais de 3 pessoas." },
      { letra: "c", texto: "e empregado arma." },
      { letra: "d", texto: "concorrem mais de tres pessoas ou ha emprego de arma." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Art. 146, par. 1: as penas aplicam-se cumulativamente e em dobro quando, para a execucao do crime, se reunem mais de tres pessoas, ou ha emprego de armas.",
  },
  {
    id: 43,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Credor, para cobrar divida, mantem devedor trancado em escritorio ate que assine cheque. A conduta configura",
    alternativas: [
      { letra: "a", texto: "exercicio regular de direito." },
      { letra: "b", texto: "extorsao." },
      { letra: "c", texto: "carcere privado em concurso com constrangimento ilegal." },
      { letra: "d", texto: "sequestro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Constranger alguem, mediante violencia ou grave ameaca, com o intuito de obter vantagem economica indevida (assinatura de cheque sob coacao), configura extorsao (art. 158). O meio (privacao de liberdade) e absorvido.",
  },
  {
    id: 44,
    fonte: "MPE-MT - 2022",
    enunciado:
      "No crime de violacao de domicilio, 'casa alheia' nao compreende (art. 150, par. 5)",
    alternativas: [
      { letra: "a", texto: "quarto de hotel." },
      { letra: "b", texto: "hospedaria." },
      { letra: "c", texto: "taverna ou casa de jogo aberta ao publico." },
      { letra: "d", texto: "aposento de habitacao coletiva." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Art. 150, par. 5: nao se compreendem na expressao 'casa' hospedaria, estalagem ou qualquer habitacao coletiva enquanto aberta, salvo aposento ocupado. Taverna e casa de jogo abertas ao publico nao sao protegidas.",
  },
  {
    id: 45,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Ameaca proferida no calor de discussao, sem seriedade, configura crime?",
    alternativas: [
      { letra: "a", texto: "Sim, sempre." },
      { letra: "b", texto: "Nao, se nao houver seriedade e idoneidade." },
      { letra: "c", texto: "Sim, independente da seriedade." },
      { letra: "d", texto: "Nao, pois ameaca so vale por escrito." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A ameaca deve ser seria e idonea (capaz de intimidar). Ameaca proferida no calor de discussao, sem seriedade ou reflexao, nao configura o crime (falta o dolo e a idoneidade).",
  },
  {
    id: 46,
    fonte: "PC-CE - 2023",
    enunciado:
      "Sequestro mediante internamento em casa de saude (art. 148, par. 1, II)",
    alternativas: [
      { letra: "a", texto: "exige dolo especifico de internar." },
      { letra: "b", texto: "e qualificadora objetiva." },
      { letra: "c", texto: "e causa de aumento de pena." },
      { letra: "d", texto: "transforma o crime em tortura." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O internamento em casa de saude e qualificadora objetiva (par. 1, II). Basta a conduta, nao exige dolo especifico alem do dolo de privar a liberdade.",
  },
  {
    id: 47,
    fonte: "OAB - LV Exame",
    enunciado:
      "Ana, apos termino, manda mensagens para ex-companheiro: 'vou espalhar que voce e gay para sua familia conservadora'. O ex se intimida. Ana",
    alternativas: [
      { letra: "a", texto: "comete injuria." },
      { letra: "b", texto: "comete ameaca." },
      { letra: "c", texto: "comete constrangimento ilegal." },
      { letra: "d", texto: "nao comete crime, e liberdade de expressao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Prometer mal injusto e grave (expor orientacao sexual para causar dano) configura ameaca. Se houvesse exigencia de vantagem, seria extorsao.",
  },
  {
    id: 48,
    fonte: "TJ-MT - 2022",
    enunciado:
      "No crime de constrangimento ilegal, a violencia moral",
    alternativas: [
      { letra: "a", texto: "exclui a configuracao do crime." },
      { letra: "b", texto: "e suficiente para caracterizar o crime." },
      { letra: "c", texto: "so configura se houver lesao psicologica." },
      { letra: "d", texto: "precisa ser fisica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A violencia pode ser moral (ex.: coacao psicologica intensa). Junto com grave ameaca, sao meios suficientes para o crime.",
  },
  {
    id: 49,
    fonte: "OAB - LVI Exame",
    enunciado:
      "Porteiro impede entrada de mulher de short em clube, alegando regra interna de 'traje adequado'. A mulher processa por constrangimento ilegal. O porteiro",
    alternativas: [
      { letra: "a", texto: "responde, pois a regra e discriminatoria." },
      { letra: "b", texto: "nao responde, pois clube e privado." },
      { letra: "c", texto: "responde apenas se usou violencia." },
      { letra: "d", texto: "nao responde, pois ha direito de admissao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Regra interna que impoe constrangimento sem base legal (discriminacao disfarcada) pode configurar constrangimento ilegal. O direito de admissao nao e absoluto.",
  },
  {
    id: 50,
    fonte: "MPE-MA - 2023",
    enunciado:
      "Sequestro com maus-tratos que resultam em grave sofrimento fisico (art. 148, par. 1, V)",
    alternativas: [
      { letra: "a", texto: "exige dolo no sofrimento." },
      { letra: "b", texto: "e crime preterdoloso." },
      { letra: "c", texto: "e qualificadora pelo resultado." },
      { letra: "d", texto: "absorve o crime de tortura." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O resultado 'grave sofrimento fisico ou moral' e qualificadora pelo resultado, geralmente preterdolosa (dolo na privacao + culpa no resultado). Pode haver concurso com tortura se houver dolo especifico de causar sofrimento.",
  },
];
