import { type Questao } from "./questoes-vida";

export const questoesSentimentoReligioso: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Durante cerimonia religiosa, Joao entra no templo e comeca a gritar, perturbando o culto. A conduta configura",
    alternativas: [
      { letra: "a", texto: "crime de desobediencia." },
      { letra: "b", texto: "crime de perturbacao do sossego." },
      { letra: "c", texto: "ultraje a culto religioso (art. 208, CP)." },
      { letra: "d", texto: "contravencao de vias de fato." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Perturbar cerimonia ou pratica de culto religioso caracteriza ultraje a culto (art. 208, segunda figura). Nao precisa haver violencia; basta a perturbacao.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2022",
    enunciado: "Violar sepultura consiste em",
    alternativas: [
      { letra: "a", texto: "apenas abrir a sepultura." },
      { letra: "b", texto: "violar ou profanar sepultura ou urna funeraria (art. 210, CP)." },
      { letra: "c", texto: "apenas roubar objetos da sepultura." },
      { letra: "d", texto: "apenas transportar cadaver sem autorizacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 210 tipifica violar ou profanar sepultura ou urna funeraria. Violar e abrir, romper; profanar e tratar com desrespeito, sem necessariamente abrir.",
  },
  {
    id: 3,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Em rede social, Maria posta video zombando de ritual religioso de determinada crenca. Configura",
    alternativas: [
      { letra: "a", texto: "liberdade de expressao." },
      { letra: "b", texto: "crime de injuria racial." },
      { letra: "c", texto: "vilipendio publico a objeto de culto religioso (art. 208, terceira figura)." },
      { letra: "d", texto: "crime contra a honra." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Vilipendiar publicamente ato ou objeto de culto religioso caracteriza a terceira figura do art. 208. Publicar video zombando e vilipendio publico.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2023",
    enunciado: "Destruir cadaver (art. 211) e crime que",
    alternativas: [
      { letra: "a", texto: "exige dolo especifico de ocultar crime." },
      { letra: "b", texto: "tutela o sentimento religioso dos familiares." },
      { letra: "c", texto: "tutela o sentimento coletivo de respeito aos mortos." },
      { letra: "d", texto: "so se configura se o cadaver for identificado." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O bem juridico e supraindividual: o sentimento coletivo de respeito e piedade para com os mortos. Nao exige relacao de parentesco.",
  },
  {
    id: 5,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Carlos, durante velorio, joga ovos no caixao, sujando-o. Configura",
    alternativas: [
      { letra: "a", texto: "crime de dano." },
      { letra: "b", texto: "crime de vilipendio a cadaver (art. 212, CP)." },
      { letra: "c", texto: "contravencao de perturbacao da ordem." },
      { letra: "d", texto: "crime de ultraje a culto." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Atos de desrespeito ao cadaver (jogar ovos no caixao) caracterizam vilipendio a cadaver (art. 212). Nao precisa haver dano material.",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2021",
    enunciado: "Impedir pratica de culto religioso (art. 208) exige",
    alternativas: [
      { letra: "a", texto: "violencia fisica." },
      { letra: "b", texto: "impedimento efetivo ou perturbacao." },
      { letra: "c", texto: "motivo de odio religioso." },
      { letra: "d", texto: "que o culto seja em local publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Basta o impedimento ou perturbacao da cerimonia. Pode ser por qualquer meio (ex.: barulho, bloqueio de acesso). Nao exige violencia.",
  },
  {
    id: 7,
    fonte: "OAB - XL Exame",
    enunciado:
      "Funeraria subtrai protese de ouro de cadaver antes do sepultamento. Configura",
    alternativas: [
      { letra: "a", texto: "furto e violacao de sepultura." },
      { letra: "b", texto: "destruicao ou subtracao de cadaver (art. 211)." },
      { letra: "c", texto: "vilipendio a cadaver." },
      { letra: "d", texto: "furto qualificado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Subtrair parte de cadaver (protese incorporada) configura subtracao de parte de cadaver (art. 211). Tambem pode haver furto, mas o art. 211 e crime especifico.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2023",
    enunciado:
      "Vilipendiar publicamente objeto de culto religioso (art. 208) exige que o objeto",
    alternativas: [
      { letra: "a", texto: "tenha valor economico." },
      { letra: "b", texto: "seja de religiao oficial." },
      { letra: "c", texto: "seja publicamente reconhecido como sagrado." },
      { letra: "d", texto: "seja utilizado em culto." },
    ],
    respostaCorreta: "d",
    explicacao:
      "O objeto deve ser de culto religioso, ou seja, utilizado em praticas religiosas. Nao importa o valor economico ou se a religiao e oficial.",
  },
  {
    id: 9,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Durante enterro, familiares impedem que pessoa de outra religiao participe do ritual. Configura",
    alternativas: [
      { letra: "a", texto: "crime de ultraje a culto." },
      { letra: "b", texto: "exercicio regular de direito." },
      { letra: "c", texto: "crime de discriminacao religiosa." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Cerimonia funebre privada: os familiares tem direito de organizar o ritual. Impedir participacao nao configura crime, desde que nao haja violencia ou perturbacao de culto alheio.",
  },
  {
    id: 10,
    fonte: "PC-PR - 2022",
    enunciado:
      "Violar sepultura para roubar joias do cadaver configura",
    alternativas: [
      { letra: "a", texto: "furto e violacao de sepultura (art. 210)." },
      { letra: "b", texto: "apenas furto qualificado." },
      { letra: "c", texto: "apenas violacao de sepultura." },
      { letra: "d", texto: "crime de profanacao de cadaver." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ha dois crimes: violacao de sepultura (art. 210) e furto (art. 155). Concurso material, pois sao condutas independentes.",
  },
  {
    id: 11,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Em discussao, Pedro chama Joao de 'herege' e 'falso crente' publicamente. Configura",
    alternativas: [
      { letra: "a", texto: "crime de injuria." },
      { letra: "b", texto: "crime de ultraje a culto (escarnecer por motivo de crenca religiosa - art. 208)." },
      { letra: "c", texto: "crime de difamacao." },
      { letra: "d", texto: "exercicio de liberdade de expressao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Escarnecer publicamente de alguem por motivo de crenca religiosa ('herege') caracteriza a primeira figura do art. 208. E crime especifico, nao injuria.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2022",
    enunciado:
      "Destruir cadaver para ocultar crime de homicidio configura",
    alternativas: [
      { letra: "a", texto: "crime de destruicao de cadaver (art. 211) e homicidio." },
      { letra: "b", texto: "apenas homicidio qualificado." },
      { letra: "c", texto: "crime conexo absorvido pelo homicidio." },
      { letra: "d", texto: "crime de ocultacao de cadaver (art. 211) em concurso com homicidio." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Ha dois crimes autonomos: homicidio e destruicao/ocultacao de cadaver (art. 211). Nao ha absorcao; sao crimes distintos que se somam.",
  },
  {
    id: 13,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Grupo invade terreiro de religiao de matriz africana e quebra objetos sagrados. Configura",
    alternativas: [
      { letra: "a", texto: "crime de dano qualificado." },
      { letra: "b", texto: "vilipendio publico a objeto de culto religioso (art. 208)." },
      { letra: "c", texto: "crime de racismo." },
      { letra: "d", texto: "crime de intolerancia religiosa (Lei 7.716/89)." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Quebrar objetos sagrados e vilipendio publico a objeto de culto (art. 208). Pode tambem configurar racismo se houver discriminacao racial associada (Lei 7.716).",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2021",
    enunciado: "Profanar sepultura significa",
    alternativas: [
      { letra: "a", texto: "apenas abri-la." },
      { letra: "b", texto: "tratar com desrespeito, sem necessariamente violar." },
      { letra: "c", texto: "apenas remover o cadaver." },
      { letra: "d", texto: "apenas danificar a lapide." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Profanar e tratar com desrespeito, ultrajar, macular a dignidade da sepultura ou urna. Pode ocorrer sem violacao fisica (ex.: pichar, realizar atos obscenos).",
  },
  {
    id: 15,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Medico legista, durante autopsia, tira fotos do cadaver e publica em rede social. Configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver (art. 212)." },
      { letra: "b", texto: "exercicio regular da funcao." },
      { letra: "c", texto: "crime de violacao de segredo profissional." },
      { letra: "d", texto: "crime contra a intimidade." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Publicar foto de cadaver de forma desrespeitosa, mesmo em autopsia legal, pode configurar vilipendio a cadaver (art. 212). A funcao nao autoriza divulgacao sensacionalista.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado:
      "O crime de escarnecer de alguem por motivo de crenca religiosa (art. 208) exige que a ofensa seja",
    alternativas: [
      { letra: "a", texto: "privada." },
      { letra: "b", texto: "publica." },
      { letra: "c", texto: "apenas verbal." },
      { letra: "d", texto: "com violencia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A conduta de escarnecer deve ser publica. Se for privada, nao configura o crime. Publicidade e elementar.",
  },
  {
    id: 17,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Funeral e interrompido por grupo que toca musica alta na rua, impedindo a continuidade. Configura",
    alternativas: [
      { letra: "a", texto: "perturbacao do sossego." },
      { letra: "b", texto: "impedimento de cerimonia religiosa (art. 208)." },
      { letra: "c", texto: "contravencao de desordem." },
      { letra: "d", texto: "crime de desobediencia." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Impedir ou perturbar cerimonia religiosa (funeral) configura a segunda figura do art. 208. A perturbacao do sossego pode ser concurso.",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado:
      "Subtrair cadaver de cemiterio para pedir resgate configura",
    alternativas: [
      { letra: "a", texto: "sequestro." },
      { letra: "b", texto: "extorsao mediante sequestro de cadaver." },
      { letra: "c", texto: "subtracao de cadaver (art. 211) e extorsao." },
      { letra: "d", texto: "violacao de sepultura e extorsao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Subtrair cadaver e crime do art. 211. Pedir resgate e extorsao (art. 158). Sao crimes autonomos em concurso.",
  },
  {
    id: 19,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Em programa de TV, apresentador faz piadas sobre santos de uma religiao. Configura",
    alternativas: [
      { letra: "a", texto: "liberdade de expressao artistica." },
      { letra: "b", texto: "crime de vilipendio publico a objeto de culto (art. 208)." },
      { letra: "c", texto: "crime de injuria coletiva." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Fazer piadas publicas sobre santos (objetos de culto) caracteriza vilipendio publico a objeto de culto. A liberdade de expressao nao protege ofensa a sentimento religioso de forma desrespeitosa.",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2022",
    enunciado: "Destruir cadaver por acidente (culpa)",
    alternativas: [
      { letra: "a", texto: "configura crime culposo." },
      { letra: "b", texto: "nao ha tipo culposo, portanto nao e crime." },
      { letra: "c", texto: "configura crime de dano culposo." },
      { letra: "d", texto: "e contravencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 211 so preve modalidade dolosa. Destruicao culposa de cadaver nao e crime penal, podendo ser ilicito civil ou administrativo.",
  },
  {
    id: 21,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Durante missa, individuo grita 'isso e tudo mentira!' e sai correndo. Configura",
    alternativas: [
      { letra: "a", texto: "crime de perturbacao de culto (art. 208)." },
      { letra: "b", texto: "exercicio de liberdade de expressao." },
      { letra: "c", texto: "contravencao de desordem." },
      { letra: "d", texto: "crime de desacato." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Gritar durante missa, perturbando a cerimonia, configura perturbacao de culto religioso. A liberdade de expressao nao autoriza perturbar ato religioso alheio.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado: "Vilipendio a cinzas de cadaver (art. 212)",
    alternativas: [
      { letra: "a", texto: "so se aplica a cadaver inteiro." },
      { letra: "b", texto: "aplica-se tambem a cinzas." },
      { letra: "c", texto: "exige que as cinzas estejam em urna." },
      { letra: "d", texto: "e crime de dano." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 212 expressamente menciona 'cadaver ou suas cinzas'. Vilipendiar cinzas (ex.: espalhar, jogar no lixo) configura o crime.",
  },
  {
    id: 23,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Grupo religioso A impede grupo religioso B de realizar culto em praca publica, usando ameacas. Configura",
    alternativas: [
      { letra: "a", texto: "crime de ultraje a culto (impedimento de cerimonia - art. 208)." },
      { letra: "b", texto: "crime de formacao de quadrilha." },
      { letra: "c", texto: "exercicio regular de direito de uso do espaco." },
      { letra: "d", texto: "crime de ameaca." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Impedir cerimonia religiosa mediante ameacas configura impedimento de culto (art. 208). Pode haver concurso com ameaca (art. 147).",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2021",
    enunciado:
      "Violar sepultura para realizar ritual religioso nao autorizado pela familia",
    alternativas: [
      { letra: "a", texto: "e crime de violacao de sepultura (art. 210)." },
      { letra: "b", texto: "e exercicio de liberdade religiosa." },
      { letra: "c", texto: "e crime apenas se danificar a sepultura." },
      { letra: "d", texto: "e ilicito civil." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A liberdade religiosa nao autoriza violar sepultura alheia sem consentimento. Violar para ritual configura crime, pois desrespeita a vontade dos familiares e a inviolabilidade da sepultura.",
  },
  {
    id: 25,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Museu exibe mumia egipcia em posicao considerada desrespeitosa por seguidores de religiao que a veneram. Configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver (art. 212)." },
      { letra: "b", texto: "exercicio de liberdade cultural." },
      { letra: "c", texto: "crime de ultraje a culto." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Expor cadaver (mumia) de forma desrespeitosa pode configurar vilipendio a cadaver. O interesse cultural nao justifica desrespeito gratuito.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2023",
    enunciado: "O crime de impedir culto religioso (art. 208) e",
    alternativas: [
      { letra: "a", texto: "de acao penal publica incondicionada." },
      { letra: "b", texto: "de acao penal publica condicionada a representacao." },
      { letra: "c", texto: "de acao penal privada." },
      { letra: "d", texto: "de acao penal publica condicionada a requisicao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Crimes contra o sentimento religioso (arts. 208 e 209) tem acao penal publica condicionada a representacao (art. 208, paragrafo unico).",
  },
  {
    id: 27,
    fonte: "OAB - L Exame",
    enunciado:
      "Carlos, para construir muro, remove ossadas de cemiterio antigo sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de violacao de sepultura (art. 210)." },
      { letra: "b", texto: "crime de destruicao de cadaver (art. 211)." },
      { letra: "c", texto: "crime ambiental." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Remover ossadas e violar sepultura. Se destruir os ossos, pode configurar tambem destruicao de cadaver (art. 211).",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2022",
    enunciado:
      "Escarnecer de alguem por motivo de funcao religiosa (ex.: sacerdote) exige que a ofensa seja",
    alternativas: [
      { letra: "a", texto: "sobre a conduta pessoal, nao religiosa." },
      { letra: "b", texto: "relacionada a funcao religiosa." },
      { letra: "c", texto: "com violencia." },
      { letra: "d", texto: "em local de culto." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O escarnio deve ser por motivo de funcao religiosa. Criticar a pessoa por motivos nao relacionados a funcao nao configura.",
  },
  {
    id: 29,
    fonte: "OAB - LI Exame",
    enunciado:
      "Funcionario de cemiterio abre caixao para roubar pertences do morto. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de sepultura (art. 210) e furto." },
      { letra: "b", texto: "apenas furto qualificado." },
      { letra: "c", texto: "vilipendio a cadaver." },
      { letra: "d", texto: "destruicao de cadaver." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Abrir caixao e violar sepultura (art. 210). Subtrair pertences e furto. Ha concurso material de crimes.",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado:
      "O bem juridico tutelado no crime de violacao de sepultura (art. 210) e",
    alternativas: [
      { letra: "a", texto: "o patrimonio da familia." },
      { letra: "b", texto: "o sentimento de respeito aos mortos." },
      { letra: "c", texto: "a saude publica." },
      { letra: "d", texto: "a ordem publica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O bem juridico e o sentimento coletivo de respeito e piedade para com os mortos. Nao e crime patrimonial.",
  },
  {
    id: 31,
    fonte: "OAB - LII Exame",
    enunciado:
      "Ateu publica artigo criticando praticas religiosas com argumentos racionais. Configura",
    alternativas: [
      { letra: "a", texto: "crime de ultraje a culto (art. 208)." },
      { letra: "b", texto: "liberdade de expressao e pensamento." },
      { letra: "c", texto: "crime contra a honra." },
      { letra: "d", texto: "contravencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Criticar praticas religiosas com argumentos racionais e exercicio de liberdade de expressao e pensamento. Nao configura escarnio nem vilipendio se feito de forma respeitosa.",
  },
  {
    id: 32,
    fonte: "MPE-PR - 2022",
    enunciado: "O crime de vilipendio a cadaver (art. 212) tem pena de",
    alternativas: [
      { letra: "a", texto: "detencao, de 1 a 3 anos, e multa." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "detencao, de 6 meses a 2 anos." },
      { letra: "d", texto: "reclusao, de 2 a 5 anos." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 212 preve pena de detencao, de 1 a 3 anos, e multa, para vilipendio a cadaver ou suas cinzas.",
  },
  {
    id: 33,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Vizinho, por vinganca, joga lixo sobre tumulo de familiar do desafeto. Configura",
    alternativas: [
      { letra: "a", texto: "crime de dano." },
      { letra: "b", texto: "profanacao de sepultura (art. 210)." },
      { letra: "c", texto: "contravencao." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Jogar lixo sobre tumulo e profanar sepultura (tratar com desrespeito). Configura a modalidade 'profanar' do art. 210.",
  },
  {
    id: 34,
    fonte: "PC-GO - 2023",
    enunciado:
      "O crime de destruicao de cadaver (art. 211) admite tentativa?",
    alternativas: [
      { letra: "a", texto: "Nao, pois e crime unissubsistente." },
      { letra: "b", texto: "Sim, pois e crime plurissubsistente." },
      { letra: "c", texto: "Nao, pois e crime de mera conduta." },
      { letra: "d", texto: "Sim, mas apenas na modalidade dolosa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O crime de destruicao de cadaver e plurissubsistente (a execucao pode ser fracionada), admitindo tentativa. Ex.: agente e surpreendido iniciando a destruicao.",
  },
  {
    id: 35,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Estudante de medicina, durante aula pratica, tira selfie com cadaver e publica na internet. Configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver (art. 212)." },
      { letra: "b", texto: "atividade academica regular." },
      { letra: "c", texto: "crime contra a intimidade." },
      { letra: "d", texto: "ilicito etico apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Tirar selfie com cadaver e publicar na internet demonstra desrespeito, configurando vilipendio a cadaver (art. 212). A atividade academica nao autoriza tal conduta.",
  },
  {
    id: 36,
    fonte: "TJ-SC - 2022",
    enunciado:
      "Violacao de sepultura (art. 210) e crime de acao penal",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Crimes contra o respeito aos mortos (arts. 209-212) sao de acao penal publica incondicionada. Diferem dos crimes contra o sentimento religioso (art. 208).",
  },
  {
    id: 37,
    fonte: "OAB - LV Exame",
    enunciado:
      "Empresa de cremacao, por negligencia, troca cinzas de dois cadaveres. Configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver." },
      { letra: "b", texto: "ilicito civil (responsabilidade contratual)." },
      { letra: "c", texto: "crime de destruicao de cadaver." },
      { letra: "d", texto: "crime de violacao de sepultura." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Troca por negligencia (culpa) nao configura crime, pois os crimes contra o respeito aos mortos exigem dolo. E ilicito civil com responsabilidade contratual.",
  },
  {
    id: 38,
    fonte: "MPE-GO - 2023",
    enunciado:
      "Ultraje a culto religioso (art. 208) protege",
    alternativas: [
      { letra: "a", texto: "apenas religioes cristas." },
      { letra: "b", texto: "todas as religioes e crencas." },
      { letra: "c", texto: "apenas religioes oficiais." },
      { letra: "d", texto: "apenas religioes monoteistas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 208 protege todas as religioes e crencas, sem distincao. A CF/88 garante liberdade de crenca a todas (art. 5, VI).",
  },
  {
    id: 39,
    fonte: "OAB - LVI Exame",
    enunciado:
      "Coveiro, por dinheiro, permite que terceiros abram sepultura para subtrair objetos. Configura",
    alternativas: [
      { letra: "a", texto: "violacao de sepultura (art. 210) como coautor." },
      { letra: "b", texto: "crime de corrupcao passiva." },
      { letra: "c", texto: "crime de prevaricacao." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O coveiro que permite a violacao, sabendo do intento, e coautor ou participe do crime de violacao de sepultura (art. 210). Pode haver concurso com corrupcao se for funcionario publico.",
  },
  {
    id: 40,
    fonte: "PC-BA - 2022",
    enunciado: "Ocultar cadaver (art. 211) significa",
    alternativas: [
      { letra: "a", texto: "apenas enterrar em local nao autorizado." },
      { letra: "b", texto: "esconder cadaver, tornando-o inacessivel." },
      { letra: "c", texto: "apenas transportar para outro local." },
      { letra: "d", texto: "apenas destruir." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ocultar e esconder, tornar inacessivel ou desconhecido o paradeiro do cadaver. Pode ser enterrar em local clandestino, esconder em propriedade, etc.",
  },
  {
    id: 41,
    fonte: "OAB - LVII Exame",
    enunciado:
      "Fotografo publica fotos de cadaver em cena de crime sem autorizacao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver (art. 212)." },
      { letra: "b", texto: "exercicio de liberdade de imprensa." },
      { letra: "c", texto: "crime contra a intimidade." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Publicar fotos de cadaver de forma sensacionalista pode configurar vilipendio (art. 212). A liberdade de imprensa nao autoriza exposicao desrespeitosa de cadaver.",
  },
  {
    id: 42,
    fonte: "TJ-RS - 2021",
    enunciado:
      "Cuspir no cadaver durante velorio configura",
    alternativas: [
      { letra: "a", texto: "crime de vilipendio a cadaver (art. 212)." },
      { letra: "b", texto: "contravencao de vias de fato." },
      { letra: "c", texto: "crime de ultraje a culto." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Cuspir no cadaver e ato de desrespeito que configura vilipendio a cadaver (art. 212). E uma das formas mais claras de vilipendio.",
  },
  {
    id: 43,
    fonte: "OAB - LVIII Exame",
    enunciado:
      "Escola proibe aluno de usar simbolo religioso (crucifixo). Configura crime contra o sentimento religioso?",
    alternativas: [
      { letra: "a", texto: "Sim, crime de impedimento de pratica de culto (art. 208)." },
      { letra: "b", texto: "Nao, pois nao ha impedimento de cerimonia ou culto." },
      { letra: "c", texto: "Sim, crime de escarnio por motivo de crenca." },
      { letra: "d", texto: "Sim, crime de vilipendio a objeto de culto." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Proibir uso de simbolo religioso em escola nao configura impedimento de cerimonia ou culto. Pode ser ilicito civil (discriminacao), mas nao crime do art. 208.",
  },
  {
    id: 44,
    fonte: "MPE-MT - 2023",
    enunciado:
      "Sujeito ativo do crime de vilipendio a cadaver (art. 212) pode ser",
    alternativas: [
      { letra: "a", texto: "apenas familiar do morto." },
      { letra: "b", texto: "qualquer pessoa (crime comum)." },
      { letra: "c", texto: "apenas funcionario publico." },
      { letra: "d", texto: "apenas profissional de saude." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Vilipendio a cadaver e crime comum: qualquer pessoa pode ser sujeito ativo. Nao exige qualidade especial do agente.",
  },
  {
    id: 45,
    fonte: "OAB - LIX Exame",
    enunciado:
      "Pintar grafite ofensivo em parede de igreja durante culto configura",
    alternativas: [
      { letra: "a", texto: "crime de dano." },
      { letra: "b", texto: "perturbacao de culto e vilipendio a objeto de culto (art. 208)." },
      { letra: "c", texto: "contravencao." },
      { letra: "d", texto: "crime de pichacao apenas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Pintar grafite ofensivo em igreja durante culto configura perturbacao de culto e vilipendio a objeto de culto (art. 208). Pode haver concurso com dano.",
  },
  {
    id: 46,
    fonte: "PC-CE - 2023",
    enunciado:
      "Profanar sepultura escrevendo pichacoes ofensivas no tumulo configura",
    alternativas: [
      { letra: "a", texto: "crime de dano e violacao de sepultura." },
      { letra: "b", texto: "apenas crime de dano." },
      { letra: "c", texto: "crime de violacao de sepultura (profanacao - art. 210)." },
      { letra: "d", texto: "contravencao de pichacao." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Pichar tumulo com ofensas e profanar sepultura (art. 210). Pode haver concurso com dano (art. 163).",
  },
  {
    id: 47,
    fonte: "OAB - LX Exame",
    enunciado:
      "Medico legista, durante exame, remove orgaos de cadaver sem autorizacao da familia, para pesquisa. Configura",
    alternativas: [
      { letra: "a", texto: "crime de destruicao/subtracao de parte de cadaver (art. 211)." },
      { letra: "b", texto: "exercicio regular da funcao." },
      { letra: "c", texto: "crime de violacao de sepultura." },
      { letra: "d", texto: "ilicito etico-profissional." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Remover orgaos sem autorizacao e subtracao de parte de cadaver. A funcao nao autoriza desrespeito a vontade da familia ou a lei (Lei de Transplantes).",
  },
  {
    id: 48,
    fonte: "TJ-MT - 2022",
    enunciado:
      "O crime de impedir culto religioso (art. 208) se consuma quando",
    alternativas: [
      { letra: "a", texto: "ha planejamento do impedimento." },
      { letra: "b", texto: "ocorre efetivo impedimento ou perturbacao." },
      { letra: "c", texto: "a vitima fica intimidada." },
      { letra: "d", texto: "o culto e cancelado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Consuma-se com o impedimento ou perturbacao efetivos. E crime de perigo concreto (perturbacao) ou dano (impedimento).",
  },
  {
    id: 49,
    fonte: "OAB - LXI Exame",
    enunciado:
      "Em transmissao online, grupo satanico realiza ritual que 'excomunga' lider religioso especifico. Configura",
    alternativas: [
      { letra: "a", texto: "crime de ultraje a culto (escarnecer por funcao religiosa - art. 208)." },
      { letra: "b", texto: "liberdade de crenca e culto." },
      { letra: "c", texto: "crime de ameaca." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Ritual satanico, mesmo que ofensivo a outras crencas, e exercicio da liberdade de culto. So configura crime se houver escarnio direto e publico a pessoa por sua crenca/funcao.",
  },
  {
    id: 50,
    fonte: "MPE-MA - 2023",
    enunciado:
      "Destruir cadaver ja em decomposicao avancada (esqueletizado)",
    alternativas: [
      { letra: "a", texto: "nao e crime, pois nao ha mais cadaver." },
      { letra: "b", texto: "e crime de destruicao de cadaver (art. 211)." },
      { letra: "c", texto: "e crime de violacao de sepultura." },
      { letra: "d", texto: "e crime de vilipendio a cadaver." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Esqueletos ainda sao partes de cadaver. Destrui-los configura crime, pois o respeito aos mortos perdura independentemente do estado de decomposicao.",
  },
];
