import { type Questao } from "./questoes-vida";

export const questoesOrganizacaoTrabalho: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Empregador, mediante ameaca de demissao, obriga empregado a trabalhar aos domingos, contrariando sua vontade. O empregador comete",
    alternativas: [
      { letra: "a", texto: "crime contra a organizacao do trabalho (art. 197, I, CP)." },
      { letra: "b", texto: "crime de constrangimento ilegal." },
      { letra: "c", texto: "ilicito trabalhista apenas." },
      { letra: "d", texto: "crime de reducao a condicao analoga a de escravo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Constranger alguem a trabalhar em determinados dias (domingo) mediante grave ameaca configura atentado contra a liberdade de trabalho (art. 197, I). E crime especifico, nao mero constrangimento ilegal.",
  },
  {
    id: 2,
    fonte: "MPE-SP - 2023",
    enunciado:
      "No crime de atentado contra a liberdade de contrato de trabalho (art. 198), a conduta tipificada e",
    alternativas: [
      { letra: "a", texto: "demitir sem justa causa." },
      { letra: "b", texto: "coagir alguem a contratar ou nao contratar trabalhador." },
      { letra: "c", texto: "exercer profissao sem registro." },
      { letra: "d", texto: "nao pagar salario." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 198 pune quem, mediante violencia ou grave ameaca, coage alguem a contratar ou a nao contratar determinado trabalhador. Tutela a liberdade contratual.",
  },
  {
    id: 3,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Sindicato, para pressionar empresa, promove paralisacao dos trabalhadores, que mantem a posse da fabrica e impedem a entrada de nao grevistas. Ha violencia. Configura",
    alternativas: [
      { letra: "a", texto: "greve licita." },
      { letra: "b", texto: "crime de paralisacao de trabalho seguida de violencia (art. 200, CP)." },
      { letra: "c", texto: "crime de atentado contra a liberdade de trabalho." },
      { letra: "d", texto: "exercicio regular de direito de greve." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Greve e direito, mas paralisacao acompanhada de violencia ou perturbacao da ordem configura crime do art. 200. A manutencao da posse do estabelecimento com impedimento de entrada pode caracterizar violencia.",
  },
  {
    id: 4,
    fonte: "PC-DF - 2022",
    enunciado: "Sabotagem (art. 202, caput) consiste em",
    alternativas: [
      { letra: "a", texto: "apenas destruir maquina de producao." },
      { letra: "b", texto: "destruir, inutilizar ou deteriorar coisa alheia, para dificultar ou impedir trabalho alheio." },
      { letra: "c", texto: "dificultar trabalho por meio de ameaca." },
      { letra: "d", texto: "organizar boicote economico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Sabotagem: destruir, inutilizar ou deteriorar coisa alheia, com o fim de dificultar ou impedir trabalho alheio. E crime de dano com elemento subjetivo especial.",
  },
  {
    id: 5,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "Empresario, para evitar sindicalizacao, ameaca demitir trabalhadores que se filiarem ao sindicato. Comete",
    alternativas: [
      { letra: "a", texto: "atentado contra a liberdade de associacao (art. 199, CP)." },
      { letra: "b", texto: "crime contra a organizacao sindical." },
      { letra: "c", texto: "ilicito trabalhista apenas." },
      { letra: "d", texto: "crime de constrangimento ilegal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ameacar para impedir associacao sindical configura atentado contra a liberdade de associacao (art. 199). E crime especifico, com pena de detencao, de 1 a 3 anos.",
  },
  {
    id: 6,
    fonte: "TJ-RJ - 2021",
    enunciado:
      "Competencia para julgar crimes contra a organizacao do trabalho, quando ofendem o sistema de orgaos e instituicoes de protecao coletiva, e da",
    alternativas: [
      { letra: "a", texto: "Justica do Trabalho." },
      { letra: "b", texto: "Justica Estadual." },
      { letra: "c", texto: "Justica Federal (art. 109, VI, CF)." },
      { letra: "d", texto: "Justica Militar." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Conforme art. 109, VI, CF/88, a Justica Federal processa e julga os crimes contra a organizacao do trabalho, quando a ofensa for ao sistema de orgaos e instituicoes de protecao coletiva.",
  },
  {
    id: 7,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      "Trabalhador, descontente, desliga maquina essencial da linha de producao, causando prejuizo a empresa. Nao ha violencia. Configura",
    alternativas: [
      { letra: "a", texto: "crime de sabotagem (art. 202)." },
      { letra: "b", texto: "dano qualificado." },
      { letra: "c", texto: "crime de paralisacao de trabalho." },
      { letra: "d", texto: "ilicito trabalhista." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Inutilizar/deteriorar coisa (maquina) para impedir ou dificultar trabalho alheio caracteriza sabotagem, mesmo sem violencia contra pessoas. E crime de dano com fim especifico.",
  },
  {
    id: 8,
    fonte: "MPE-MG - 2023",
    enunciado:
      "Boicotagem violenta (art. 198, paragrafo unico) exige",
    alternativas: [
      { letra: "a", texto: "apenas campanha publicitaria contra empresa." },
      { letra: "b", texto: "violencia ou grave ameaca para impedir compra ou venda de mercadoria." },
      { letra: "c", texto: "paralisacao coletiva de trabalhadores." },
      { letra: "d", texto: "sabotagem de maquinas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Boicotagem violenta: empregar violencia ou grave ameaca para impedir ou dificultar a compra ou venda de mercadoria. Difere da boicotagem pacifica, que e licita.",
  },
  {
    id: 9,
    fonte: "OAB - XL Exame",
    enunciado:
      "Empregador deixa de pagar salario minimo, frustrando direito assegurado por lei trabalhista. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito assegurado por lei trabalhista (art. 203, CP)." },
      { letra: "b", texto: "crime de apropriacao indebita." },
      { letra: "c", texto: "ilicito trabalhista apenas." },
      { letra: "d", texto: "crime de sonegacao fiscal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Frustrar, mediante fraude ou violencia, direito assegurado por lei trabalhista (ex.: salario minimo) configura crime do art. 203. E necessario o elemento subjetivo (fraude ou violencia).",
  },
  {
    id: 10,
    fonte: "PC-PR - 2022",
    enunciado:
      "Crime de aliciamento para fim de emigracao (art. 206) exige",
    alternativas: [
      { letra: "a", texto: "apenas promessa de emprego no exterior." },
      { letra: "b", texto: "aliciar trabalhador, mediante fraude, para servico no estrangeiro." },
      { letra: "c", texto: "transporte de trabalhador para outra regiao do pais." },
      { letra: "d", texto: "contratacao de estrangeiro sem autorizacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Aliciar, mediante fraude, trabalhador para servico no estrangeiro configura crime do art. 206. E protecao contra trafico de pessoas para trabalho.",
  },
  {
    id: 11,
    fonte: "OAB - XLI Exame",
    enunciado:
      "Durante greve, trabalhadores bloqueiam acesso a fabrica, impedindo entrada de caminhoes. Ha ameacas a motoristas. Configura",
    alternativas: [
      { letra: "a", texto: "greve licita." },
      { letra: "b", texto: "crime de paralisacao de trabalho com violencia (art. 200)." },
      { letra: "c", texto: "crime de atentado contra a liberdade de trabalho." },
      { letra: "d", texto: "crime de sequestro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Paralisacao acompanhada de violencia ou grave ameaca (impedimento com ameacas) configura crime do art. 200. O direito de greve nao protege atos violentos.",
  },
  {
    id: 12,
    fonte: "TJ-SP - 2022",
    enunciado:
      "Exercicio de profissao ou atividade com infracao de decisao administrativa (art. 205) e crime",
    alternativas: [
      { letra: "a", texto: "contra a administracao publica." },
      { letra: "b", texto: "contra a organizacao do trabalho." },
      { letra: "c", texto: "de desobediencia." },
      { letra: "d", texto: "de exercicio ilegal da profissao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Esta inserido no Capitulo 'Dos crimes contra a organizacao do trabalho'. Exerce profissao ou atividade em infracao de decisao administrativa (ex.: interdicao por falta de seguranca).",
  },
  {
    id: 13,
    fonte: "OAB - XLII Exame",
    enunciado:
      "Empregador, para impedir fiscalizacao, esconde documentos trabalhistas. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime contra a administracao publica." },
      { letra: "c", texto: "crime de falsidade ideologica." },
      { letra: "d", texto: "ilicito administrativo apenas." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Frustrar direito trabalhista mediante fraude (esconder documentos para impedir fiscalizacao) pode configurar art. 203. Tambem pode configurar crime contra a administracao.",
  },
  {
    id: 14,
    fonte: "MPE-RS - 2021",
    enunciado:
      "Crime de aliciamento de trabalhadores de um local para outro do territorio nacional (art. 207)",
    alternativas: [
      { letra: "a", texto: "exige fraude." },
      { letra: "b", texto: "exige violencia." },
      { letra: "c", texto: "exige apenas transporte interestadual." },
      { letra: "d", texto: "nao exige elemento subjetivo especifico." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 207 exige aliciamento mediante fraude para transportar trabalhadores de uma para outra localidade no territorio nacional. Visa coibir trafico interno.",
  },
  {
    id: 15,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Sindicalista, mediante ameaca, obriga empresario a fechar acordo coletivo desfavoravel. Configura",
    alternativas: [
      { letra: "a", texto: "exercicio regular do direito de representacao." },
      { letra: "b", texto: "crime de atentado contra a liberdade de contrato de trabalho (art. 198)." },
      { letra: "c", texto: "crime de extorsao." },
      { letra: "d", texto: "crime de constrangimento ilegal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Coagir, mediante violencia ou grave ameaca, a celebrar ou rescindir contrato de trabalho caracteriza atentado contra a liberdade de contrato (art. 198). Pode haver concurso com extorsao.",
  },
  {
    id: 16,
    fonte: "PC-MG - 2023",
    enunciado:
      "Paralisacao de trabalho de interesse coletivo (art. 201) exige que a paralisacao",
    alternativas: [
      { letra: "a", texto: "cause grave perturbacao a ordem publica." },
      { letra: "b", texto: "seja em servico essencial." },
      { letra: "c", texto: "tenha motivacao politica." },
      { letra: "d", texto: "seja realizada por funcionario publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 201 pune a paralisacao coletiva de empregados, em servicos essenciais ou atividades de relevante interesse coletivo. E crime mesmo sem violencia, devido ao carater essencial.",
  },
  {
    id: 17,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Empregador contrata menor de 16 anos, frustrando lei sobre trabalho infantil. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de lei sobre nacionalizacao do trabalho (art. 204)." },
      { letra: "b", texto: "crime de frustracao de direito assegurado por lei trabalhista (art. 203)." },
      { letra: "c", texto: "crime do Estatuto da Crianca." },
      { letra: "d", texto: "ilicito administrativo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Contratar menor em desacordo com a lei frustra direito assegurado por lei trabalhista (protecao ao menor). Art. 203 exige fraude ou violencia; a contratacao direta pode ser fraude.",
  },
  {
    id: 18,
    fonte: "TJ-PR - 2022",
    enunciado:
      "Invasao de estabelecimento industrial (art. 202, par. 1)",
    alternativas: [
      { letra: "a", texto: "so configura crime se houver violencia." },
      { letra: "b", texto: "e crime mesmo sem violencia, desde que com intuito de impedir trabalho." },
      { letra: "c", texto: "exige dano as instalacoes." },
      { letra: "d", texto: "e contravencao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A invasao por turba ou em grupo de mais de 4 pessoas, com intuito de impedir/dificultar trabalho, e crime mesmo sem violencia (par. 1). Se houver violencia, ha aumento de pena (par. 2).",
  },
  {
    id: 19,
    fonte: "OAB - XLV Exame",
    enunciado:
      "Empregador obriga trabalhador, sob ameaca de demissao, a nao se filiar a sindicato. Configura",
    alternativas: [
      { letra: "a", texto: "crime de atentado contra a liberdade de associacao (art. 199)." },
      { letra: "b", texto: "crime de constrangimento ilegal." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de ameaca." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Impedir, mediante violencia ou grave ameaca, associacao sindical caracteriza atentado contra a liberdade de associacao (art. 199). Ameaca de demissao injusta pode configurar grave ameaca.",
  },
  {
    id: 20,
    fonte: "MPE-ES - 2022",
    enunciado:
      "Sabotagem qualificada (art. 202, par. 2) ocorre quando",
    alternativas: [
      { letra: "a", texto: "ha concurso de agentes." },
      { letra: "b", texto: "o crime e cometido com violencia." },
      { letra: "c", texto: "o bem e de valor elevado." },
      { letra: "d", texto: "ha dolo especifico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A sabotagem e qualificada se cometida com violencia a pessoa (par. 2). A pena aumenta de 1/3. A violencia pode ser fisica ou moral grave.",
  },
  {
    id: 21,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "Grupo de trabalhadores, sem violencia, invade fabrica e desliga maquinas para paralisar producao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de invasao de estabelecimento industrial (art. 202, par. 1)." },
      { letra: "b", texto: "greve licita." },
      { letra: "c", texto: "crime de sabotagem." },
      { letra: "d", texto: "crime de paralisacao de trabalho." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Invasao por turba ou mais de 4 pessoas, com fim de impedir trabalho, configura crime do par. 1 do art. 202, mesmo sem violencia. Se desligar maquinas, tambem pode ser sabotagem.",
  },
  {
    id: 22,
    fonte: "PC-SP - 2023",
    enunciado:
      "Frustracao de lei sobre nacionalizacao do trabalho (art. 204) pune quem",
    alternativas: [
      { letra: "a", texto: "contrata estrangeiro sem autorizacao." },
      { letra: "b", texto: "paga abaixo do salario minimo." },
      { letra: "c", texto: "impede associacao sindical." },
      { letra: "d", texto: "nao registra carteira." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 204 pune quem, mediante fraude, frustra disposicao legal sobre nacionalizacao do trabalho (ex.: lei que exige certa porcentagem de brasileiros). Contratar estrangeiro ilegalmente pode configurar.",
  },
  {
    id: 23,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "Durante greve em hospital, trabalhadores impedem entrada de medicos, causando grave risco a pacientes. Configura",
    alternativas: [
      { letra: "a", texto: "crime de paralisacao de trabalho em servico essencial (art. 201)." },
      { letra: "b", texto: "greve licita, pois hospital e essencial." },
      { letra: "c", texto: "crime de sabotagem." },
      { letra: "d", texto: "crime de omissao de socorro." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Paralisacao em servico essencial (hospital) configura crime do art. 201, independentemente de violencia. O impedimento de entrada agrava a situacao.",
  },
  {
    id: 24,
    fonte: "TJ-MG - 2021",
    enunciado:
      "Competencia para julgar crime de sabotagem em empresa privada, sem ofensa a orgaos de protecao coletiva, e da",
    alternativas: [
      { letra: "a", texto: "Justica Federal." },
      { letra: "b", texto: "Justica Estadual." },
      { letra: "c", texto: "Justica do Trabalho." },
      { letra: "d", texto: "Justica Militar." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Se o crime nao ofende o sistema de orgaos e instituicoes de protecao coletiva do trabalho, a competencia e da Justica Estadual (regra comum). A Justica Federal so e competente na hipotese do art. 109, VI, CF.",
  },
  {
    id: 25,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "Empregador, mediante fraude, apresenta falsos registros de ponto para negar horas extras. Configura",
    alternativas: [
      { letra: "a", texto: "crime de falsidade ideologica." },
      { letra: "b", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "c", texto: "ilicito trabalhista apenas." },
      { letra: "d", texto: "crime de estelionato." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Apresentar falsos registros de ponto e fraude para frustrar direito trabalhista (horas extras). Configura art. 203. A falsificacao e o meio fraudulento.",
  },
  {
    id: 26,
    fonte: "MPE-BA - 2023",
    enunciado:
      "Atentado contra a liberdade de trabalho (art. 197) tutela",
    alternativas: [
      { letra: "a", texto: "apenas o direito do empregador." },
      { letra: "b", texto: "a liberdade de escolha de trabalho do individuo." },
      { letra: "c", texto: "o direito de greve." },
      { letra: "d", texto: "a organizacao sindical." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 197 tutela a liberdade de escolha de trabalho. Pune quem constrange alguem a exercer ou deixar de exercer arte, oficio, profissao ou industria, mediante violencia ou grave ameaca.",
  },
  {
    id: 27,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "Empregador retira documentos pessoais do trabalhador para impedi-lo de pedir demissao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203, par. 1)." },
      { letra: "b", texto: "crime de furto." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de sequestro." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O par. 1 do art. 203 inclui como conduta tipica reter documentos pessoais ou contratuais do trabalhador, para cercear sua liberdade de rescisao contratual.",
  },
  {
    id: 28,
    fonte: "PC-RJ - 2022",
    enunciado:
      "Paralisacao de trabalho (art. 200) difere de greve licita porque",
    alternativas: [
      { letra: "a", texto: "greve e sempre crime." },
      { letra: "b", texto: "a paralisacao do art. 200 envolve violencia ou perturbacao da ordem." },
      { letra: "c", texto: "greve so e licita no setor publico." },
      { letra: "d", texto: "paralisacao so ocorre no setor privado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A greve e direito constitucional (art. 9, CF). O art. 200 criminaliza a paralisacao acompanhada de violencia contra pessoa ou coisa, ou perturbacao da ordem.",
  },
  {
    id: 29,
    fonte: "OAB - L Exame",
    enunciado:
      "Empresa recruta trabalhadores rurais com promessas falsas de boas condicoes de trabalho e os transporta para fazenda em outro estado. Configura",
    alternativas: [
      { letra: "a", texto: "crime de aliciamento de trabalhadores (art. 207)." },
      { letra: "b", texto: "crime de trafico de pessoas." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de estelionato." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Aliciar trabalhadores mediante fraude (promessas falsas) para outra localidade do territorio nacional configura crime do art. 207. E o trafico interno de trabalhadores.",
  },
  {
    id: 30,
    fonte: "TJ-RS - 2023",
    enunciado:
      "Crime de atentado contra a liberdade de associacao (art. 199) protege",
    alternativas: [
      { letra: "a", texto: "a liberdade de associacao profissional ou sindical." },
      { letra: "b", texto: "apenas a liberdade partidaria." },
      { letra: "c", texto: "a liberdade de expressao." },
      { letra: "d", texto: "o direito de reuniao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 199 protege a liberdade de associacao profissional ou sindical. Pune quem constrange alguem a participar ou deixar de participar de associacao.",
  },
  {
    id: 31,
    fonte: "OAB - LI Exame",
    enunciado:
      "Empregador obriga trabalhador a comprar alimentos exclusivamente no armazem da fazenda, a precos abusivos. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime de reducao a condicao analoga a de escravo (art. 149)." },
      { letra: "c", texto: "crime de extorsao." },
      { letra: "d", texto: "ilicito trabalhista." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Obrigar o trabalhador a comprar no 'barracão' (truck system) a precos abusivos e uma das formas de reducao a condicao analoga a de escravo (art. 149). Pode haver concurso com art. 203.",
  },
  {
    id: 32,
    fonte: "MPE-PR - 2022",
    enunciado:
      "Crime de exercicio de atividade com infracao de decisao administrativa (art. 205) tem pena de",
    alternativas: [
      { letra: "a", texto: "detencao, de 3 meses a 2 anos." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "detencao, de 6 meses a 2 anos, ou multa." },
      { letra: "d", texto: "reclusao, de 2 a 5 anos." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 205 preve pena de detencao, de 6 meses a 2 anos, ou multa, para quem exerce atividade com infracao de decisao administrativa.",
  },
  {
    id: 33,
    fonte: "OAB - LII Exame",
    enunciado:
      "Intermediario recruta trabalhadores rurais com promessas de salarios altos e os leva para outra cidade, onde sao submetidos a condicoes degradantes. Configura",
    alternativas: [
      { letra: "a", texto: "crime de aliciamento (art. 207) e reducao a condicao analoga a de escravo (art. 149)." },
      { letra: "b", texto: "apenas ilicito trabalhista." },
      { letra: "c", texto: "crime de estelionato." },
      { letra: "d", texto: "crime de constrangimento ilegal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ha concurso de crimes: aliciamento mediante fraude (art. 207) e reducao a condicao analoga a de escravo (art. 149) pelas condicoes degradantes. Os tipos penais se somam.",
  },
  {
    id: 34,
    fonte: "PC-GO - 2023",
    enunciado:
      "No art. 197, II, do CP, constranger alguem a abrir ou fechar estabelecimento de trabalho configura",
    alternativas: [
      { letra: "a", texto: "crime de constrangimento ilegal." },
      { letra: "b", texto: "atentado contra a liberdade de trabalho." },
      { letra: "c", texto: "crime de extorsao." },
      { letra: "d", texto: "crime de ameaca." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O inciso II do art. 197 pune quem constrange alguem a abrir ou fechar estabelecimento de trabalho, mediante violencia ou grave ameaca. E modalidade especifica de atentado contra a liberdade de trabalho.",
  },
  {
    id: 35,
    fonte: "OAB - LIII Exame",
    enunciado:
      "Empregador nao recolhe FGTS dos empregados, frustrando direito trabalhista. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime de apropriacao indebita previdenciaria." },
      { letra: "c", texto: "ilicito trabalhista apenas." },
      { letra: "d", texto: "crime de sonegacao fiscal." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Nao recolher FGTS, mediante fraude, frustra direito assegurado por lei trabalhista. Configura art. 203 se houver elemento fraudulento. Pode haver concurso com apropriacoes previdenciarias.",
  },
  {
    id: 36,
    fonte: "TJ-SC - 2022",
    enunciado:
      "Greve e direito constitucional (art. 9, CF). A lei penal pune",
    alternativas: [
      { letra: "a", texto: "toda greve." },
      { letra: "b", texto: "apenas greve com violencia ou em servico essencial sem manutencao minima." },
      { letra: "c", texto: "apenas greve no setor publico." },
      { letra: "d", texto: "greve que dure mais de 30 dias." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A CF garante o direito de greve. A lei penal pune greve com violencia (art. 200) e paralisacao em servico essencial sem manutencao dos servicos indispensaveis (art. 201).",
  },
  {
    id: 37,
    fonte: "OAB - LIV Exame",
    enunciado:
      "Empregador ameaca denunciar trabalhador irregular a autoridade migratoria para impedi-lo de reclamar direitos. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime de denuncia caluniosa." },
      { letra: "c", texto: "exercicio regular de direito." },
      { letra: "d", texto: "crime de ameaca." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ameacar para frustrar direito trabalhista (reclamacao) configura art. 203. A ameaca de denuncia a autoridade migratoria e forma de coacao para impedir o exercicio de direitos.",
  },
  {
    id: 38,
    fonte: "MPE-GO - 2023",
    enunciado:
      "O crime de sabotagem (art. 202) e crime",
    alternativas: [
      { letra: "a", texto: "de mera conduta." },
      { letra: "b", texto: "material, exige resultado (dano)." },
      { letra: "c", texto: "formal." },
      { letra: "d", texto: "de perigo abstrato." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A sabotagem e crime material: exige resultado (destruicao, inutilizacao ou deterioracao de coisa alheia). Alem disso, exige o dolo especifico de impedir ou dificultar trabalho.",
  },
  {
    id: 39,
    fonte: "OAB - LV Exame",
    enunciado:
      "Empregador obriga empregados a assinar contrato em branco, sob ameaca de nao contratacao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de atentado contra a liberdade de contrato de trabalho (art. 198)." },
      { letra: "b", texto: "crime de falsidade ideologica." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de estelionato." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Coagir mediante ameaca (nao contratacao) a celebrar contrato em termos desfavoraveis (branco) configura atentado contra a liberdade contratual (art. 198).",
  },
  {
    id: 40,
    fonte: "PC-BA - 2022",
    enunciado:
      "Aliciamento para emigracao (art. 206) tem pena de",
    alternativas: [
      { letra: "a", texto: "detencao, de 1 a 3 anos, e multa." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "detencao, de 6 meses a 2 anos." },
      { letra: "d", texto: "reclusao, de 2 a 5 anos." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 206 preve pena de detencao, de 1 a 3 anos, e multa, para quem aliciar trabalhador para emigracao.",
  },
  {
    id: 41,
    fonte: "OAB - LVI Exame",
    enunciado:
      "Empregador mantem trabalhadores em alojamento insalubre, sem condicoes minimas de higiene. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime de reducao a condicao analoga a de escravo (art. 149)." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de periclitacao da vida." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Manter trabalhadores em condicoes degradantes configura reducao a condicao analoga a de escravo (art. 149). E uma das modalidades tipicas desse crime.",
  },
  {
    id: 42,
    fonte: "TJ-RS - 2021",
    enunciado:
      "Empregador impede trabalhador de se desligar do servico, retendo seus documentos e nao pagando verbas rescisorias. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203, par. 1)." },
      { letra: "b", texto: "crime de carcere privado." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de extorsao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Reter documentos e verbas rescisorias para impedir o desligamento configura frustracao de direito trabalhista (art. 203, par. 1). E forma de coacao pela retencao.",
  },
  {
    id: 43,
    fonte: "OAB - LVII Exame",
    enunciado:
      "Comerciante obriga fornecedor, sob ameaca, a nao vender para concorrente. Configura",
    alternativas: [
      { letra: "a", texto: "boicotagem violenta (art. 198, paragrafo unico)." },
      { letra: "b", texto: "crime de concorrencia desleal." },
      { letra: "c", texto: "crime de extorsao." },
      { letra: "d", texto: "ilicito civil." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Empregar violencia ou grave ameaca para impedir venda de mercadoria configura boicotagem violenta (art. 198, paragrafo unico). E modalidade especifica de crime contra a organizacao do trabalho.",
  },
  {
    id: 44,
    fonte: "MPE-MT - 2023",
    enunciado:
      "O crime de paralisacao de trabalho em servico essencial (art. 201) e de acao penal",
    alternativas: [
      { letra: "a", texto: "publica incondicionada." },
      { letra: "b", texto: "publica condicionada a representacao." },
      { letra: "c", texto: "privada." },
      { letra: "d", texto: "publica condicionada a requisicao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Os crimes contra a organizacao do trabalho sao, em regra, de acao penal publica incondicionada. O Ministerio Publico e o titular da acao.",
  },
  {
    id: 45,
    fonte: "OAB - LVIII Exame",
    enunciado:
      "Empregador exige que trabalhadores comprem uniforme da propria empresa a precos exorbitantes, descontando do salario. Configura",
    alternativas: [
      { letra: "a", texto: "crime de frustracao de direito trabalhista (art. 203)." },
      { letra: "b", texto: "crime de extorsao." },
      { letra: "c", texto: "ilicito trabalhista." },
      { letra: "d", texto: "crime de estelionato." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Descontar valores abusivos do salario para compra de uniforme frustra direito trabalhista (intangibilidade salarial). Configura art. 203 se houver elemento de fraude ou coacao.",
  },
  {
    id: 46,
    fonte: "PC-CE - 2023",
    enunciado:
      "Aliciamento de trabalhadores para outra localidade (art. 207) visa coibir",
    alternativas: [
      { letra: "a", texto: "migracao interna voluntaria." },
      { letra: "b", texto: "trafico interno de trabalhadores." },
      { letra: "c", texto: "contratacao interestadual legal." },
      { letra: "d", texto: "trabalho escravo apenas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O crime visa coibir o trafico interno de trabalhadores, onde pessoas sao aliciadas mediante fraude para trabalhar em outra regiao, muitas vezes em condicoes analogas a escravidao.",
  },
  {
    id: 47,
    fonte: "OAB - LIX Exame",
    enunciado:
      "Empregador, para burlar lei que exige 2/3 de brasileiros na empresa, falsifica documentos de estrangeiros. Configura",
    alternativas: [
      { letra: "a", texto: "crime de falsidade ideologica." },
      { letra: "b", texto: "crime de frustracao de lei sobre nacionalizacao do trabalho (art. 204)." },
      { letra: "c", texto: "crime de contrabando de migrantes." },
      { letra: "d", texto: "crime de sonegacao fiscal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Frustrar, mediante fraude, disposicao legal sobre nacionalizacao do trabalho (cota de brasileiros) configura art. 204. A falsificacao de documentos e o meio fraudulento.",
  },
  {
    id: 48,
    fonte: "TJ-MT - 2022",
    enunciado:
      "Invasao de estabelecimento comercial por mais de 4 pessoas, sem violencia, mas com intuito de impedir trabalho, e crime",
    alternativas: [
      { letra: "a", texto: "de invasao de domicilio." },
      { letra: "b", texto: "de formacao de quadrilha." },
      { letra: "c", texto: "de invasao de estabelecimento industrial (art. 202, par. 1)." },
      { letra: "d", texto: "de constrangimento ilegal." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O par. 1 do art. 202 abrange estabelecimento industrial, comercial ou agricola. A invasao por grupo com intuito de impedir trabalho configura crime, mesmo sem violencia.",
  },
  {
    id: 49,
    fonte: "OAB - LX Exame",
    enunciado:
      "Durante greve, trabalhadores ocupam fabrica e danificam maquinas para impedir producao. Configura",
    alternativas: [
      { letra: "a", texto: "crime de sabotagem e invasao de estabelecimento." },
      { letra: "b", texto: "greve licita com ocupacao." },
      { letra: "c", texto: "crime de dano apenas." },
      { letra: "d", texto: "crime de paralisacao com violencia." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Ocupar (invasao) e danificar maquinas para impedir trabalho configuram invasao de estabelecimento (par. 1) e sabotagem (caput). Podem estar conjugados.",
  },
  {
    id: 50,
    fonte: "MPE-MA - 2023",
    enunciado:
      "Crime de paralisacao de trabalho seguida de violencia (art. 200) tem pena de",
    alternativas: [
      { letra: "a", texto: "detencao, de 1 a 3 anos." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "detencao, de 6 meses a 2 anos." },
      { letra: "d", texto: "reclusao, de 2 a 5 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Art. 200: pena de reclusao, de 1 a 3 anos. E mais grave que outros crimes do capitulo, pois envolve violencia.",
  },
];
