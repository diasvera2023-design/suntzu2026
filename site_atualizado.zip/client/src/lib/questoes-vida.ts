export interface Questao {
  id: number;
  fonte: string;
  enunciado: string;
  alternativas: { letra: string; texto: string }[];
  respostaCorreta: string;
  explicacao: string;
}

export const questoesCrimesContraVida: Questao[] = [
  {
    id: 1,
    fonte: "OAB - XXIX Exame",
    enunciado:
      'Um homem, durante discussao, desfere golpes de faca contra a vitima, que vem a falecer no local. O agente alega que agiu sob o dominio de violenta emocao, logo em seguida a injusta provocacao da vitima. Nesse caso, a causa de diminuicao de pena prevista no art. 121, \u00a7 1\u00ba, do CP',
    alternativas: [
      { letra: "a", texto: "nao se aplica, pois a emocao violenta deve preceder a conduta." },
      { letra: "b", texto: "nao se aplica, pois a provocacao nao foi considerada injusta." },
      { letra: "c", texto: "aplica-se, desde que comprovado o nexo causal." },
      { letra: "d", texto: "aplica-se independentemente de a emocao ser anterior ou posterior a conduta." },
    ],
    respostaCorreta: "a",
    explicacao:
      'Segundo a doutrina e jurisprudencia, a "violenta emocao" deve ser anterior a conduta homicida, e nao posterior. A emocao provocada pela injusta provocacao da vitima deve existir no momento da acao.',
  },
  {
    id: 2,
    fonte: "OAB - XXX Exame",
    enunciado:
      "Maria, gestante, consente que um medico realize aborto nela. O medico, apos receber o pagamento, provoca o aborto. Em relacao ao medico, configura-se o crime de",
    alternativas: [
      { letra: "a", texto: "aborto consentido (art. 126, CP), com pena de reclusao de 1 a 4 anos." },
      { letra: "b", texto: "aborto sem consentimento (art. 125, CP), pois o consentimento da gestante e irrelevante." },
      { letra: "c", texto: "aborto consentido, mas com aumento de pena por exercer a medicina." },
      { letra: "d", texto: "aborto proprio (art. 124, CP), pois so a gestante poderia responder pelo crime." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 126 do CP pune quem provoca aborto com o consentimento da gestante. O consentimento e elemento que diferencia o art. 126 (pena menor) do art. 125 (sem consentimento, pena maior).",
  },
  {
    id: 3,
    fonte: "MPE-SP - 2019",
    enunciado:
      "No crime de homicidio qualificado pelo motivo futil, o motivo futil deve ser",
    alternativas: [
      { letra: "a", texto: "qualquer motivo irrelevante, desde que presente na mente do agente." },
      { letra: "b", texto: "motivo de relevante valor social ou moral." },
      { letra: "c", texto: "motivo irrelevante do ponto de vista do agente e da sociedade." },
      { letra: "d", texto: "motivo que justifique a conduta perante a sociedade." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O motivo futil, para qualificar o homicidio (art. 121, \u00a72\u00ba, I), deve ser irrelevante tanto para o agente quanto para os padroes sociais objetivos.",
  },
  {
    id: 4,
    fonte: "OAB - XXVII Exame",
    enunciado:
      "Joao, desempregado e deprimido, pede a seu amigo Pedro que lhe empreste uma arma para cometer suicidio. Pedro, com pena, entrega a arma. Joao atira contra si, mas sobrevive com lesoes graves. A conduta de Pedro caracteriza",
    alternativas: [
      { letra: "a", texto: "homicidio tentado, pois houve auxilio a morte." },
      { letra: "b", texto: "crime de induzimento, instigacao ou auxilio ao suicidio, na forma tentada." },
      { letra: "c", texto: "crime de induzimento, instigacao ou auxilio ao suicidio, com lesao grave, na modalidade auxilio material." },
      { letra: "d", texto: "nada, pois o suicidio nao e crime." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 122, \u00a71\u00ba, do CP (redacao da Lei 13.968/2019) preve pena maior quando o suicidio ou automutilacao resulta em lesao corporal grave ou gravissima. Pedro praticou auxilio material para o suicidio (art. 122, caput).",
  },
  {
    id: 5,
    fonte: "PC-DF - 2018",
    enunciado: "No crime de infanticidio, o estado puerperal",
    alternativas: [
      { letra: "a", texto: "e isentante de pena, por tratar-se de doenca mental." },
      { letra: "b", texto: "e causa de diminuicao de pena, por atenuar a culpabilidade." },
      { letra: "c", texto: "e elementar do tipo, comunicando-se a participes e cooperadores." },
      { letra: "d", texto: "e irrelevante, pois o crime e o mesmo homicidio." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A doutrina majoritaria entende que o estado puerperal e elementar do tipo do infanticidio (art. 123, CP), comunicando-se aos coautores e participes (art. 30, CP).",
  },
  {
    id: 6,
    fonte: "OAB - XXXI Exame",
    enunciado:
      "Uma mulher, gravida de feto anencefalo, realiza aborto com auxilio medico. Em relacao a essa conduta, o STF decidiu que",
    alternativas: [
      { letra: "a", texto: "e crime de aborto, pois a vida intrauterina e protegida desde a concepcao." },
      { letra: "b", texto: "e atipico, por ausencia de bem juridico protegido (vida viavel)." },
      { letra: "c", texto: "e crime de homicidio, pois o feto ja tem vida." },
      { letra: "d", texto: "e aborto legal, com base no art. 128, II, do CP." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Na ADPF 54, o STF decidiu que a interrupcao da gestacao de feto anencefalo e atipica, por nao haver expectativa de vida viavel, nao se enquadrando nos crimes contra a vida.',
  },
  {
    id: 7,
    fonte: "TJ-SP - 2020",
    enunciado:
      "No homicidio qualificado pelo emprego de veneno, exige-se que",
    alternativas: [
      { letra: "a", texto: "o veneno seja de origem industrial." },
      { letra: "b", texto: "a morte ocorra necessariamente por envenenamento." },
      { letra: "c", texto: "o agente utilize meio insidioso ou veneno." },
      { letra: "d", texto: "o veneno seja administrado de forma cruel." },
    ],
    respostaCorreta: "c",
    explicacao:
      'O art. 121, \u00a72\u00ba, I, do CP qualifica o homicidio pelo "emprego de veneno, fogo, explosivo, asfixia, tortura ou outro meio insidioso ou cruel". O veneno e uma das modalidades de meio insidioso.',
  },
  {
    id: 8,
    fonte: "OAB - XXVIII Exame",
    enunciado:
      "O crime de homicidio privilegiado (art. 121, \u00a7 1\u00ba) exige",
    alternativas: [
      { letra: "a", texto: "injusta provocacao da vitima e violenta emocao do agente, imediatamente subsequente." },
      { letra: "b", texto: "qualquer motivo de relevante valor social ou moral." },
      { letra: "c", texto: "motivo de relevante valor moral, mesmo sem violenta emocao." },
      { letra: "d", texto: "violenta emocao, independentemente de provocacao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O homicidio privilegiado ocorre quando o agente comete o crime sob dominio de violenta emocao, logo em seguida a injusta provocacao da vitima.",
  },
  {
    id: 9,
    fonte: "MPE-RS - 2017",
    enunciado:
      "Quanto ao crime de autoaborto (art. 124, CP), e correto afirmar que",
    alternativas: [
      { letra: "a", texto: "so a gestante responde pelo crime, sendo impossivel a participacao de terceiro." },
      { letra: "b", texto: "terceiro que presta auxilio a gestante responde como participe." },
      { letra: "c", texto: "o medico que realiza o aborto a pedido da gestante responde pelo art. 126." },
      { letra: "d", texto: "a gestante nao pode ser punida se o aborto for realizado por terceiro sem seu consentimento." },
    ],
    respostaCorreta: "b",
    explicacao:
      "No autoaborto (art. 124), a gestante e autora. O terceiro que auxilia, induz ou instiga responde como participe (teoria restritiva da participacao em crime proprio).",
  },
  {
    id: 10,
    fonte: "OAB - XXXII Exame",
    enunciado:
      "Joao, sabendo que Pedro e deprimido, insiste diariamente para que ele se suicide, aproveitando-se de sua fragilidade psicologica. Pedro, enfim, comete suicidio. A conduta de Joao configura",
    alternativas: [
      { letra: "a", texto: "homicidio doloso, pois houve induzimento." },
      { letra: "b", texto: "instigacao ao suicidio, com resultado morte." },
      { letra: "c", texto: "auxilio ao suicidio, pois houve fornecimento de ideias." },
      { letra: "d", texto: "crime impossivel, pois o suicidio nao e punivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Instigar e reforcar a ideia de suicidio ja existente na vitima. O resultado morte agrava a pena para 2 a 6 anos (art. 122, \u00a72\u00ba, CP).",
  },
  {
    id: 11,
    fonte: "PC-PR - 2020",
    enunciado:
      "No crime de homicidio, o inicio da vida humana protegida se da",
    alternativas: [
      { letra: "a", texto: "desde a concepcao." },
      { letra: "b", texto: "com a nidacao do ovulo." },
      { letra: "c", texto: "com o inicio do parto." },
      { letra: "d", texto: "apos o parto, com a respiracao autonoma." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Para o crime de homicidio, a vida humana protegida e a extrauterina, iniciada com o inicio do parto (cessa a protecao do aborto).",
  },
  {
    id: 12,
    fonte: "OAB - XXVI Exame",
    enunciado:
      "O aborto legal previsto no art. 128, I, do CP (aborto necessario) exige",
    alternativas: [
      { letra: "a", texto: "risco a saude fisica ou mental da gestante." },
      { letra: "b", texto: "risco a vida da gestante, sem outro meio de salva-la." },
      { letra: "c", texto: "autorizacao judicial previa." },
      { letra: "d", texto: "consentimento do marido ou companheiro." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O aborto necessario (art. 128, I) so se justifica quando nao ha outro meio de salvar a vida da gestante (risco de morte).",
  },
  {
    id: 13,
    fonte: "TJ-RJ - 2019",
    enunciado:
      "No homicidio culposo, a causa especial de aumento de pena pelo resultado (art. 121, \u00a7 3\u00ba) aplica-se quando",
    alternativas: [
      { letra: "a", texto: "o agente deixa de prestar socorro a vitima." },
      { letra: "b", texto: "o agente foge do local para nao ser preso." },
      { letra: "c", texto: "o agente nao possuia habilitacao para dirigir." },
      { letra: "d", texto: "o crime e cometido em atividade de risco acentuado." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A causa de aumento de pena no homicidio culposo ocorre quando o agente nao socorre a vitima, foge ou impede o socorro (art. 121, \u00a7 3\u00ba).",
  },
  {
    id: 14,
    fonte: "OAB - XXV Exame",
    enunciado:
      "Mae, sob influencia do estado puerperal, mata seu filho recem-nascido. Seu marido, que nao estava sob estado puerperal, auxilia na ocultacao do cadaver. Em relacao ao marido, o crime de infanticidio",
    alternativas: [
      { letra: "a", texto: "nao se comunica, pois ele nao estava sob estado puerperal." },
      { letra: "b", texto: "comunica-se, pois o estado puerperal e elementar do tipo." },
      { letra: "c", texto: "comunica-se apenas se ele tambem estiver sob estado puerperal." },
      { letra: "d", texto: "e considerado homicidio simples." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O estado puerperal e elementar do tipo, portanto comunica-se aos participes (art. 30, CP). O marido responde por infanticidio como participe.",
  },
  {
    id: 15,
    fonte: "MPE-MG - 2018",
    enunciado: "O crime de aborto e",
    alternativas: [
      { letra: "a", texto: "de perigo abstrato." },
      { letra: "b", texto: "de dano, pois exige a destruicao do produto da concepcao." },
      { letra: "c", texto: "formal, pois consuma-se com a conduta de provocar o aborto." },
      { letra: "d", texto: "permanente, pois a situacao de gravidez se prolonga." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O aborto e crime material (exige resultado naturalistico - interrupcao da gravidez) e de dano (destruicao da vida intrauterina).",
  },
  {
    id: 16,
    fonte: "OAB - XXXIII Exame",
    enunciado:
      "Apos a Lei 13.968/2019, o crime do art. 122 do CP passou a abranger tambem",
    alternativas: [
      { letra: "a", texto: "a eutanasia." },
      { letra: "b", texto: "a automutilacao." },
      { letra: "c", texto: "o homicidio por piedade." },
      { letra: "d", texto: "o aborto eugenico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A Lei 13.968/2019 ampliou o art. 122 para incluir a inducao, instigacao ou auxilio a automutilacao.",
  },
  {
    id: 17,
    fonte: "PC-PE - 2021",
    enunciado:
      "No crime de homicidio qualificado pela ocultacao de cadaver (art. 121, \u00a7 2\u00ba, VI), e necessario",
    alternativas: [
      { letra: "a", texto: "que a ocultacao seja anterior a morte." },
      { letra: "b", texto: "que a ocultacao dificulte a investigacao." },
      { letra: "c", texto: "que o agente seja parente da vitima." },
      { letra: "d", texto: "que a ocultacao seja realizada em lugar ermo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A qualificadora da ocultacao de cadaver visa dificultar ou impossibilitar a investigacao do crime (Sumula 589, STJ).",
  },
  {
    id: 18,
    fonte: "OAB - XXIV Exame",
    enunciado: "Aborto de feto anencefalo, apos decisao do STF, e",
    alternativas: [
      { letra: "a", texto: "crime de aborto, com pena atenuada." },
      { letra: "b", texto: "aborto legal, se houver autorizacao judicial." },
      { letra: "c", texto: "atipico, por ausencia de bem juridico vida viavel." },
      { letra: "d", texto: "homicidio privilegiado." },
    ],
    respostaCorreta: "c",
    explicacao:
      'STF, na ADPF 54, reconheceu a atipicidade da conduta por nao ofender o bem juridico "vida potencialmente viavel".',
  },
  {
    id: 19,
    fonte: "TJ-ES - 2020",
    enunciado: "O homicidio culposo (art. 121, \u00a7 3\u00ba) exige",
    alternativas: [
      { letra: "a", texto: "dolo eventual." },
      { letra: "b", texto: "culpa consciente." },
      { letra: "c", texto: "negligencia, impericia ou imprudencia." },
      { letra: "d", texto: "preterdolo." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Homicidio culposo ocorre quando o agente da causa ao resultado morte por negligencia, impericia ou imprudencia.",
  },
  {
    id: 20,
    fonte: "OAB - XXXIV Exame",
    enunciado:
      "O crime de induzimento, instigacao ou auxilio ao suicidio (art. 122, CP) e",
    alternativas: [
      { letra: "a", texto: "crime proprio." },
      { letra: "b", texto: "crime de mera conduta." },
      { letra: "c", texto: "crime de perigo abstrato." },
      { letra: "d", texto: "crime material." },
    ],
    respostaCorreta: "d",
    explicacao:
      "E crime material, pois exige que a vitima tente o suicidio ou a automutilacao (ou que ocorra lesao/morte). Nao e mera conduta.",
  },
  {
    id: 21,
    fonte: "OAB - XXXV Exame",
    enunciado:
      "Um individuo, durante uma briga de transito, desfere um unico soco no rosto da vitima, que, ao cair, bate a cabeca no meio-fio e vem a falecer. Nao havia intencao de matar. O agente, logo apos, foge do local sem prestar socorro. A conduta tipifica",
    alternativas: [
      { letra: "a", texto: "homicidio doloso, pois assumiu o risco de matar." },
      { letra: "b", texto: "homicidio culposo, com causa de aumento de pena pela fuga." },
      { letra: "c", texto: "lesao corporal seguida de morte." },
      { letra: "d", texto: "homicidio preterdoloso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O agente nao quis o resultado morte, mas agiu com imprudencia ao agredir. A morte foi resultado culposo. A fuga do local sem prestar socorro e causa de aumento de pena prevista no art. 121, \u00a73\u00ba, do CP.",
  },
  {
    id: 22,
    fonte: "PC-MG - 2022",
    enunciado: "No crime de infanticidio, o estado puerperal",
    alternativas: [
      { letra: "a", texto: "deve perdurar ate o momento da acao penal." },
      { letra: "b", texto: "e equivalente a imputabilidade diminuida." },
      { letra: "c", texto: "deve ser contemporaneo a conduta de matar." },
      { letra: "d", texto: "e causa de exclusao da culpabilidade." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Para configuracao do infanticidio (art. 123, CP), o estado puerperal (perturbacao psicofisiologica decorrente do parto) deve existir no momento da conduta de matar o proprio filho, durante o parto ou logo apos.",
  },
  {
    id: 23,
    fonte: "OAB - XXXVI Exame",
    enunciado:
      "Uma mulher, apos descobrir que foi estuprada, decide interromper a gravidez com auxilio medico. Sobre o caso, e correto afirmar:",
    alternativas: [
      { letra: "a", texto: "O medico comete crime de aborto, pois o estupro nao foi previamente comprovado judicialmente." },
      { letra: "b", texto: "Trata-se de aborto legal, nos termos do art. 128, II, do CP, independentemente de autorizacao judicial." },
      { letra: "c", texto: "E necessario o consentimento do marido ou companheiro para a realizacao do aborto." },
      { letra: "d", texto: "A gestante responde pelo crime de autoaborto, pois o medico apenas auxiliou." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O aborto em caso de estupro (art. 128, II, CP) e aborto legal. Nao exige autorizacao judicial previa, conforme entendimento consolidado. A gestante nao comete crime, e o medico atua licitamente.",
  },
  {
    id: 24,
    fonte: "TJ-PR - 2021",
    enunciado:
      "No homicidio qualificado pelo motivo torpe, o motivo",
    alternativas: [
      { letra: "a", texto: "deve ser desprezivel sob o ponto de vista social." },
      { letra: "b", texto: "e aquele que revela baixo nivel moral do agente." },
      { letra: "c", texto: "precisa ser confessado espontaneamente pelo agente." },
      { letra: "d", texto: "justifica a acao perante a moral media da sociedade." },
    ],
    respostaCorreta: "b",
    explicacao:
      'Motivo torpe e aquele que revela baixeza, vileza, carater moral reprovavel do agente (ex.: matar para nao pagar uma pequena divida). Difere do motivo futil, que e irrelevante.',
  },
  {
    id: 25,
    fonte: "OAB - XXXVII Exame",
    enunciado:
      "Paulo, sabendo que Carlos esta deprimido, deixa propositalmente uma arma carregada ao seu alcance, esperando que ele cometa suicidio. Carlos, de fato, se mata. A conduta de Paulo caracteriza",
    alternativas: [
      { letra: "a", texto: "homicidio doloso por omissao." },
      { letra: "b", texto: "induzimento ao suicidio." },
      { letra: "c", texto: "instigacao ao suicidio." },
      { letra: "d", texto: "auxilio material ao suicidio." },
    ],
    respostaCorreta: "d",
    explicacao:
      "Fornecer os meios para a pratica do suicidio (arma, veneno, etc.) configura auxilio material, tipificado no art. 122, caput, do CP. A inducao seria criar a ideia; a instigacao, reforca-la.",
  },
  {
    id: 26,
    fonte: "MPE-RJ - 2020",
    enunciado:
      "O crime de aborto consentido (art. 126, CP) tem sua pena aumentada de um terco ate a metade se",
    alternativas: [
      { letra: "a", texto: "a gestante e menor de 14 anos." },
      { letra: "b", texto: "o aborto resulta em morte da gestante." },
      { letra: "c", texto: "o agente e o proprio pai do feto." },
      { letra: "d", texto: "o crime e praticado em hospital publico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 127 do CP preve aumento de pena se do aborto resulta lesao corporal grave (um terco) ou se resulta morte (metade). E um aumento pelo resultado mais grave.",
  },
  {
    id: 27,
    fonte: "OAB - XXXVIII Exame",
    enunciado:
      "A competencia para julgar crime de homicidio doloso e do",
    alternativas: [
      { letra: "a", texto: "Juizo Singular da Vara Criminal." },
      { letra: "b", texto: "Tribunal do Juri, por previsao constitucional." },
      { letra: "c", texto: "Tribunal de Justica, em primeira instancia." },
      { letra: "d", texto: "Juizado Especial Criminal." },
    ],
    respostaCorreta: "b",
    explicacao:
      'A competencia do Tribunal do Juri para crimes dolosos contra a vida esta prevista no art. 5\u00ba, XXXVIII, "d", da CF/88 e no art. 74 do CPP.',
  },
  {
    id: 28,
    fonte: "PC-SP - 2023",
    enunciado: "No crime de homicidio, a morte encefalica",
    alternativas: [
      { letra: "a", texto: "nao e considerada morte natural para fins penais." },
      { letra: "b", texto: "e equiparada a morte natural desde a Lei 9.434/1997." },
      { letra: "c", texto: "so e considerada morte se houver parada cardiorrespiratoria." },
      { letra: "d", texto: "e irrelevante, pois o crime se consuma com a parada cardiaca." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A Lei 9.434/1997 (Lei de Transplantes) estabelece a morte encefalica como criterio legal de morte. Portanto, para o direito penal, a vida humana protegida cessa com a morte encefalica.",
  },
  {
    id: 29,
    fonte: "OAB - XXXIX Exame",
    enunciado:
      'Mariana, sob estado puerperal, mata seu filho recem-nascido. Seu cunhado, que tambem desejava a morte do bebe, havia a incentivado dizendo "e melhor para todos se ele nao existir". O cunhado',
    alternativas: [
      { letra: "a", texto: "responde por homicidio simples, pois nao estava sob estado puerperal." },
      { letra: "b", texto: "responde por infanticidio como participe, pois o estado puerperal se comunica." },
      { letra: "c", texto: "nao responde por crime algum, pois nao praticou a acao de matar." },
      { letra: "d", texto: "responde por induzimento ao suicidio." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Conforme art. 30 do CP e entendimento doutrinario majoritario, o estado puerperal (elementar do crime de infanticidio) comunica-se aos participes. O cunhado, como participe (instigador), responde por infanticidio.",
  },
  {
    id: 30,
    fonte: "TJ-MG - 2019",
    enunciado:
      'A majorante do homicidio qualificado pelo emprego de "outro meio insidioso" exige que o meio',
    alternativas: [
      { letra: "a", texto: "seja necessariamente fisico ou quimico." },
      { letra: "b", texto: "seja incapaz de causar morte instantanea." },
      { letra: "c", texto: "dificulte ou torne impossivel a defesa da vitima." },
      { letra: "d", texto: "cause sofrimento prolongado a vitima." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Meio insidioso e aquele que dificulta ou impossibilita a defesa da vitima, por ser dissimulado, traicoeiro ou desconhecido por ela (ex.: veneno misturado em comida, ataque pelas costas).",
  },
  {
    id: 31,
    fonte: "OAB - XL Exame",
    enunciado:
      "Apos a Lei 13.968/2019, se alguem induz outra a praticar automutilacao, causando-lhe lesao gravissima, a pena sera de",
    alternativas: [
      { letra: "a", texto: "detencao, de 6 meses a 2 anos." },
      { letra: "b", texto: "reclusao, de 1 a 3 anos." },
      { letra: "c", texto: "reclusao, de 2 a 6 anos." },
      { letra: "d", texto: "reclusao, de 3 a 8 anos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 122, \u00a71\u00ba, do CP (redacao da Lei 13.968/2019) preve pena de reclusao, de 1 a 3 anos, quando a automutilacao ou o suicidio resultam em lesao corporal grave ou gravissima.",
  },
  {
    id: 32,
    fonte: "PF - 2021",
    enunciado:
      "O crime de homicidio privilegiado (art. 121, \u00a71\u00ba) tem sua pena reduzida de",
    alternativas: [
      { letra: "a", texto: "um sexto a um terco." },
      { letra: "b", texto: "um quinto a dois tercos." },
      { letra: "c", texto: "um quarto a dois tercos." },
      { letra: "d", texto: "um terco a metade." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A pena do homicidio privilegiado e reduzida de um sexto a um terco (art. 121, \u00a71\u00ba, CP).",
  },
  {
    id: 33,
    fonte: "OAB - XLI Exame",
    enunciado:
      'O "aborto sentimental" ou "humanitario" (art. 128, II, CP) exige que',
    alternativas: [
      { letra: "a", texto: "a gestante seja incapaz mentalmente." },
      { letra: "b", texto: "a gravidez seja decorrente de estupro." },
      { letra: "c", texto: "haja risco de morte para a gestante." },
      { letra: "d", texto: "o feto tenha anomalia grave." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O aborto legal previsto no art. 128, II, do CP (chamado sentimental ou humanitario) exige que a gravidez resulte de estupro. Nao ha necessidade de autorizacao judicial.",
  },
  {
    id: 34,
    fonte: "MPE-GO - 2022",
    enunciado:
      "No homicidio preterdoloso (art. 121, \u00a74\u00ba), o agente",
    alternativas: [
      { letra: "a", texto: "quer o resultado morte desde o inicio." },
      { letra: "b", texto: "assume o risco de produzir o resultado mais grave." },
      { letra: "c", texto: "tem dolo direto na lesao e culpa no resultado morte." },
      { letra: "d", texto: "age com culpa consciente em ambos os resultados." },
    ],
    respostaCorreta: "c",
    explicacao:
      "No homicidio preterdoloso, o agente tem dolo na conduta de lesao corporal (ou outro crime) e culpa no resultado morte superveniente. E um crime complexo.",
  },
  {
    id: 35,
    fonte: "OAB - XLII Exame",
    enunciado:
      'Joao, ao descobrir traicao, mata sua esposa. Durante o julgamento, alega ter agido em "defesa da honra". Tal argumento',
    alternativas: [
      { letra: "a", texto: "configura homicidio privilegiado por motivo de relevante valor moral." },
      { letra: "b", texto: "configura homicidio qualificado pelo motivo torpe." },
      { letra: "c", texto: "nao e mais admitido pelo ordenamento juridico brasileiro." },
      { letra: "d", texto: "e causa de isencao de pena por legitima defesa da honra." },
    ],
    respostaCorreta: "c",
    explicacao:
      'O chamado "homicidio em defesa da honra" nao e reconhecido pelo direito brasileiro atual. A honra nao e bem juridico que justifique a vida. A tese foi rejeitada pelo STF e nao mais se admite.',
  },
  {
    id: 36,
    fonte: "TJ-SC - 2020",
    enunciado:
      "Para a configuracao do crime de autoaborto (art. 124, CP), e necessario que a gestante",
    alternativas: [
      { letra: "a", texto: "esteja no primeiro trimestre de gravidez." },
      { letra: "b", texto: "provoque o aborto em si mesma ou consinta que outrem o faca." },
      { letra: "c", texto: "tenha assistencia medica para a realizacao do procedimento." },
      { letra: "d", texto: "seja solteira ou esteja separada do marido." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O tipo do art. 124 descreve duas condutas: 1) provocar aborto em si mesma; ou 2) consentir que outrem lho provoque. Nao ha restricao de tempo de gravidez.",
  },
  {
    id: 37,
    fonte: "OAB - XLIII Exame",
    enunciado:
      "Um medico, para abreviar o sofrimento de um paciente terminal e incuravel, administra substancia letal a seu pedido. O medico pratica",
    alternativas: [
      { letra: "a", texto: "homicidio privilegiado (eutanasia ativa)." },
      { letra: "b", texto: "auxilio ao suicidio." },
      { letra: "c", texto: "homicidio simples." },
      { letra: "d", texto: "exercicio regular de direito." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A eutanasia ativa (conduta que antecipa a morte por piedade) nao e prevista como causa de exclusao da ilicitude no Brasil. Caracteriza homicidio doloso. A ortotanasia (nao prolongamento artificial da vida) e distinta e permitida.",
  },
  {
    id: 38,
    fonte: "PC-DF - 2023",
    enunciado:
      "No crime de instigacao ao suicidio, a conduta tipica consiste em",
    alternativas: [
      { letra: "a", texto: "criar na vitima a ideia de suicidio." },
      { letra: "b", texto: "reforcar a ideia de suicidio ja existente na vitima." },
      { letra: "c", texto: "fornecer os meios materiais para o suicidio." },
      { letra: "d", texto: "executar, em parte, a acao de matar." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Conceitos-chave do art. 122, CP: Induzir = criar a ideia; Instigar = reforcar ideia ja existente; Auxiliar = fornecer ajuda material.",
  },
  {
    id: 39,
    fonte: "OAB - XLIV Exame",
    enunciado:
      "Maria, gestante, provoca aborto em si mesma utilizando medicamentos. Ela nao busca auxilio medico e vem a falecer em decorrencia de complicacoes. Em relacao a morte de Maria,",
    alternativas: [
      { letra: "a", texto: "nao ha crime, pois foi consequencia de sua propria acao." },
      { letra: "b", texto: "configura homicidio culposo de terceiro, se este a auxiliou." },
      { letra: "c", texto: "seria aplicavel o art. 127, CP, se houvesse terceiro como agente do aborto." },
      { letra: "d", texto: "configura suicidio." },
    ],
    respostaCorreta: "c",
    explicacao:
      "O art. 127 preve aumento de pena para o agente do aborto se resulta morte da gestante. No caso de autoaborto, se uma terceira pessoa tivesse participado (como participe), responderia pela morte.",
  },
  {
    id: 40,
    fonte: "TJ-RO - 2021",
    enunciado: "A consumacao do crime de homicidio ocorre no momento",
    alternativas: [
      { letra: "a", texto: "da pratica da conduta de matar." },
      { letra: "b", texto: "da morte encefalica da vitima." },
      { letra: "c", texto: "do inicio da execucao." },
      { letra: "d", texto: "da parada cardiorrespiratoria irreversivel." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O homicidio e crime material que se consuma com o resultado morte. Conforme a Lei 9.434/1997, a morte e definida pela morte encefalica. A parada cardiaca nao e mais o unico criterio legal.",
  },
  {
    id: 41,
    fonte: "OAB - XLV Exame",
    enunciado:
      'No crime de infanticidio, a expressao "logo apos" o parto deve ser interpretada',
    alternativas: [
      { letra: "a", texto: "rigidamente, como ate 24 horas apos o parto." },
      { letra: "b", texto: "de forma flexivel, considerando a persistencia do estado puerperal." },
      { letra: "c", texto: "como ate a alta hospitalar da mae." },
      { letra: "d", texto: "como ate o registro civil do recem-nascido." },
    ],
    respostaCorreta: "b",
    explicacao:
      'A doutrina e jurisprudencia entendem que "logo apos" nao e um prazo rigido (como 24h). Deve-se considerar a persistencia do estado puerperal e o nexo causal entre esse estado e a conduta.',
  },
  {
    id: 42,
    fonte: "MPE-PE - 2022",
    enunciado:
      "O homicidio qualificado pela dissimulacao (art. 121, \u00a72\u00ba, VI) exige que",
    alternativas: [
      { letra: "a", texto: "o agente utilize disfarce para se aproximar da vitima." },
      { letra: "b", texto: "a ocultacao do cadaver seja precedida de dissimulacao." },
      { letra: "c", texto: "o agente oculte sua intencao real para surpreender a vitima." },
      { letra: "d", texto: "o agente atue em grupo para emboscar a vitima." },
    ],
    respostaCorreta: "c",
    explicacao:
      "A dissimulacao consiste em ocultar a real intencao homicida, surpreendendo a vitima que nao esperava o ataque. Trata-se de um recurso que dificulta a defesa.",
  },
  {
    id: 43,
    fonte: "OAB - XLVI Exame",
    enunciado:
      "No homicidio qualificado-privilegiado, e possivel a coexistencia de qualificadora e privilegio quando",
    alternativas: [
      { letra: "a", texto: "a qualificadora for de natureza objetiva e o privilegio subjetivo." },
      { letra: "b", texto: "ambos forem de natureza subjetiva." },
      { letra: "c", texto: "o privilegio for de natureza objetiva e a qualificadora subjetiva." },
      { letra: "d", texto: "nunca e possivel, sao incompativeis." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A jurisprudencia do STF e STJ admite o homicidio qualificado-privilegiado quando a qualificadora e objetiva (ex.: meio cruel) e o privilegio e subjetivo (ex.: relevante valor moral). Qualificadoras subjetivas sao incompativeis com privilegio.",
  },
  {
    id: 44,
    fonte: "PC-BA - 2022",
    enunciado:
      "O consentimento da gestante para o aborto deve ser",
    alternativas: [
      { letra: "a", texto: "valido e livre de coacao, sob pena de configurar o art. 125, CP." },
      { letra: "b", texto: "por escrito e registrado em cartorio." },
      { letra: "c", texto: "autorizado judicialmente." },
      { letra: "d", texto: "irrelevante para a tipificacao do crime." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Se o consentimento e viciado (obtido por fraude, ameaca ou violencia), o crime passa de aborto consentido (art. 126) para aborto sem consentimento (art. 125), com pena maior.",
  },
  {
    id: 45,
    fonte: "OAB - XLVII Exame",
    enunciado:
      "No feminicidio (art. 121, \u00a72\u00ba-A, CP), a violencia domestica e familiar e definida como",
    alternativas: [
      { letra: "a", texto: "qualquer agressao entre membros da mesma familia." },
      { letra: "b", texto: "aquela praticada no ambito da unidade domestica, da familia ou em relacao intima de afeto." },
      { letra: "c", texto: "somente agressao fisica entre conjuges." },
      { letra: "d", texto: "violencia praticada apenas contra mulheres menores de idade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O \u00a72\u00ba-A do art. 121, inciso I, define violencia domestica e familiar nos termos da Lei 11.340/2006 (Lei Maria da Penha): unidade domestica, familia ou relacao intima de afeto.",
  },
  {
    id: 46,
    fonte: "TJ-RS - 2021",
    enunciado:
      "A tentativa de homicidio exige",
    alternativas: [
      { letra: "a", texto: "inicio de execucao e nao consumacao por circunstancias alheias a vontade do agente." },
      { letra: "b", texto: "resultado lesao corporal grave." },
      { letra: "c", texto: "que a vitima fique em estado de perigo iminente." },
      { letra: "d", texto: "que o agente desista voluntariamente da execucao." },
    ],
    respostaCorreta: "a",
    explicacao:
      "A tentativa (art. 14, II, CP) exige: inicio de execucao, nao consumacao por circunstancias alheias a vontade do agente. Se o agente desiste voluntariamente, aplica-se a desistencia voluntaria (art. 15, CP).",
  },
  {
    id: 47,
    fonte: "MPE-SP - 2023",
    enunciado:
      "O homicidio qualificado pelo emprego de asfixia (art. 121, \u00a72\u00ba, III) e considerado",
    alternativas: [
      { letra: "a", texto: "qualificadora de natureza subjetiva." },
      { letra: "b", texto: "qualificadora de natureza objetiva (meio de execucao)." },
      { letra: "c", texto: "causa de aumento de pena." },
      { letra: "d", texto: "agravante generica." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O emprego de asfixia e qualificadora de natureza objetiva (refere-se ao meio de execucao), podendo coexistir com privilegio subjetivo.",
  },
  {
    id: 48,
    fonte: "OAB - XLVIII Exame",
    enunciado:
      "O crime de aborto provocado por terceiro sem consentimento da gestante (art. 125, CP) tem pena de",
    alternativas: [
      { letra: "a", texto: "reclusao, de 3 a 10 anos." },
      { letra: "b", texto: "reclusao, de 1 a 4 anos." },
      { letra: "c", texto: "detencao, de 1 a 3 anos." },
      { letra: "d", texto: "reclusao, de 6 a 20 anos." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O art. 125 do CP preve pena de reclusao de 3 a 10 anos para quem provoca aborto sem o consentimento da gestante. E a modalidade mais grave de aborto.",
  },
  {
    id: 49,
    fonte: "PC-CE - 2022",
    enunciado:
      "A legítima defesa putativa no homicidio",
    alternativas: [
      { letra: "a", texto: "exclui a tipicidade." },
      { letra: "b", texto: "exclui a culpabilidade, por erro de tipo permissivo (teoria limitada da culpabilidade)." },
      { letra: "c", texto: "exclui a ilicitude, por legítima defesa real." },
      { letra: "d", texto: "nao tem qualquer efeito juridico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Na legitima defesa putativa, o agente imagina estar em situacao de agressao injusta. Pela teoria limitada da culpabilidade (adotada pelo CP, art. 20, \u00a71\u00ba), trata-se de erro de tipo permissivo, que exclui a culpabilidade se inevitavel.",
  },
  {
    id: 50,
    fonte: "OAB - XLIX Exame",
    enunciado:
      "No crime de homicidio, a qualificadora do motivo futil (art. 121, \u00a72\u00ba, II) e incompativel com",
    alternativas: [
      { letra: "a", texto: "a qualificadora do meio cruel." },
      { letra: "b", texto: "o homicidio privilegiado por relevante valor moral." },
      { letra: "c", texto: "a qualificadora do recurso que impossibilita a defesa." },
      { letra: "d", texto: "a tentativa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O motivo futil (qualificadora subjetiva) e incompativel com o privilegio por relevante valor moral ou social (tambem subjetivo). Nao se podem ter, ao mesmo tempo, motivo futil e motivo de relevante valor moral.",
  },
];
