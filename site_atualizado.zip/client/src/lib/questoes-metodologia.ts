import { type Questao } from "./questoes-vida";

export const questoesMetodologia: Questao[] = [
  {
    id: 1,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "As metodologias ativas de aprendizagem colocam o aluno como protagonista do processo educativo. Entre as caracteristicas fundamentais dessas metodologias, destaca-se",
    alternativas: [
      { letra: "a", texto: "a transmissao unidirecional de conteudo pelo professor." },
      { letra: "b", texto: "a participacao ativa do aluno na construcao do conhecimento." },
      { letra: "c", texto: "a avaliacao exclusivamente por provas escritas." },
      { letra: "d", texto: "a memorizacao de codigos e leis como objetivo principal." },
    ],
    respostaCorreta: "b",
    explicacao:
      "As metodologias ativas se fundamentam na participacao efetiva do aluno, conforme Paulo Freire (Pedagogia da Autonomia). O estudante deixa de ser receptor passivo e passa a construir ativamente o conhecimento, diferentemente do modelo bancario de educacao.",
  },
  {
    id: 2,
    fonte: "Concurso Pedagogia - 2022",
    enunciado:
      "Paulo Freire, em sua obra 'Pedagogia da Autonomia', critica o modelo de educacao que denomina 'bancaria'. Essa critica se refere a",
    alternativas: [
      { letra: "a", texto: "educacao que prioriza o dialogo e a participacao do aluno." },
      { letra: "b", texto: "educacao que trata o aluno como depositario passivo de informacoes." },
      { letra: "c", texto: "educacao que estimula a criatividade e o pensamento critico." },
      { letra: "d", texto: "educacao que utiliza tecnologias digitais em sala de aula." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A educacao bancaria, criticada por Paulo Freire, e aquela em que o professor 'deposita' conteudos no aluno, que os recebe passivamente, sem reflexao critica. Freire propoe a educacao problematizadora como alternativa.",
  },
  {
    id: 3,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "A Aprendizagem Baseada em Problemas (ABP) no ensino juridico tem como ponto de partida",
    alternativas: [
      { letra: "a", texto: "a exposicao teorica do professor sobre o tema." },
      { letra: "b", texto: "a leitura previa do codigo e da doutrina pelo aluno." },
      { letra: "c", texto: "a apresentacao de um problema ou caso concreto a ser resolvido." },
      { letra: "d", texto: "a realizacao de prova para medir o nivel da turma." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Na ABP (PBL), o problema e apresentado antes da teoria. O aluno deve identificar as questoes juridicas, pesquisar e propor solucoes. A teoria e buscada para resolver o problema concreto, e nao o contrario.",
  },
  {
    id: 4,
    fonte: "Concurso Docente - UFMG 2020",
    enunciado:
      "No metodo da Sala de Aula Invertida (Flipped Classroom), o tempo presencial em sala de aula e dedicado prioritariamente a",
    alternativas: [
      { letra: "a", texto: "exposicao do conteudo teorico pelo professor." },
      { letra: "b", texto: "copia de resumos e anotacoes da lousa." },
      { letra: "c", texto: "atividades praticas, debates e resolucao de problemas." },
      { letra: "d", texto: "avaliacao somativa com aplicacao de provas." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Na sala de aula invertida, o conteudo teorico e estudado previamente em casa (via textos, videos, podcasts). O tempo presencial e otimizado para atividades praticas, debates e resolucao de problemas, conforme Bergmann e Sams (2012).",
  },
  {
    id: 5,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A gamificacao no ensino juridico consiste em",
    alternativas: [
      { letra: "a", texto: "substituir a aula por jogos eletronicos recreativos." },
      { letra: "b", texto: "aplicar elementos de jogos (pontuacao, desafios, recompensas) ao contexto educacional." },
      { letra: "c", texto: "utilizar apenas avaliacoes ludicas sem fundamentacao pedagogica." },
      { letra: "d", texto: "transformar a faculdade de Direito em um espaco de lazer." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Gamificacao e a aplicacao de mecanicas de jogos (pontos, niveis, rankings, badges) em contextos nao ludicos, como a educacao. Nao se trata de jogar, mas de usar elementos de jogos para aumentar o engajamento e a motivacao, conforme Karl Kapp (2012).",
  },
  {
    id: 6,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "Segundo Vygotsky, a Zona de Desenvolvimento Proximal (ZDP) refere-se a",
    alternativas: [
      { letra: "a", texto: "o que o aluno ja sabe fazer sozinho." },
      { letra: "b", texto: "a distancia entre o que o aluno faz sozinho e o que faz com ajuda de alguem mais experiente." },
      { letra: "c", texto: "o conteudo que o aluno nunca conseguira aprender." },
      { letra: "d", texto: "a avaliacao final do processo de aprendizagem." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A ZDP de Vygotsky e a distancia entre o nivel de desenvolvimento real (o que o aluno faz sozinho) e o nivel de desenvolvimento potencial (o que consegue fazer com mediacao). A aprendizagem colaborativa atua nessa zona.",
  },
  {
    id: 7,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "O juri simulado, como estrategia pedagogica no ensino do Direito Penal, desenvolve principalmente",
    alternativas: [
      { letra: "a", texto: "a capacidade de memorizacao de artigos do Codigo Penal." },
      { letra: "b", texto: "habilidades de argumentacao, oratoria e raciocinio juridico." },
      { letra: "c", texto: "a habilidade de copiar pecas processuais de modelos prontos." },
      { letra: "d", texto: "exclusivamente o conhecimento teorico da parte geral." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O juri simulado e uma metodologia ativa que desenvolve argumentacao, oratoria, pesquisa, trabalho em equipe e raciocinio juridico. Os alunos vivenciam papeis reais (acusacao, defesa, jurados, juiz), aplicando teoria a pratica.",
  },
  {
    id: 8,
    fonte: "Concurso Docente - USP 2021",
    enunciado:
      "A avaliacao formativa, no contexto do ensino juridico, tem como principal objetivo",
    alternativas: [
      { letra: "a", texto: "classificar e rankear os alunos por desempenho." },
      { letra: "b", texto: "acompanhar continuamente a aprendizagem e fornecer feedback para melhoria." },
      { letra: "c", texto: "aplicar uma prova final para decidir aprovacao ou reprovacao." },
      { letra: "d", texto: "substituir completamente a avaliacao somativa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A avaliacao formativa, segundo Perrenoud (1999), acompanha o processo de aprendizagem de forma continua, oferecendo feedback construtivo. Seu objetivo e melhorar a aprendizagem, nao apenas classificar o aluno.",
  },
  {
    id: 9,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A Resolucao CNE/CES n. 5/2018, que estabelece as Diretrizes Curriculares Nacionais do curso de Direito, preve que a formacao do bacharel deve",
    alternativas: [
      { letra: "a", texto: "limitar-se a memorizacao de leis e codigos." },
      { letra: "b", texto: "estimular a capacidade de raciocinio juridico, argumentacao e reflexao critica." },
      { letra: "c", texto: "ser exclusivamente teorica, sem componentes praticos." },
      { letra: "d", texto: "ignorar as novas tecnologias e metodologias de ensino." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 3, XIII, da Resolucao CNE/CES n. 5/2018 preve que o curso de Direito deve estimular a capacidade de raciocinio juridico, argumentacao, persuasao e reflexao critica, alinhado as metodologias ativas de ensino.",
  },
  {
    id: 10,
    fonte: "Concurso Pedagogia - 2022",
    enunciado:
      "Jean Piaget, com sua teoria construtivista, defende que o conhecimento",
    alternativas: [
      { letra: "a", texto: "e transmitido passivamente do professor ao aluno." },
      { letra: "b", texto: "e construido pelo sujeito atraves da interacao com o meio." },
      { letra: "c", texto: "independe de qualquer experiencia pratica." },
      { letra: "d", texto: "deve ser avaliado exclusivamente por provas objetivas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Para Piaget, o conhecimento nao e inato nem simplesmente transmitido: e construido ativamente pelo sujeito na interacao com o ambiente. Essa base teorica sustenta as metodologias ativas, que priorizam a experiencia e a acao do aluno.",
  },
  {
    id: 11,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "No metodo de estudo de caso (case method), originario da Harvard Law School, o aluno deve",
    alternativas: [
      { letra: "a", texto: "memorizar a ementa de todos os julgados sobre o tema." },
      { letra: "b", texto: "analisar criticamente decisoes judiciais, identificando fatos, questoes juridicas e fundamentacao." },
      { letra: "c", texto: "copiar modelos de pecas processuais de manuais." },
      { letra: "d", texto: "assistir passivamente a exposicao do professor sobre o caso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O case method exige analise critica: identificar fatos relevantes, questoes juridicas, argumentos das partes e fundamentacao da decisao. O aluno desenvolve o 'pensar como jurista', habilidade essencial a pratica do Direito.",
  },
  {
    id: 12,
    fonte: "Concurso Docente - UFPR 2023",
    enunciado:
      "A aprendizagem cooperativa, segundo os irmaos Johnson (1989), difere da colaborativa porque",
    alternativas: [
      { letra: "a", texto: "nao envolve trabalho em grupo." },
      { letra: "b", texto: "cada membro do grupo tem uma funcao especifica que contribui para o resultado final." },
      { letra: "c", texto: "dispensa a interacao entre os alunos." },
      { letra: "d", texto: "e sinonimo perfeito de aprendizagem colaborativa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Na aprendizagem cooperativa, cada membro tem papel definido e contribui com uma parte para o todo. Na colaborativa, o grupo trabalha junto na mesma tarefa. Ambas promovem interacao, mas com dinamicas diferentes.",
  },
  {
    id: 13,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A utilizacao de quizzes interativos com correcao automatica e feedback imediato e um exemplo de",
    alternativas: [
      { letra: "a", texto: "avaliacao somativa tradicional." },
      { letra: "b", texto: "gamificacao aliada a avaliacao formativa." },
      { letra: "c", texto: "metodologia passiva de ensino." },
      { letra: "d", texto: "avaliacao classificatoria sem proposito pedagogico." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Quizzes interativos combinam gamificacao (elementos de jogo como pontuacao e feedback) com avaliacao formativa (acompanhamento continuo com retorno construtivo). O aluno aprende com os erros e acompanha seu progresso.",
  },
  {
    id: 14,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "Segundo a Lei de Diretrizes e Bases da Educacao Nacional (LDB - Lei 9.394/96), a educacao superior tem por finalidade",
    alternativas: [
      { letra: "a", texto: "formar exclusivamente tecnicos para o mercado de trabalho." },
      { letra: "b", texto: "estimular a criacao cultural, o desenvolvimento cientifico e o pensamento reflexivo." },
      { letra: "c", texto: "limitar o ensino a reproducao de conhecimentos consolidados." },
      { letra: "d", texto: "avaliar os alunos unicamente por provas padronizadas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O art. 43 da LDB preve que a educacao superior deve estimular a criacao cultural, o desenvolvimento do espirito cientifico e do pensamento reflexivo. Isso fundamenta o uso de metodologias ativas no ensino do Direito.",
  },
  {
    id: 15,
    fonte: "Concurso Docente - UFRJ 2022",
    enunciado:
      "A Taxonomia de Bloom, frequentemente utilizada no planejamento de ensino, organiza os objetivos educacionais em niveis cognitivos. O nivel mais elevado e",
    alternativas: [
      { letra: "a", texto: "lembrar (memorizar informacoes)." },
      { letra: "b", texto: "compreender (explicar conceitos)." },
      { letra: "c", texto: "criar (produzir novo conhecimento ou solucoes originais)." },
      { letra: "d", texto: "aplicar (utilizar conhecimento em situacoes novas)." },
    ],
    respostaCorreta: "c",
    explicacao:
      "Na Taxonomia de Bloom revisada (Anderson & Krathwohl, 2001), os niveis sao: lembrar, compreender, aplicar, analisar, avaliar e criar. O nivel 'criar' e o mais elevado, exigindo que o aluno produza algo original.",
  },
  {
    id: 16,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "O uso de portfolios reflexivos como instrumento de avaliacao no ensino juridico permite",
    alternativas: [
      { letra: "a", texto: "apenas registrar as notas das provas ao longo do semestre." },
      { letra: "b", texto: "que o aluno documente sua trajetoria de aprendizagem, reflexoes e producoes ao longo da disciplina." },
      { letra: "c", texto: "substituir completamente a presenca em sala de aula." },
      { letra: "d", texto: "avaliar apenas a capacidade de memorizacao do aluno." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O portfolio reflexivo e um instrumento de avaliacao formativa que reune producoes do aluno (analises de casos, fichamentos, reflexoes) ao longo da disciplina, permitindo acompanhar e documentar o processo de aprendizagem.",
  },
  {
    id: 17,
    fonte: "Concurso Pedagogia - 2022",
    enunciado:
      "A teoria sociointeracionista de Vygotsky enfatiza que a aprendizagem ocorre principalmente por meio",
    alternativas: [
      { letra: "a", texto: "da maturacao biologica do individuo, independente do meio." },
      { letra: "b", texto: "da interacao social e da mediacao de instrumentos culturais." },
      { letra: "c", texto: "do isolamento do aluno para estudo individual." },
      { letra: "d", texto: "da repeticao mecanica de exercicios." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Vygotsky defende que a aprendizagem e um processo fundamentalmente social, mediado pela linguagem e por instrumentos culturais. A interacao com professores e colegas mais experientes e essencial para o desenvolvimento cognitivo.",
  },
  {
    id: 18,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A interdisciplinaridade no ensino do Direito Penal significa",
    alternativas: [
      { letra: "a", texto: "estudar apenas o Codigo Penal, sem relacao com outras disciplinas." },
      { letra: "b", texto: "integrar o Direito Penal com outras areas do conhecimento, como sociologia, psicologia e criminologia." },
      { letra: "c", texto: "substituir o estudo do Direito Penal por disciplinas de outras areas." },
      { letra: "d", texto: "eliminar as fronteiras entre todas as disciplinas do curso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A interdisciplinaridade nao elimina disciplinas, mas promove o dialogo entre elas. No Direito Penal, integrar conhecimentos de sociologia, criminologia, psicologia e politicas publicas enriquece a compreensao dos fenomenos criminais.",
  },
  {
    id: 19,
    fonte: "Concurso Docente - UFBA 2023",
    enunciado:
      "No contexto das metodologias ativas, o papel do professor se transforma de",
    alternativas: [
      { letra: "a", texto: "facilitador para transmissor de conhecimento." },
      { letra: "b", texto: "transmissor de conhecimento para mediador e facilitador da aprendizagem." },
      { letra: "c", texto: "avaliador para mero espectador do processo." },
      { letra: "d", texto: "autoridade maxima para figura irrelevante no processo." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Nas metodologias ativas, o professor deixa de ser o centro do processo (transmissor) e passa a ser mediador/facilitador, orientando o aluno na construcao do conhecimento. Isso nao diminui sua importancia, mas transforma seu papel.",
  },
  {
    id: 20,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "A competencia denominada 'aprender a aprender', relacionada a metacognicao, refere-se a capacidade de",
    alternativas: [
      { letra: "a", texto: "memorizar a maior quantidade de informacoes possivel." },
      { letra: "b", texto: "o aluno refletir sobre seu proprio processo de aprendizagem e desenvolver estrategias de estudo eficazes." },
      { letra: "c", texto: "depender exclusivamente do professor para aprender." },
      { letra: "d", texto: "evitar qualquer forma de autoavaliacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Metacognicao e a capacidade de pensar sobre o proprio pensamento. 'Aprender a aprender' significa que o aluno conhece suas estrategias de estudo, identifica dificuldades e busca autonomamente formas de supera-las.",
  },
  {
    id: 21,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "A aprendizagem significativa, segundo David Ausubel, ocorre quando",
    alternativas: [
      { letra: "a", texto: "o aluno memoriza conteudos sem relaciona-los a conhecimentos previos." },
      { letra: "b", texto: "novos conhecimentos se conectam a estrutura cognitiva preexistente do aluno de forma nao arbitraria." },
      { letra: "c", texto: "o professor impoe o conteudo sem considerar o que o aluno ja sabe." },
      { letra: "d", texto: "a avaliacao e realizada apenas ao final do curso." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Para Ausubel, a aprendizagem significativa ocorre quando o novo conhecimento se ancora nos conhecimentos previos do aluno (subsuncores). O fator mais importante e o que o aluno ja sabe. Isso se opoe a aprendizagem mecanica (memorizacao sem compreensao).",
  },
  {
    id: 22,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A utilizacao de estudos de caso baseados em jurisprudencia do STF e STJ no ensino do Direito Penal e uma pratica que se alinha a qual metodologia?",
    alternativas: [
      { letra: "a", texto: "Aula expositiva tradicional." },
      { letra: "b", texto: "Case method (metodo de estudo de caso)." },
      { letra: "c", texto: "Ensino programado." },
      { letra: "d", texto: "Instrucao direta." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O case method, desenvolvido na Harvard Law School, utiliza decisoes judiciais reais como material didatico principal. Os alunos analisam criticamente os julgados, extraindo principios juridicos e desenvolvendo raciocinio analitico.",
  },
  {
    id: 23,
    fonte: "Concurso Docente - UNICAMP 2022",
    enunciado:
      "O feedback no processo de ensino-aprendizagem deve ser, preferencialmente",
    alternativas: [
      { letra: "a", texto: "generico, como 'parabens' ou 'precisa melhorar'." },
      { letra: "b", texto: "especifico, construtivo e oportuno, indicando pontos fortes e aspectos a melhorar." },
      { letra: "c", texto: "dado apenas ao final do semestre, na prova final." },
      { letra: "d", texto: "negativo, para que o aluno se esforce mais." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O feedback eficaz deve ser especifico (indicar exatamente o que esta correto ou incorreto), construtivo (sugerir caminhos de melhoria) e oportuno (proximo ao momento da atividade). Feedback generico ou tardio tem pouco efeito na aprendizagem.",
  },
  {
    id: 24,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "A Resolucao CNE/CES n. 5/2018 estabelece que o Projeto Pedagogico do curso de Direito deve contemplar",
    alternativas: [
      { letra: "a", texto: "apenas disciplinas teoricas, sem atividades praticas." },
      { letra: "b", texto: "pratica juridica, atividades complementares e formas de avaliacao diversificadas." },
      { letra: "c", texto: "exclusivamente aulas expositivas e provas escritas." },
      { letra: "d", texto: "conteudo identico ao de todos os cursos de Direito do pais." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A Resolucao CNE/CES n. 5/2018 preve que o PPC deve incluir pratica juridica real e simulada, atividades complementares, trabalho de conclusao de curso e avaliacao diversificada, superando o modelo exclusivamente teorico.",
  },
  {
    id: 25,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "O conceito de 'scaffolding' (andaimento) no processo educacional refere-se a",
    alternativas: [
      { letra: "a", texto: "dar ao aluno todas as respostas prontas desde o inicio." },
      { letra: "b", texto: "oferecer suporte temporario que e gradualmente retirado conforme o aluno ganha autonomia." },
      { letra: "c", texto: "construir edificios para abrigar as escolas." },
      { letra: "d", texto: "impedir que o aluno tente resolver problemas sozinho." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Scaffolding (andaimento), conceito derivado de Vygotsky e desenvolvido por Bruner, e o suporte temporario que o professor oferece ao aluno. Conforme o aluno desenvolve competencia, o suporte e gradualmente reduzido ate que ele consiga atuar autonomamente.",
  },
  {
    id: 26,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A aprendizagem baseada em projetos (Project Based Learning - PjBL) no Direito Penal pode ser exemplificada por",
    alternativas: [
      { letra: "a", texto: "responder questoes de multipla escolha sobre o Codigo Penal." },
      { letra: "b", texto: "os alunos elaborarem um projeto de lei sobre politica criminal, pesquisando legislacao comparada e dados estatisticos." },
      { letra: "c", texto: "o professor ditar o conteudo para os alunos copiarem." },
      { letra: "d", texto: "assistir a filmes sobre crimes sem discussao posterior." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A PjBL envolve a elaboracao de um projeto concreto que requer pesquisa, planejamento e execucao. No Direito Penal, elaborar um projeto de lei exige pesquisa legislativa, analise de dados e fundamentacao doutrinaria.",
  },
  {
    id: 27,
    fonte: "Concurso Docente - UFG 2022",
    enunciado:
      "A 'sala de aula invertida' requer do aluno, como etapa fundamental",
    alternativas: [
      { letra: "a", texto: "que chegue a aula sem nenhuma preparacao previa." },
      { letra: "b", texto: "o estudo previo do material disponibilizado pelo professor antes da aula presencial." },
      { letra: "c", texto: "que grave as aulas para assistir depois em casa." },
      { letra: "d", texto: "que apenas assista aulas expositivas online." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A essencia da sala de aula invertida e o estudo previo: o aluno acessa textos, videos e materiais antes da aula. O tempo presencial e entao usado para aprofundamento, debate e atividades praticas, maximizando a interacao professor-aluno.",
  },
  {
    id: 28,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "Karl Kapp (2012) define gamificacao como o uso de mecanicas, esteticas e pensamento de jogos para",
    alternativas: [
      { letra: "a", texto: "substituir o ensino formal por jogos recreativos." },
      { letra: "b", texto: "engajar pessoas, motivar acoes, promover aprendizagem e resolver problemas." },
      { letra: "c", texto: "avaliar alunos exclusivamente por competicoes." },
      { letra: "d", texto: "eliminar a necessidade de professores no ensino superior." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Kapp define gamificacao como o uso de mecanicas de jogos para engajar, motivar e resolver problemas em contextos nao ludicos. No ensino, isso aumenta a retencao de conteudo e a motivacao intrinseca do aluno.",
  },
  {
    id: 29,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "A avaliacao diagnostica, realizada no inicio de uma disciplina ou unidade de ensino, tem como objetivo",
    alternativas: [
      { letra: "a", texto: "reprovar alunos que nao tenham conhecimento previo." },
      { letra: "b", texto: "identificar os conhecimentos previos dos alunos para adequar o planejamento de ensino." },
      { letra: "c", texto: "substituir a avaliacao final do semestre." },
      { letra: "d", texto: "premiar os alunos com melhor desempenho." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A avaliacao diagnostica, segundo Luckesi, identifica o que o aluno ja sabe antes de iniciar o conteudo. Isso permite ao professor adequar estrategias e conteudos ao nivel real da turma, tornando o ensino mais eficaz.",
  },
  {
    id: 30,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "O moot court (competicao simulada de julgamento) como estrategia de ensino do Direito Penal favorece o desenvolvimento de",
    alternativas: [
      { letra: "a", texto: "apenas a memorizacao de artigos do Codigo Penal." },
      { letra: "b", texto: "competencias de pesquisa, argumentacao escrita e oratoria juridica." },
      { letra: "c", texto: "habilidades manuais e artisticas." },
      { letra: "d", texto: "exclusivamente o conhecimento de direito processual." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O moot court desenvolve competencias essenciais ao jurista: pesquisa juridica aprofundada, elaboracao de memoriais (argumentacao escrita) e sustentacao oral (oratoria). E uma forma de aprendizagem experiencial que simula a pratica forense.",
  },
  {
    id: 31,
    fonte: "Concurso Docente - UFPE 2022",
    enunciado:
      "O conceito de 'aprendizagem experiencial' de David Kolb propoe que o aprendizado efetivo ocorre atraves de",
    alternativas: [
      { letra: "a", texto: "leitura passiva de livros e manuais." },
      { letra: "b", texto: "um ciclo que envolve experiencia concreta, observacao reflexiva, conceitualizacao abstrata e experimentacao ativa." },
      { letra: "c", texto: "memorizacao de conteudos sem reflexao." },
      { letra: "d", texto: "avaliacao exclusivamente por provas escritas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O ciclo de Kolb preve quatro etapas: experiencia concreta (vivenciar), observacao reflexiva (refletir), conceitualizacao abstrata (teorizar) e experimentacao ativa (aplicar). A aprendizagem e um processo ciclico e continuo.",
  },
  {
    id: 32,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "A utilizacao de plataformas digitais de aprendizagem no ensino do Direito e respaldada pela Resolucao CNE/CES n. 5/2018, que reconhece",
    alternativas: [
      { letra: "a", texto: "que tecnologias digitais sao prejudiciais ao ensino juridico." },
      { letra: "b", texto: "a importancia de considerar as novas tecnologias e suas implicacoes juridicas na formacao." },
      { letra: "c", texto: "que o ensino do Direito deve ser exclusivamente presencial." },
      { letra: "d", texto: "que plataformas digitais substituem o professor." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A Resolucao CNE/CES n. 5/2018 reconhece a necessidade de formar bachareis preparados para as novas tecnologias. O art. 5 preve competencias relacionadas ao uso e compreensao das implicacoes juridicas das tecnologias.",
  },
  {
    id: 33,
    fonte: "Concurso Pedagogia - 2022",
    enunciado:
      "Howard Gardner, com a teoria das inteligencias multiplas, propoe que",
    alternativas: [
      { letra: "a", texto: "a inteligencia e unica e pode ser medida por um teste padronizado." },
      { letra: "b", texto: "existem multiplas formas de inteligencia, e o ensino deve contemplar essa diversidade." },
      { letra: "c", texto: "apenas a inteligencia logico-matematica e relevante para o Direito." },
      { letra: "d", texto: "todas as pessoas aprendem exatamente da mesma forma." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Gardner identifica multiplas inteligencias (linguistica, logico-matematica, interpessoal, intrapessoal, etc.). No ensino juridico, e fundamental diversificar estrategias para contemplar diferentes estilos de aprendizagem.",
  },
  {
    id: 34,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A pesquisa juridica como pratica pedagogica no ensino do Direito Penal tem como funcao principal",
    alternativas: [
      { letra: "a", texto: "copiar trechos de livros e colar em trabalhos academicos." },
      { letra: "b", texto: "desenvolver a capacidade de investigacao, analise critica e producao de conhecimento juridico original." },
      { letra: "c", texto: "substituir as aulas presenciais por leitura de artigos." },
      { letra: "d", texto: "apenas preparar o aluno para o TCC." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A pesquisa juridica desenvolve competencias de investigacao, analise e producao cientifica. No Direito Penal, pesquisar jurisprudencia, analisar dados criminais e produzir artigos forma o jurista pesquisador.",
  },
  {
    id: 35,
    fonte: "Concurso Docente - UFSC 2023",
    enunciado:
      "O 'design thinking' aplicado ao ensino do Direito Penal e uma abordagem que prioriza",
    alternativas: [
      { letra: "a", texto: "o pensamento linear e a memorizacao de conteudos." },
      { letra: "b", texto: "a empatia, a definicao do problema, a ideacao, a prototipagem e o teste de solucoes." },
      { letra: "c", texto: "o design grafico de materiais didaticos." },
      { letra: "d", texto: "a estetica visual das apresentacoes dos alunos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O design thinking e um processo centrado no ser humano com 5 etapas: empatizar, definir, idear, prototipar e testar. No Direito Penal, pode ser usado para pensar solucoes de politica criminal centradas nas necessidades das vitimas e da sociedade.",
  },
  {
    id: 36,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "A 'rotacao por estacoes' como estrategia de ensino ativo consiste em",
    alternativas: [
      { letra: "a", texto: "os alunos ficarem sentados em seus lugares durante toda a aula." },
      { letra: "b", texto: "organizar a sala em estacoes com atividades diferentes, pelas quais os grupos rotacionam." },
      { letra: "c", texto: "o professor mudar de sala a cada aula." },
      { letra: "d", texto: "uma modalidade de transporte escolar." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Na rotacao por estacoes, a sala e dividida em estacoes com atividades diferentes (leitura, video, debate, quiz, caso pratico). Os grupos rotacionam entre as estacoes em intervalos definidos, experimentando diversas abordagens do mesmo tema.",
  },
  {
    id: 37,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "A 'curadoria de conteudo' pelo professor no contexto de metodologias ativas refere-se a",
    alternativas: [
      { letra: "a", texto: "criar todo o conteudo didatico do zero, sem usar fontes externas." },
      { letra: "b", texto: "selecionar, organizar e disponibilizar materiais de qualidade para estudo previo dos alunos." },
      { letra: "c", texto: "copiar materiais de outros professores sem adaptacao." },
      { letra: "d", texto: "deixar o aluno buscar sozinho todo o material necessario." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A curadoria de conteudo e uma competencia essencial do professor nas metodologias ativas: selecionar textos, videos, artigos e jurisprudencia de qualidade, organiza-los didaticamente e disponibiliza-los para estudo previo.",
  },
  {
    id: 38,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A 'peer instruction' (instrucao pelos pares), desenvolvida por Eric Mazur, propoe que",
    alternativas: [
      { letra: "a", texto: "os alunos ensinem uns aos outros, explicando conceitos em suas proprias palavras." },
      { letra: "b", texto: "apenas o professor pode explicar os conteudos." },
      { letra: "c", texto: "os alunos trabalhem sempre individualmente, sem interacao." },
      { letra: "d", texto: "a aula seja inteiramente substituida por monitorias." },
    ],
    respostaCorreta: "a",
    explicacao:
      "Na peer instruction, o professor apresenta uma questao conceitual, os alunos respondem individualmente, depois discutem com colegas e respondem novamente. A explicacao entre pares e eficaz porque os alunos usam linguagem acessivel.",
  },
  {
    id: 39,
    fonte: "Concurso Docente - UFRGS 2022",
    enunciado:
      "A 'rubrica de avaliacao' e um instrumento que",
    alternativas: [
      { letra: "a", texto: "substitui qualquer forma de avaliacao no ensino superior." },
      { letra: "b", texto: "define criterios claros e niveis de desempenho esperados, tornando a avaliacao mais transparente e objetiva." },
      { letra: "c", texto: "serve apenas para avaliar trabalhos de artes visuais." },
      { letra: "d", texto: "impede a subjetividade do professor na avaliacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A rubrica define criterios especificos e niveis de desempenho (insatisfatorio, basico, proficiente, avancado) para cada aspecto avaliado. Isso torna a avaliacao mais transparente, justa e orientadora para o aluno.",
  },
  {
    id: 40,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "O ensino hibrido (blended learning) no curso de Direito combina",
    alternativas: [
      { letra: "a", texto: "apenas aulas presenciais tradicionais." },
      { letra: "b", texto: "atividades presenciais e online de forma integrada e complementar." },
      { letra: "c", texto: "apenas atividades a distancia, sem momentos presenciais." },
      { letra: "d", texto: "aulas presenciais e intervalos para recreacao." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O ensino hibrido integra momentos presenciais e online de forma complementar. No Direito, o aluno pode estudar legislacao e doutrina online e usar o tempo presencial para debates, analise de casos e pratica forense.",
  },
  {
    id: 41,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "A 'aprendizagem invertida' se diferencia de uma simples 'aula com video em casa' porque",
    alternativas: [
      { letra: "a", texto: "nao utiliza nenhum recurso tecnologico." },
      { letra: "b", texto: "o tempo presencial e intencionalmente planejado para atividades de ordem superior (analise, avaliacao, criacao)." },
      { letra: "c", texto: "o professor nao tem papel nenhum no processo." },
      { letra: "d", texto: "os alunos assistem videos em sala e fazem exercicios em casa." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A verdadeira sala de aula invertida nao e apenas 'assistir video em casa'. O diferencial e que o tempo presencial e planejado para atividades cognitivas de ordem superior (Taxonomia de Bloom): analisar, avaliar e criar.",
  },
  {
    id: 42,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A 'metodologia socrática', frequentemente utilizada no ensino juridico, baseia-se em",
    alternativas: [
      { letra: "a", texto: "o professor fornecer todas as respostas diretamente." },
      { letra: "b", texto: "um dialogo de perguntas e respostas que conduz o aluno a reflexao e a descoberta do conhecimento." },
      { letra: "c", texto: "a memorizacao de textos filosoficos gregos." },
      { letra: "d", texto: "a avaliacao por meio de debates competitivos." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O metodo socratico (maieutica) utiliza perguntas orientadas para conduzir o aluno a reflexao critica e a descoberta autonoma do conhecimento. E uma das metodologias mais tradicionais e eficazes no ensino do Direito.",
  },
  {
    id: 43,
    fonte: "Concurso Docente - UFMG 2023",
    enunciado:
      "A 'comunidade de aprendizagem' no ensino juridico e um conceito que se refere a",
    alternativas: [
      { letra: "a", texto: "um grupo de alunos que estudam isoladamente." },
      { letra: "b", texto: "um ambiente onde professores, alunos e profissionais do Direito interagem e aprendem mutuamente." },
      { letra: "c", texto: "uma rede social para compartilhar conteudos de lazer." },
      { letra: "d", texto: "uma associacao sindical de professores universitarios." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A comunidade de aprendizagem e um espaco (fisico ou virtual) onde diferentes atores (professores, alunos, profissionais) interagem, compartilham conhecimentos e aprendem coletivamente. Esta plataforma e um exemplo de comunidade de aprendizagem digital.",
  },
  {
    id: 44,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "Segundo Edgar Dale (1969) e o 'cone da experiencia', a aprendizagem e mais efetiva quando o aluno",
    alternativas: [
      { letra: "a", texto: "apenas le o conteudo passivamente." },
      { letra: "b", texto: "participa ativamente, simulando ou realizando experiencias praticas." },
      { letra: "c", texto: "assiste a palestras sem interagir." },
      { letra: "d", texto: "ouve explicacoes do professor sem fazer anotacoes." },
    ],
    respostaCorreta: "b",
    explicacao:
      "O cone de Dale sugere que a retencao de conhecimento e maior quando o aluno participa ativamente (dramatizar, simular, praticar) do que quando apenas le ou ouve. Embora as porcentagens exatas sejam debatidas, o principio ativo e amplamente aceito.",
  },
  {
    id: 45,
    fonte: "Concurso Pedagogia - 2022",
    enunciado:
      "A 'sala de aula dialogada', proposta por Paulo Freire, se fundamenta no principio de que",
    alternativas: [
      { letra: "a", texto: "o professor e o unico detentor do conhecimento verdadeiro." },
      { letra: "b", texto: "o dialogo entre professor e aluno e essencial para uma educacao libertadora e critica." },
      { letra: "c", texto: "o aluno deve aceitar passivamente tudo o que o professor diz." },
      { letra: "d", texto: "a escola nao tem funcao transformadora na sociedade." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Para Freire, o dialogo e a essencia da educacao libertadora. Professor e aluno sao sujeitos ativos do processo educativo, e o conhecimento e construido coletivamente atraves da problematizacao e do debate.",
  },
  {
    id: 46,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A utilizacao de mapas mentais e mapas conceituais como ferramenta de estudo no Direito Penal auxilia",
    alternativas: [
      { letra: "a", texto: "apenas a decoracao de datas e numeros de artigos." },
      { letra: "b", texto: "na organizacao visual do conhecimento, estabelecendo conexoes entre conceitos e facilitando a compreensao sistemica." },
      { letra: "c", texto: "a substituicao da leitura dos textos legais." },
      { letra: "d", texto: "exclusivamente alunos com dificuldades de aprendizagem." },
    ],
    respostaCorreta: "b",
    explicacao:
      "Mapas mentais e conceituais (Novak, 1984) organizam visualmente o conhecimento, estabelecendo hierarquias e conexoes. No Direito Penal, ajudam a visualizar relacoes entre tipos penais, qualificadoras, causas de aumento e excludentes.",
  },
  {
    id: 47,
    fonte: "Concurso Docente - UFBA 2023",
    enunciado:
      "A 'avaliacao por competencias' no ensino do Direito prioriza a verificacao de",
    alternativas: [
      { letra: "a", texto: "apenas a quantidade de conteudo memorizado pelo aluno." },
      { letra: "b", texto: "a capacidade do aluno de mobilizar conhecimentos, habilidades e atitudes para resolver situacoes complexas." },
      { letra: "c", texto: "exclusivamente habilidades praticas, sem conhecimento teorico." },
      { letra: "d", texto: "a assiduidade e pontualidade do aluno." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A avaliacao por competencias verifica se o aluno consegue mobilizar conhecimentos (saber), habilidades (saber fazer) e atitudes (saber ser) para resolver problemas complexos. No Direito, inclui argumentar, analisar e propor solucoes juridicas.",
  },
  {
    id: 48,
    fonte: "ENADE - Direito 2018",
    enunciado:
      "O 'think-pair-share' (pensar-parear-compartilhar) e uma estrategia em que o aluno",
    alternativas: [
      { letra: "a", texto: "pensa sozinho, forma par com colega para discutir e depois compartilha com a turma." },
      { letra: "b", texto: "compartilha a resposta imediatamente sem refletir." },
      { letra: "c", texto: "apenas ouve a resposta do colega sem contribuir." },
      { letra: "d", texto: "trabalha exclusivamente de forma individual o tempo todo." },
    ],
    respostaCorreta: "a",
    explicacao:
      "O think-pair-share tem tres etapas: (1) think - reflexao individual; (2) pair - discussao em dupla; (3) share - compartilhamento com a turma. E uma tecnica simples e eficaz para engajar todos os alunos na discussao.",
  },
  {
    id: 49,
    fonte: "Concurso Pedagogia - 2023",
    enunciado:
      "A 'educacao problematizadora' de Paulo Freire, aplicada ao ensino do Direito Penal, propoe que",
    alternativas: [
      { letra: "a", texto: "os problemas sociais devem ser ignorados no estudo do Direito." },
      { letra: "b", texto: "o ensino parta de problemas reais da sociedade, promovendo reflexao critica e transformacao social." },
      { letra: "c", texto: "apenas problemas matematicos sejam utilizados em sala de aula." },
      { letra: "d", texto: "o professor evite discutir questoes sociais controversas." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A educacao problematizadora parte da realidade concreta dos alunos e da sociedade. No Direito Penal, discutir problemas reais como violencia domestica, encarceramento em massa e reincidencia criminal promove formacao critica e engajada.",
  },
  {
    id: 50,
    fonte: "ENADE - Direito 2021",
    enunciado:
      "A formacao continuada do professor universitario de Direito, no contexto das metodologias ativas, e importante porque",
    alternativas: [
      { letra: "a", texto: "o professor ja sabe tudo o que precisa ao concluir o mestrado ou doutorado." },
      { letra: "b", texto: "as metodologias de ensino evoluem constantemente, exigindo atualizacao pedagogica permanente do docente." },
      { letra: "c", texto: "basta ter conhecimento tecnico-juridico para ser um bom professor." },
      { letra: "d", texto: "a formacao pedagogica e irrelevante para o ensino superior." },
    ],
    respostaCorreta: "b",
    explicacao:
      "A docencia no ensino superior exige nao apenas conhecimento tecnico, mas tambem competencia pedagogica. As metodologias evoluem constantemente, e o professor precisa se atualizar para oferecer um ensino de qualidade e alinhado as demandas contemporaneas.",
  },
];
