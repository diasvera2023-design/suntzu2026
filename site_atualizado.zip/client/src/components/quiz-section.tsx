import { useState, useCallback, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { type Questao } from "@/lib/questoes-vida";
import {
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  ClipboardList,
  Lightbulb,
  Trophy,
  Target,
} from "lucide-react";

function QuestionCard({
  questao,
  selectedAnswer,
  onSelect,
  revealed,
  onReveal,
}: {
  questao: Questao;
  selectedAnswer: string | null;
  onSelect: (letra: string) => void;
  revealed: boolean;
  onReveal: () => void;
}) {
  const isCorrect = selectedAnswer === questao.respostaCorreta;

  return (
    <Card data-testid={`card-questao-${questao.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="text-base font-serif">
            Questao {questao.id}
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            {questao.fonte}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm leading-relaxed" data-testid={`text-enunciado-${questao.id}`}>
          {questao.enunciado}
        </p>

        <div className="space-y-2">
          {questao.alternativas.map((alt) => {
            const isThisCorrect = alt.letra === questao.respostaCorreta;
            const isThisSelected = selectedAnswer === alt.letra;
            let variant: "outline" | "default" | "destructive" | "secondary" = "outline";
            let extraClasses = "justify-start text-left h-auto min-h-9 py-2 whitespace-normal";

            if (revealed) {
              if (isThisCorrect) {
                extraClasses += " border-green-600 bg-green-50 text-green-900 dark:bg-green-950 dark:text-green-100 dark:border-green-500";
              } else if (isThisSelected && !isThisCorrect) {
                extraClasses += " border-red-500 bg-red-50 text-red-900 dark:bg-red-950 dark:text-red-100 dark:border-red-500";
              }
            } else if (isThisSelected) {
              variant = "secondary";
            }

            return (
              <Button
                key={alt.letra}
                variant={variant}
                className={extraClasses}
                onClick={() => {
                  if (!revealed) onSelect(alt.letra);
                }}
                disabled={revealed}
                data-testid={`button-alt-${questao.id}-${alt.letra}`}
              >
                <span className="flex items-start gap-2 w-full">
                  <span className="font-semibold shrink-0 uppercase">{alt.letra})</span>
                  <span>{alt.texto}</span>
                </span>
                {revealed && isThisCorrect && (
                  <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 shrink-0 ml-2" />
                )}
                {revealed && isThisSelected && !isThisCorrect && (
                  <XCircle className="h-4 w-4 text-red-500 dark:text-red-400 shrink-0 ml-2" />
                )}
              </Button>
            );
          })}
        </div>

        {!revealed && selectedAnswer && (
          <Button
            onClick={onReveal}
            className="w-full"
            data-testid={`button-confirmar-${questao.id}`}
          >
            <Target className="h-4 w-4 mr-2" />
            Confirmar Resposta
          </Button>
        )}

        {revealed && (
          <div
            className={`rounded-md p-4 ${
              isCorrect
                ? "bg-green-50 border border-green-200 dark:bg-green-950 dark:border-green-800"
                : "bg-red-50 border border-red-200 dark:bg-red-950 dark:border-red-800"
            }`}
            data-testid={`text-resultado-${questao.id}`}
          >
            <div className="flex items-center gap-2 mb-2">
              {isCorrect ? (
                <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500 dark:text-red-400" />
              )}
              <p className={`text-sm font-semibold ${
                isCorrect
                  ? "text-green-800 dark:text-green-200"
                  : "text-red-800 dark:text-red-200"
              }`}>
                {isCorrect ? "Resposta Correta!" : `Resposta Incorreta - A correta e a alternativa ${questao.respostaCorreta.toUpperCase()}`}
              </p>
            </div>
            <div className="flex items-start gap-2 mt-2">
              <Lightbulb className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
              <p className="text-sm text-muted-foreground leading-relaxed">
                {questao.explicacao}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface QuizState {
  answers: Record<number, string>;
  revealed: Set<number>;
}

function getStorageKey(questoes: Questao[]) {
  if (questoes.length === 0) return "quiz-unknown";
  return `quiz-${questoes[0].id}-${questoes.length}`;
}

function loadState(key: string): QuizState {
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        answers: parsed.answers || {},
        revealed: new Set(parsed.revealed || []),
      };
    }
  } catch {}
  return { answers: {}, revealed: new Set() };
}

function saveState(key: string, state: QuizState) {
  try {
    localStorage.setItem(
      key,
      JSON.stringify({
        answers: state.answers,
        revealed: Array.from(state.revealed),
      })
    );
  } catch {}
}

export default function QuizSection({ questoes }: { questoes: Questao[] }) {
  const ITEMS_PER_PAGE = 5;
  const storageKey = getStorageKey(questoes);
  const [page, setPage] = useState(0);
  const [state, setState] = useState<QuizState>(() => loadState(storageKey));

  useEffect(() => {
    saveState(storageKey, state);
  }, [state, storageKey]);

  const totalPages = Math.ceil(questoes.length / ITEMS_PER_PAGE);
  const pageQuestions = questoes.slice(
    page * ITEMS_PER_PAGE,
    (page + 1) * ITEMS_PER_PAGE
  );

  const answeredCount = Object.keys(state.answers).length;
  const revealedCount = state.revealed.size;
  const correctCount = questoes.filter(
    (q) => state.revealed.has(q.id) && state.answers[q.id] === q.respostaCorreta
  ).length;

  const handleSelect = useCallback((questionId: number, letra: string) => {
    setState((prev) => ({
      ...prev,
      answers: { ...prev.answers, [questionId]: letra },
    }));
  }, []);

  const handleReveal = useCallback((questionId: number) => {
    setState((prev) => ({
      ...prev,
      revealed: new Set(Array.from(prev.revealed).concat(questionId)),
    }));
  }, []);

  const handleReset = useCallback(() => {
    setState({ answers: {}, revealed: new Set() });
    setPage(0);
    try { localStorage.removeItem(storageKey); } catch {}
  }, [storageKey]);

  return (
    <div className="space-y-6" data-testid="section-quiz">
      <div className="flex items-center gap-3 flex-wrap">
        <ClipboardList className="h-6 w-6 text-primary" />
        <h2 className="text-xl font-serif font-bold">
          Questoes
        </h2>
        <Badge variant="secondary" className="text-xs">
          {questoes.length} questoes
        </Badge>
      </div>

      <p className="text-sm text-muted-foreground leading-relaxed">
        Questoes de concursos publicos e exames da OAB.
        Selecione a alternativa e confirme para ver a correcao automatica com a explicacao fundamentada.
      </p>

      {revealedCount > 0 && (
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <Trophy className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">Desempenho</p>
                  <p className="text-xs text-muted-foreground">
                    {correctCount} de {revealedCount} corretas ({revealedCount > 0 ? Math.round((correctCount / revealedCount) * 100) : 0}%)
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="outline" className="text-xs">
                  <CheckCircle2 className="h-3 w-3 mr-1 text-green-600" />
                  {correctCount} acertos
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <XCircle className="h-3 w-3 mr-1 text-red-500" />
                  {revealedCount - correctCount} erros
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {questoes.length - revealedCount} restantes
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleReset}
                  data-testid="button-zerar-desempenho"
                >
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Zerar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {pageQuestions.map((q) => (
          <QuestionCard
            key={q.id}
            questao={q}
            selectedAnswer={state.answers[q.id] || null}
            onSelect={(letra) => handleSelect(q.id, letra)}
            revealed={state.revealed.has(q.id)}
            onReveal={() => handleReveal(q.id)}
          />
        ))}
      </div>

      <Separator />

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <Button
          variant="outline"
          size="sm"
          disabled={page === 0}
          onClick={() => setPage((p) => p - 1)}
          data-testid="button-quiz-prev"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Anterior
        </Button>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            Pagina {page + 1} de {totalPages}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            data-testid="button-quiz-reset"
          >
            <RotateCcw className="h-4 w-4 mr-1" />
            Reiniciar
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= totalPages - 1}
            onClick={() => setPage((p) => p + 1)}
            data-testid="button-quiz-next"
          >
            Proxima
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
}
