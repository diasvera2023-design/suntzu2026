import { useLocation } from "wouter";
import {
  Shield,
  HeartPulse,
  AlertTriangle,
  Scale,
  Lock,
  Wallet,
  FileText,
  Briefcase,
  ShieldAlert,
  Flame,
  Users,
  Building2,
  BookOpen,
  GraduationCap,
  Church,
  Library,
  Scroll,
  Lightbulb,
  BookMarked,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import { penalIII, type Topic } from "@/lib/penal-data";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Shield,
  HeartPulse,
  AlertTriangle,
  Scale,
  Lock,
  Wallet,
  FileText,
  Briefcase,
  ShieldAlert,
  Flame,
  Users,
  Building2,
  BookOpen,
  GraduationCap,
  Church,
};

function TopicMenuItem({ topic, disciplinaId }: { topic: Topic; disciplinaId: string }) {
  const [location, setLocation] = useLocation();
  const IconComponent = iconMap[topic.icon] || Shield;
  const path = `/${disciplinaId}/${topic.id}`;
  const isActive = location === path;

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        isActive={isActive}
        onClick={() => setLocation(path)}
        data-testid={`nav-topic-${topic.id}`}
      >
        <IconComponent className="h-4 w-4" />
        <span>{topic.title}</span>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

export function AppSidebar() {
  const [location, setLocation] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 cursor-pointer"
          data-testid="nav-logo"
        >
          <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold leading-tight">FC Liber</span>
            <span className="text-xs text-muted-foreground leading-tight">Direito Penal</span>
          </div>
        </button>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Direito Penal III</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={location === "/penal-iii"}
                  onClick={() => setLocation("/penal-iii")}
                  data-testid="nav-penal-iii-overview"
                >
                  <BookOpen className="h-4 w-4" />
                  <span>Visao Geral</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              {penalIII.topics.map((topic) => (
                <TopicMenuItem key={topic.id} topic={topic} disciplinaId="penal-iii" />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel>Recursos</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={location === "/bibliografia"}
                  onClick={() => setLocation("/bibliografia")}
                  data-testid="nav-bibliografia"
                >
                  <Library className="h-4 w-4" />
                  <span>Bibliografia Basica</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={location === "/artigo-sandro"}
                  onClick={() => setLocation("/artigo-sandro")}
                  data-testid="nav-artigo-sandro"
                >
                  <Scroll className="h-4 w-4" />
                  <span>Artigo Dr. Sandro Dias</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={location === "/metodologia"}
                  onClick={() => setLocation("/metodologia")}
                  data-testid="nav-metodologia"
                >
                  <Lightbulb className="h-4 w-4" />
                  <span>Metodologia de Ensino</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={location === "/manual-aluno"}
                  onClick={() => setLocation("/manual-aluno")}
                  data-testid="nav-manual-aluno"
                >
                  <BookMarked className="h-4 w-4" />
                  <span>Manual do Aluno</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

      </SidebarContent>
    </Sidebar>
  );
}
