import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Lightbulb,
  Target,
  RotateCcw,
  Gamepad2,
  Monitor,
  ClipboardCheck,
  Users,
  FileSearch,
  ChevronDown,
  ChevronUp,
  BookOpen,
  GraduationCap,
  Sparkles,
} from "lucide-react";
import { metodologiaTopicos, type MetodologiaTopico } from "@/lib/metodologia-data";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Lightbulb,
  Target,
  RotateCcw,
  Gamepad2,
  Monitor,
  ClipboardCheck,
  Users,
  FileSearch,
};

const colorMap: Record<string, { bg: string; border: string; text: string }> = {
  "metodologias-ativas": { bg: "#2563eb15", border: "#2563eb40", text: "#2563eb" },
  "aprendizagem-baseada-problemas": { bg: "#dc262615", border: "#dc262640", text: "#dc2626" },
  "sala-aula-invertida": { bg: "#7c3aed15", border: "#7c3aed40", text: "#7c3aed" },
  "avaliacao-formativa": { bg: "#d9730615", border: "#d9730640", text: "#d97306" },
  "aprendizagem-colaborativa": { bg: "#db277815", border: "#db277840", text: "#db2778" },
  "estudo-caso-juridico": { bg: "#4f46e515", border: "#4f46e540", text: "#4f46e5" },
};

function TopicCard({ topico }: { topico: MetodologiaTopico }) {
  const [expanded, setExpanded] = useState(false);
  const IconComponent = iconMap[topico.icon] || Lightbulb;
  const colors = colorMap[topico.id] || colorMap["metodologias-ativas"];

  return (
    <Card
      className="overflow-visible transition-all duration-300"
      style={{ borderColor: expanded ? colors.border : undefined }}
      data-testid={`card-metodologia-${topico.id}`}
    >
      <button
        className="w-full text-left p-5 flex items-start gap-4 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
        data-testid={`button-expand-${topico.id}`}
      >
        <div
          className="flex items-center justify-center w-11 h-11 rounded-md shrink-0 mt-0.5"
          style={{ backgroundColor: colors.bg, border: `1px solid ${colors.border}`, color: colors.text }}
        >
          <IconComponent className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-semibold leading-tight mb-1">
            {topico.titulo}
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
            {topico.descricao}
          </p>
        </div>
        <div className="shrink-0 mt-1">
          {expanded ? (
            <ChevronUp className="h-5 w-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-5 w-5 text-muted-foreground" />
          )}
        </div>
      </button>

      {expanded && (
        <div className="px-5 pb-5 space-y-5">
          <Separator />

          <div>
            <h4
              className="text-sm font-semibold mb-2 flex items-center gap-2"
              style={{ color: colors.text }}
            >
              <BookOpen className="h-4 w-4" />
              Conteudo
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed text-justify">
              {topico.conteudo}
            </p>
          </div>

          <div>
            <h4
              className="text-sm font-semibold mb-2 flex items-center gap-2"
              style={{ color: colors.text }}
            >
              <Target className="h-4 w-4" />
              Objetivos de Aprendizagem
            </h4>
            <ul className="space-y-1.5">
              {topico.objetivos.map((obj, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <span
                    className="mt-1.5 w-1.5 h-1.5 rounded-full shrink-0"
                    style={{ backgroundColor: colors.text }}
                  />
                  {obj}
                </li>
              ))}
            </ul>
          </div>

          <div
            className="p-4 rounded-md"
            style={{ backgroundColor: colors.bg, border: `1px solid ${colors.border}` }}
          >
            <h4
              className="text-sm font-semibold mb-2 flex items-center gap-2"
              style={{ color: colors.text }}
            >
              <Sparkles className="h-4 w-4" />
              Aplicacao Pratica no Direito Penal
            </h4>
            <p className="text-sm leading-relaxed" style={{ color: colors.text }}>
              {topico.aplicacaoPratica}
            </p>
          </div>

          {topico.fundamentacao && topico.fundamentacao.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-2 text-foreground">
                Fundamentacao Legal
              </h4>
              <ul className="space-y-1.5">
                {topico.fundamentacao.map((f, i) => (
                  <li key={i} className="text-sm text-muted-foreground italic">
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div>
            <h4 className="text-sm font-semibold mb-2 text-foreground">
              Referencias Bibliograficas
            </h4>
            <ul className="space-y-1">
              {topico.autoresReferencia.map((ref, i) => (
                <li key={i} className="text-xs text-muted-foreground">
                  {ref}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </Card>
  );
}

export default function Metodologia() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6">
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
              <GraduationCap className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <h1
            className="text-3xl font-serif font-bold tracking-tight mb-2"
            data-testid="text-metodologia-title"
          >
            Metodologia de Ensino Contemporaneo
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Abordagens pedagogicas modernas aplicadas ao ensino do Direito Penal.
            Fundamentadas em teoricos como Paulo Freire, Piaget, Vygotsky e nas
            Diretrizes Curriculares Nacionais (Resolucao CNE/CES n. 5/2018).
          </p>
        </div>

        <div className="space-y-4 mb-10" data-testid="metodologia-topics-list">
          {metodologiaTopicos.map((topico) => (
            <TopicCard key={topico.id} topico={topico} />
          ))}
        </div>

        <div className="mt-8 p-4 rounded-md bg-muted text-center">
          <p className="text-xs text-muted-foreground">
            Conteudo fundamentado nas Diretrizes Curriculares Nacionais do Curso de Direito
            (Resolucao CNE/CES n. 5/2018), LDB (Lei 9.394/96) e referencias bibliograficas
            indicadas em cada topico.
          </p>
        </div>
      </div>
    </div>
  );
}
