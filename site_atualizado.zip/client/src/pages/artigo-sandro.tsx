import { Card } from "@/components/ui/card";
import { FileText } from "lucide-react";
import arcoFlechaImg from "@assets/image_1770571153005.png";
import artigoPdf from "@assets/admin,+07_Oliveira_norm_port_ing_esp_(3)_1770571047852.pdf";

export default function ArtigoSandro() {
  return (
    <div className="flex-1 overflow-auto">
      <div
        className="min-h-full flex flex-col items-center justify-start py-8 px-4"
        style={{
          background:
            "linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--muted)) 100%)",
        }}
      >
        <div className="max-w-[900px] w-full text-center space-y-8">
          <div>
            <h1
              className="text-4xl sm:text-5xl font-bold mb-5 bg-clip-text text-transparent"
              style={{
                backgroundImage: "linear-gradient(45deg, #2ecc71, #1abc9c)",
              }}
              data-testid="text-artigo-title"
            >
              ARTIGO ACADEMICO
            </h1>
            <p
              className="text-lg text-muted-foreground max-w-[700px] mx-auto leading-relaxed italic"
              data-testid="text-artigo-subtitle"
            >
              "A reinsercao social atraves do trabalho: responsabilidade
              empresarial no resgate da dignidade da pessoa humana"
            </p>
          </div>

          <div className="py-8">
            <a
              href={artigoPdf}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block group"
              data-testid="button-artigo-link"
            >
              <div className="relative mx-auto cursor-pointer" style={{ width: "280px" }}>
                <img
                  src={arcoFlechaImg}
                  alt="Arco e Flecha - Acessar Artigo"
                  className="w-full h-auto transition-transform duration-300 group-hover:scale-105"
                  style={{
                    filter: "drop-shadow(0 0 15px rgba(46, 204, 113, 0.5))",
                    animation: "img-glow 3s ease-in-out infinite alternate",
                  }}
                  data-testid="img-arco-flecha"
                />
                <div
                  className="mt-6 font-bold text-center whitespace-nowrap"
                  style={{
                    fontSize: "1.1rem",
                    color: "#2ecc71",
                    textShadow: "0 2px 10px rgba(46, 204, 113, 0.5)",
                    letterSpacing: "2px",
                  }}
                  data-testid="text-acessar-artigo"
                >
                  ACESSAR ARTIGO COMPLETO
                </div>
              </div>
            </a>
          </div>

          <div className="mt-16">
            <h2
              className="text-2xl sm:text-3xl font-bold"
              style={{ color: "#1abc9c" }}
              data-testid="text-artigo-author"
            >
              ARTIGO DR. SANDRO DIAS
            </h2>
            <p className="text-lg text-muted-foreground mt-1">
              MODELO DE INSPIRACAO
            </p>
          </div>

          <Card className="text-left p-6 relative overflow-visible">
            <div
              className="absolute left-0 top-0 bottom-0 w-1 rounded-l-md"
              style={{ background: "#2ecc71" }}
            />
            <h3
              className="text-lg font-bold mb-3"
              style={{ color: "#2ecc71" }}
              data-testid="text-sobre-pesquisa"
            >
              SOBRE A PESQUISA
            </h3>
            <p className="text-muted-foreground leading-relaxed text-justify">
              Este artigo cientifico aborda a responsabilidade social
              empresarial na reinsercao de egressos do sistema prisional
              atraves do trabalho. O estudo destaca como a oferta de
              oportunidades laborais pode reduzir a reincidencia criminal e
              promover a dignidade humana, analisando politicas publicas e a
              necessidade de legislacao incentivadora.
            </p>
          </Card>

          <div
            className="flex flex-wrap justify-center gap-6"
            data-testid="stats-container"
          >
            <Card className="p-5 min-w-[170px] text-center" style={{ borderColor: "rgba(46, 204, 113, 0.3)" }}>
              <div
                className="text-4xl font-bold mb-1"
                style={{ color: "#2ecc71" }}
                data-testid="stat-ano"
              >
                2014
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">
                Ano de Publicacao
              </div>
            </Card>
            <Card className="p-5 min-w-[170px] text-center" style={{ borderColor: "rgba(46, 204, 113, 0.3)" }}>
              <div
                className="text-4xl font-bold mb-1"
                style={{ color: "#2ecc71" }}
                data-testid="stat-paginas"
              >
                26
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">
                Paginas
              </div>
            </Card>
            <Card className="p-5 min-w-[170px] text-center" style={{ borderColor: "rgba(46, 204, 113, 0.3)" }}>
              <div
                className="text-4xl font-bold mb-1"
                style={{ color: "#2ecc71" }}
                data-testid="stat-idiomas"
              >
                3
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">
                Idiomas
              </div>
            </Card>
          </div>

          <div className="flex items-center justify-center gap-2 text-muted-foreground text-sm pb-8">
            <FileText className="h-4 w-4" />
            <span>
              Revista Juridica Cesumar - Mestrado | Volume 14, Numero 1 | ISSN 1677-6402
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes img-glow {
          from { filter: drop-shadow(0 0 10px rgba(46, 204, 113, 0.4)); }
          to { filter: drop-shadow(0 0 25px rgba(46, 204, 113, 0.7)); }
        }
      `}</style>
    </div>
  );
}
