import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { type Topic, type SubTopic } from "@/lib/penal-data";
import { questoesCrimesContraVida } from "@/lib/questoes-vida";
import { questoesLesaoCorporal } from "@/lib/questoes-lesao-corporal";
import { questoesPericlitacao } from "@/lib/questoes-periclitacao";
import { questoesHonra } from "@/lib/questoes-honra";
import { questoesLiberdadePessoal } from "@/lib/questoes-liberdade-pessoal";
import { questoesPatrimonio } from "@/lib/questoes-patrimonio";
import { questoesPropriedadeImaterial } from "@/lib/questoes-propriedade-imaterial";
import { questoesOrganizacaoTrabalho } from "@/lib/questoes-organizacao-trabalho";
import { questoesSentimentoReligioso } from "@/lib/questoes-sentimento-religioso";
import QuizSection from "@/components/quiz-section";
import {
  Scale,
  BookOpen,
  AlertCircle,
  Gavel,
  FileText,
  ListChecks,
  Info,
  Play,
  GraduationCap,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useState } from "react";

function SubTopicCard({ subtopic }: { subtopic: SubTopic }) {
  return (
    <Card data-testid={`card-subtopic-${subtopic.id}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-serif">{subtopic.title}</CardTitle>
        <div className="flex items-center gap-2 flex-wrap mt-1">
          <Badge variant="default" className="text-xs">
            <Scale className="h-3 w-3 mr-1" />
            Fundamento Legal
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-md bg-muted p-4" data-testid={`text-artigos-${subtopic.id}`}>
          <div className="flex items-start gap-2 mb-2">
            <FileText className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <p className="text-xs font-semibold text-primary uppercase tracking-wider">
              Dispositivo Legal
            </p>
          </div>
          <p className="text-sm font-medium">{subtopic.artigos}</p>
        </div>

        <div className="rounded-md border p-4" data-testid={`text-fundamento-${subtopic.id}`}>
          <div className="flex items-start gap-2 mb-2">
            <Gavel className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <p className="text-xs font-semibold text-primary uppercase tracking-wider">
              Texto Legal / Fundamento
            </p>
          </div>
          <p className="text-sm italic leading-relaxed text-muted-foreground">
            "{subtopic.fundamentoLegal}"
          </p>
        </div>

        <div data-testid={`text-explicacao-${subtopic.id}`}>
          <div className="flex items-start gap-2 mb-2">
            <BookOpen className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <p className="text-xs font-semibold text-primary uppercase tracking-wider">
              Explicacao Doutrinaria
            </p>
          </div>
          <p className="text-sm leading-relaxed">{subtopic.explicacao}</p>
        </div>

        <Accordion type="multiple" className="w-full">
          {subtopic.elementosDoTipo && subtopic.elementosDoTipo.length > 0 && (
            <AccordionItem value="elementos" data-testid={`accordion-elementos-${subtopic.id}`}>
              <AccordionTrigger className="text-sm">
                <div className="flex items-center gap-2">
                  <ListChecks className="h-4 w-4" />
                  <span>Elementos do Tipo Penal</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-2">
                  {subtopic.elementosDoTipo.map((el, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-semibold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-muted-foreground">{el}</span>
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          )}

          {subtopic.jurisprudencia && subtopic.jurisprudencia.length > 0 && (
            <AccordionItem value="jurisprudencia" data-testid={`accordion-jurisprudencia-${subtopic.id}`}>
              <AccordionTrigger className="text-sm">
                <div className="flex items-center gap-2">
                  <Gavel className="h-4 w-4" />
                  <span>Jurisprudencia</span>
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {subtopic.jurisprudencia.length}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-3">
                  {subtopic.jurisprudencia.map((jp, i) => (
                    <li key={i} className="text-sm text-muted-foreground pl-4 border-l-2 border-primary/30 leading-relaxed">
                      {jp}
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          )}

          {subtopic.observacoes && subtopic.observacoes.length > 0 && (
            <AccordionItem value="observacoes" data-testid={`accordion-observacoes-${subtopic.id}`}>
              <AccordionTrigger className="text-sm">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  <span>Observacoes e Detalhes</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-2">
                  {subtopic.observacoes.map((obs, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <AlertCircle className="h-3.5 w-3.5 text-muted-foreground mt-0.5 shrink-0" />
                      <span className="text-muted-foreground leading-relaxed">{obs}</span>
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          )}
        </Accordion>
      </CardContent>
    </Card>
  );
}

const enunciadoTopicos = [
  {
    titulo: "Analise Separada por Envolvido",
    texto: "Sempre analise separadamente cada envolvido, mesmo no mesmo crime.",
  },
  {
    titulo: "Perfil Criminologico — O 'Porque'",
    texto: "Busque motivacao (economica, poder, emocional) e historico do investigado.",
  },
  {
    titulo: "Enquadramento Legal — O 'Como'",
    texto: "Identifique o papel (autor, participe), o dolo (direto/eventual) e todas as qualificadoras especificas.",
  },
  {
    titulo: "Provas do Processo — O 'Comprova'",
    texto: "Separe as provas por investigado e avalie seu valor probatorio.",
  },
  {
    titulo: "Crime Organizado — Piramide",
    texto: "Mandante (topo), organizador (meio), executor (base). Responsabilidade penal e de todos, mas com nuances.",
  },
  {
    titulo: "Qualificadoras Mais Comuns",
    texto: "Motivo torpe (dinheiro, vinganca), meio cruel (sofrimento desnecessario), recurso que impossibilitou defesa (emboscada).",
  },
  {
    titulo: "Dolo Direto vs. Eventual",
    texto: "Quis matar? Ou aceitou o risco de matar como consequencia de outro objetivo?",
  },
  {
    titulo: "Atenuantes e Agravantes",
    texto: "Colaboracao, confissao, reincidencia, lideranca — individuais e podem alterar a pena.",
  },
  {
    titulo: "Conexao dos Tres Pilares",
    texto: "O perfil ajuda a entender a conduta, que se enquadra na lei, comprovada pelas evidencias.",
  },
  {
    titulo: "Objetivo Final",
    texto: "Demonstrar que o direito penal e aplicado a pessoas concretas, nao a um 'caso' generico. Individualizar e justica.",
  },
];

function EnunciadoHomicidio3D() {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="text-center space-y-6 py-4">
      <div>
        <h2
          className="text-2xl font-serif font-bold mb-2"
          style={{ color: "#4a148c" }}
          data-testid="text-enunciado-title"
        >
          Enunciado para Analise Criminal Integrada
        </h2>
        <p className="text-muted-foreground text-sm max-w-lg mx-auto leading-relaxed">
          Atividade pratica: elaborar analise criminal completa e individualizada,
          integrando as dimensoes criminologica, juridico-penal e processual.
        </p>
      </div>

      <div
        className="inline-block group cursor-pointer"
        style={{ perspective: "1200px" }}
        onClick={() => setExpanded(!expanded)}
        data-testid="button-enunciado-3d"
      >
        <div
          className="relative mx-auto transition-transform duration-500 ease-out"
          style={{
            width: "260px",
            height: "180px",
            transformStyle: "preserve-3d",
            transform: expanded
              ? "rotateY(0deg) rotateX(0deg) scale(1.02)"
              : "rotateY(-20deg) rotateX(5deg)",
          }}
          onMouseEnter={(e) => {
            if (!expanded) {
              (e.currentTarget as HTMLElement).style.transform =
                "rotateY(-30deg) rotateX(3deg) translateY(-8px) scale(1.05)";
            }
          }}
          onMouseLeave={(e) => {
            if (!expanded) {
              (e.currentTarget as HTMLElement).style.transform =
                "rotateY(-20deg) rotateX(5deg)";
            }
          }}
        >
          <div
            className="absolute inset-0 rounded-md flex flex-col items-center justify-center gap-3"
            style={{
              background: "linear-gradient(145deg, #1a0533 0%, #2d1654 50%, #4a148c 100%)",
              boxShadow:
                "0 15px 35px rgba(0,0,0,0.4), 0 5px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
              border: "1px solid rgba(255,255,255,0.08)",
              backfaceVisibility: "hidden",
            }}
          >
            <div
              className="flex items-center justify-center rounded-full"
              style={{
                width: "56px",
                height: "56px",
                background: "linear-gradient(135deg, #7b1fa2, #4a148c)",
                boxShadow: "0 4px 15px rgba(123, 31, 162, 0.5)",
              }}
            >
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div className="text-center px-4">
              <div
                className="text-xs font-bold uppercase tracking-[2px]"
                style={{ color: "#ce93d8" }}
              >
                Enunciado
              </div>
              <div
                className="text-[10px] mt-0.5 uppercase tracking-wider flex items-center gap-1 justify-center"
                style={{ color: "rgba(255,255,255,0.5)" }}
              >
                {expanded ? "Clique para recolher" : "Clique para expandir"}
                {expanded ? (
                  <ChevronUp className="h-3 w-3" />
                ) : (
                  <ChevronDown className="h-3 w-3" />
                )}
              </div>
            </div>
          </div>

          <div
            className="absolute top-0 bottom-0 rounded-md"
            style={{
              left: "-20px",
              width: "20px",
              background: "linear-gradient(to right, #0d0520, #1a0533)",
              transform: "rotateY(90deg)",
              transformOrigin: "right center",
              boxShadow: "inset 0 0 10px rgba(0,0,0,0.4)",
            }}
          />

          <div
            className="absolute left-0 right-0 rounded-md"
            style={{
              bottom: "-12px",
              height: "12px",
              background: "linear-gradient(to bottom, #150430, #0d0520)",
              transform: "rotateX(90deg)",
              transformOrigin: "top center",
              boxShadow: "inset 0 0 8px rgba(0,0,0,0.3)",
            }}
          />
        </div>
      </div>

      {expanded && (
        <div className="max-w-2xl mx-auto text-left space-y-4 mt-6" data-testid="enunciado-content">
          <Card className="p-5 relative overflow-visible">
            <div
              className="absolute left-0 top-0 bottom-0 w-1 rounded-l-md"
              style={{ background: "#7b1fa2" }}
            />
            <h3
              className="text-base font-bold mb-3"
              style={{ color: "#7b1fa2" }}
            >
              Objetivo da Atividade
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed text-justify">
              Elaborar uma analise criminal completa e individualizada de cada investigado
              em um caso concreto de homicidio, integrando tres dimensoes fundamentais:
              a criminologica, a juridico-penal e a processual. O trabalho deve demonstrar
              a capacidade de articular teoria e pratica na compreensao do fenomeno criminal,
              respondendo como exemplo. Sempre analise separadamente cada envolvido, mesmo no mesmo crime.
            </p>
          </Card>

          <div className="grid gap-3 sm:grid-cols-2">
            {enunciadoTopicos.map((item, i) => (
              <Card
                key={i}
                className="p-4 relative overflow-visible"
                data-testid={`card-enunciado-topico-${i}`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className="flex items-center justify-center w-7 h-7 rounded-full text-white text-xs font-bold shrink-0"
                    style={{ background: "linear-gradient(135deg, #7b1fa2, #4a148c)" }}
                  >
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-semibold mb-1">{item.titulo}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {item.texto}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface Props {
  topic: Topic;
  disciplinaNome: string;
}

export default function TopicDetail({ topic, disciplinaNome }: Props) {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6">
        <div className="mb-6">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            {disciplinaNome}
          </p>
          <h1 className="text-2xl font-serif font-bold tracking-tight mb-2" data-testid="text-topic-title">
            {topic.title}
          </h1>
          <p className="text-muted-foreground leading-relaxed" data-testid="text-topic-descricao">
            {topic.descricao}
          </p>
        </div>

        <Separator className="my-6" />

        <div className="space-y-6">
          {topic.subtopics.map((subtopic) => (
            <SubTopicCard key={subtopic.id} subtopic={subtopic} />
          ))}
        </div>

        {topic.id === "crimes-contra-vida" && (
          <>
            <Separator className="my-8" />

            <div className="text-center space-y-6 py-4">
              <div>
                <h2
                  className="text-2xl font-serif font-bold mb-2"
                  style={{ color: "#b71c1c" }}
                  data-testid="text-entrevista-homicidio-title"
                >
                  Entrevista Exclusiva
                </h2>
                <p className="text-muted-foreground text-sm max-w-lg mx-auto leading-relaxed">
                  Entrevista com <strong>Dr. Sandro Dias</strong>, Delegado de Policia Civil,
                  abordando aspectos praticos do homicidio qualificado na investigacao criminal.
                </p>
              </div>

              <a
                href="https://youtu.be/kizmSXTrmDU?si=A-MrTVqDNw3TU3bF"
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-block outline-none"
                data-testid="button-entrevista-homicidio-youtube"
                style={{ perspective: "1200px" }}
              >
                <div
                  className="relative mx-auto transition-transform duration-500 ease-out"
                  style={{
                    width: "220px",
                    height: "160px",
                    transformStyle: "preserve-3d",
                    transform: "rotateY(-20deg) rotateX(5deg)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.transform =
                      "rotateY(-30deg) rotateX(3deg) translateY(-8px) scale(1.05)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.transform =
                      "rotateY(-20deg) rotateX(5deg)";
                  }}
                >
                  <div
                    className="absolute inset-0 rounded-md flex flex-col items-center justify-center gap-3"
                    style={{
                      background: "linear-gradient(145deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
                      boxShadow:
                        "0 15px 35px rgba(0,0,0,0.4), 0 5px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      backfaceVisibility: "hidden",
                    }}
                  >
                    <div
                      className="flex items-center justify-center rounded-full transition-transform duration-300 group-hover:scale-110"
                      style={{
                        width: "56px",
                        height: "56px",
                        background: "linear-gradient(135deg, #b71c1c, #880e0e)",
                        boxShadow: "0 4px 15px rgba(183, 28, 28, 0.5)",
                      }}
                    >
                      <Play className="h-6 w-6 text-white ml-0.5" fill="white" />
                    </div>
                    <div className="text-center px-4">
                      <div
                        className="text-xs font-bold uppercase tracking-[2px]"
                        style={{ color: "#b71c1c" }}
                      >
                        YouTube
                      </div>
                      <div
                        className="text-[10px] mt-0.5 uppercase tracking-wider"
                        style={{ color: "rgba(255,255,255,0.5)" }}
                      >
                        Assistir Entrevista
                      </div>
                    </div>
                  </div>

                  <div
                    className="absolute top-0 bottom-0 rounded-md"
                    style={{
                      left: "-20px",
                      width: "20px",
                      background: "linear-gradient(to right, #0d1b2a, #1a1a2e)",
                      transform: "rotateY(90deg)",
                      transformOrigin: "right center",
                      boxShadow: "inset 0 0 10px rgba(0,0,0,0.4)",
                    }}
                  />

                  <div
                    className="absolute left-0 right-0 rounded-md"
                    style={{
                      bottom: "-12px",
                      height: "12px",
                      background: "linear-gradient(to bottom, #0d1b2e, #0a1628)",
                      transform: "rotateX(90deg)",
                      transformOrigin: "top center",
                      boxShadow: "inset 0 0 8px rgba(0,0,0,0.3)",
                    }}
                  />
                </div>
              </a>

              <p
                className="text-xs text-muted-foreground"
                data-testid="text-entrevista-homicidio-autor"
              >
                Dr. Sandro Dias — Delegado de Policia Civil
              </p>
            </div>

            <Separator className="my-8" />

            <EnunciadoHomicidio3D />

            <Separator className="my-8" />
            <QuizSection questoes={questoesCrimesContraVida} />
          </>
        )}

        {topic.id === "lesao-corporal" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesLesaoCorporal} />
          </>
        )}

        {topic.id === "periclitacao-vida-saude" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesPericlitacao} />
          </>
        )}

        {topic.id === "crimes-contra-honra" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesHonra} />
          </>
        )}

        {topic.id === "crimes-liberdade-pessoal" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesLiberdadePessoal} />
          </>
        )}

        {topic.id === "crimes-patrimonio" && (
          <>
            <Separator className="my-8" />

            <div className="text-center space-y-6 py-4">
              <div>
                <h2
                  className="text-2xl font-serif font-bold mb-2"
                  style={{ color: "#e53935" }}
                  data-testid="text-entrevista-title"
                >
                  Entrevista Exclusiva
                </h2>
                <p className="text-muted-foreground text-sm max-w-lg mx-auto leading-relaxed">
                  Entrevista com <strong>Dr. Sandro Dias</strong>, Delegado de Policia Civil,
                  abordando temas relevantes sobre crimes contra o patrimonio na pratica policial.
                </p>
              </div>

              <a
                href="https://youtu.be/WTw4pCsizoo?si=FKgZQ75QcK_g4mDY"
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-block outline-none"
                data-testid="button-entrevista-youtube"
                style={{ perspective: "1200px" }}
              >
                <div
                  className="relative mx-auto transition-transform duration-500 ease-out"
                  style={{
                    width: "220px",
                    height: "160px",
                    transformStyle: "preserve-3d",
                    transform: "rotateY(-20deg) rotateX(5deg)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.transform =
                      "rotateY(-30deg) rotateX(3deg) translateY(-8px) scale(1.05)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.transform =
                      "rotateY(-20deg) rotateX(5deg)";
                  }}
                >
                  <div
                    className="absolute inset-0 rounded-md flex flex-col items-center justify-center gap-3"
                    style={{
                      background: "linear-gradient(145deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
                      boxShadow:
                        "0 15px 35px rgba(0,0,0,0.4), 0 5px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      backfaceVisibility: "hidden",
                    }}
                  >
                    <div
                      className="flex items-center justify-center rounded-full transition-transform duration-300 group-hover:scale-110"
                      style={{
                        width: "56px",
                        height: "56px",
                        background: "linear-gradient(135deg, #e53935, #c62828)",
                        boxShadow: "0 4px 15px rgba(229, 57, 53, 0.5)",
                      }}
                    >
                      <Play className="h-6 w-6 text-white ml-0.5" fill="white" />
                    </div>
                    <div className="text-center px-4">
                      <div
                        className="text-xs font-bold uppercase tracking-[2px]"
                        style={{ color: "#e53935" }}
                      >
                        YouTube
                      </div>
                      <div
                        className="text-[10px] mt-0.5 uppercase tracking-wider"
                        style={{ color: "rgba(255,255,255,0.5)" }}
                      >
                        Assistir Entrevista
                      </div>
                    </div>
                  </div>

                  <div
                    className="absolute top-0 bottom-0 rounded-md"
                    style={{
                      left: "-20px",
                      width: "20px",
                      background: "linear-gradient(to right, #0d1b2a, #1a1a2e)",
                      transform: "rotateY(90deg)",
                      transformOrigin: "right center",
                      boxShadow: "inset 0 0 10px rgba(0,0,0,0.4)",
                    }}
                  />

                  <div
                    className="absolute left-0 right-0 rounded-md"
                    style={{
                      bottom: "-12px",
                      height: "12px",
                      background: "linear-gradient(to bottom, #0d1b2e, #0a1628)",
                      transform: "rotateX(90deg)",
                      transformOrigin: "top center",
                      boxShadow: "inset 0 0 8px rgba(0,0,0,0.3)",
                    }}
                  />
                </div>
              </a>

              <p
                className="text-xs text-muted-foreground"
                data-testid="text-entrevista-autor"
              >
                Dr. Sandro Dias — Delegado de Policia Civil
              </p>
            </div>

            <Separator className="my-8" />
            <QuizSection questoes={questoesPatrimonio} />
          </>
        )}

        {topic.id === "crimes-propriedade-imaterial" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesPropriedadeImaterial} />
          </>
        )}

        {topic.id === "crimes-organizacao-trabalho" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesOrganizacaoTrabalho} />
          </>
        )}

        {topic.id === "crimes-sentimento-religioso" && (
          <>
            <Separator className="my-8" />
            <QuizSection questoes={questoesSentimentoReligioso} />
          </>
        )}

        <div className="mt-8 p-4 rounded-md bg-muted text-center">
          <p className="text-xs text-muted-foreground">
            Todo o conteudo e fundamentado no Codigo Penal (Decreto-Lei n. 2.848/1940),
            Constituicao Federal de 1988, legislacao especial e jurisprudencia dos Tribunais Superiores (STF e STJ).
          </p>
        </div>
      </div>
    </div>
  );
}
