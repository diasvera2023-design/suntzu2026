import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { type Disciplina } from "@/lib/penal-data";
import {
  BookOpen,
  ArrowRight,
  Clock,
  Award,
  Library,
} from "lucide-react";

interface Props {
  disciplina: Disciplina;
}

export default function DisciplinaOverview({ disciplina }: Props) {
  const [, setLocation] = useLocation();

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6">
        <div className="mb-6">
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <h1 className="text-2xl font-serif font-bold tracking-tight" data-testid="text-disciplina-title">
              {disciplina.nome}
            </h1>
            <Badge variant="outline">
              <Clock className="h-3 w-3 mr-1" />
              {disciplina.cargaHoraria}h
            </Badge>
            <Badge variant="outline">
              <Award className="h-3 w-3 mr-1" />
              {disciplina.creditos} creditos
            </Badge>
          </div>
          <p className="text-muted-foreground leading-relaxed" data-testid="text-disciplina-ementa">
            {disciplina.ementa}
          </p>
        </div>

        <div className="grid gap-4 mb-8">
          {disciplina.topics.map((topic) => (
            <Card key={topic.id} className="hover-elevate cursor-pointer" data-testid={`card-topic-${topic.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <CardTitle className="text-lg">{topic.title}</CardTitle>
                  <Badge variant="secondary">
                    {topic.subtopics.length} {topic.subtopics.length === 1 ? "subtopico" : "subtopicos"}
                  </Badge>
                </div>
                <CardDescription className="leading-relaxed">
                  {topic.descricao}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-3">
                  {topic.subtopics.map((sub) => (
                    <Badge key={sub.id} variant="outline" className="text-xs">
                      {sub.title}
                    </Badge>
                  ))}
                </div>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => setLocation(`/${disciplina.id}/${topic.id}`)}
                  data-testid={`button-explore-${topic.id}`}
                >
                  Explorar Topico
                  <ArrowRight className="h-3.5 w-3.5 ml-1" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Separator className="my-6" />

        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Library className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold" data-testid="text-bibliografia-title">
              Bibliografia
            </h2>
          </div>

          <Accordion type="single" collapsible>
            <AccordionItem value="basica" data-testid="accordion-bibliografia-basica">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Bibliografia Basica</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-2">
                  {disciplina.bibliografiaBasica.map((ref, i) => (
                    <li key={i} className="text-sm text-muted-foreground pl-4 border-l-2 border-primary/20">
                      {ref}
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="complementar" data-testid="accordion-bibliografia-complementar">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Bibliografia Complementar</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-2">
                  {disciplina.bibliografiaComplementar.map((ref, i) => (
                    <li key={i} className="text-sm text-muted-foreground pl-4 border-l-2 border-primary/20">
                      {ref}
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </div>
  );
}
