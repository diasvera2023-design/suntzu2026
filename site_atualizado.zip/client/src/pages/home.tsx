import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { penalIII } from "@/lib/penal-data";
import {
  GraduationCap,
  BookOpen,
  Scale,
  ArrowRight,
  Clock,
  Award,
} from "lucide-react";

function DisciplinaCard({ disciplina, path }: { disciplina: typeof penalIII; path: string }) {
  const [, setLocation] = useLocation();

  return (
    <Card data-testid={`card-disciplina-${disciplina.id}`}>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="text-xl">{disciplina.nome}</CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline">
              <Clock className="h-3 w-3 mr-1" />
              {disciplina.cargaHoraria}h
            </Badge>
            <Badge variant="outline">
              <Award className="h-3 w-3 mr-1" />
              {disciplina.creditos} creditos
            </Badge>
          </div>
        </div>
        <CardDescription className="text-sm leading-relaxed mt-2">
          {disciplina.ementa}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-3">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
            Topicos da Ementa
          </p>
          <div className="flex flex-wrap gap-2">
            {disciplina.topics.map((topic) => (
              <Badge
                key={topic.id}
                variant="secondary"
                className="cursor-pointer"
                onClick={() => setLocation(`/${disciplina.id}/${topic.id}`)}
                data-testid={`badge-topic-${topic.id}`}
              >
                {topic.title}
              </Badge>
            ))}
          </div>
          <Separator className="my-1" />
          <Button
            variant="default"
            className="w-full"
            onClick={() => setLocation(path)}
            data-testid={`button-view-${disciplina.id}`}
          >
            Explorar Disciplina
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
              <GraduationCap className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-serif font-bold tracking-tight mb-2" data-testid="text-page-title">
            Direito Penal - Parte Especial
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Plataforma educacional interativa da FC Liber - Porangatu/GO.
            Conteudo fundamentado no Codigo Penal (Decreto-Lei n. 2.848/1940),
            legislacao especial e jurisprudencia dos Tribunais Superiores.
          </p>
        </div>

        <div className="grid gap-6 mb-8">
          <DisciplinaCard disciplina={penalIII} path="/penal-iii" />
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Scale className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-lg">Fundamentacao Legal</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-start gap-3">
                <BookOpen className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Codigo Penal</p>
                  <p className="text-xs text-muted-foreground">
                    Decreto-Lei n. 2.848/1940 - Parte Especial (Arts. 121 a 361)
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <BookOpen className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Constituicao Federal</p>
                  <p className="text-xs text-muted-foreground">
                    CF/88 - Direitos e Garantias Fundamentais (Art. 5)
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <BookOpen className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Jurisprudencia</p>
                  <p className="text-xs text-muted-foreground">
                    Sumulas e decisoes do STF e STJ
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <BookOpen className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Legislacao Especial</p>
                  <p className="text-xs text-muted-foreground">
                    Leis complementares e ordinarias correlatas
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-8 text-xs text-muted-foreground">
          <p>FC Liber - Porangatu/GO</p>
          <p>Rua 06, n. 33, Qd. 34, Lote 3, Centro, Porangatu - GO, 76550-000</p>
        </div>
      </div>
    </div>
  );
}
