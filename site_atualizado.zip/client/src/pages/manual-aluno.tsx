import { Card } from "@/components/ui/card";
import { BookOpen, GraduationCap, Users, Calendar, FileCheck, ArrowRight } from "lucide-react";
import manualPdf from "@assets/Manual-do-Aluno_1770600909804.pdf";

const destaques = [
  {
    icon: Calendar,
    titulo: "Periodo Letivo",
    descricao: "Minimo 200 dias de trabalho academico efetivo, em regime semestral.",
  },
  {
    icon: Users,
    titulo: "Frequencia",
    descricao: "Minimo de 75% de presenca obrigatoria para aprovacao.",
  },
  {
    icon: FileCheck,
    titulo: "Matricula",
    descricao: "Semestral, com prazos definidos no calendario academico.",
  },
];

export default function ManualAluno() {
  return (
    <div className="flex-1 overflow-auto">
      <div
        className="min-h-full flex flex-col items-center justify-start py-8 px-4"
        style={{
          background:
            "linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--muted)) 100%)",
        }}
      >
        <div className="max-w-[900px] w-full text-center space-y-8">
          <div>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
                <GraduationCap className="h-7 w-7 text-primary-foreground" />
              </div>
            </div>
            <h1
              className="text-3xl sm:text-4xl font-serif font-bold tracking-tight mb-2"
              data-testid="text-manual-title"
            >
              Manual do Aluno
            </h1>
            <p
              className="text-muted-foreground max-w-2xl mx-auto leading-relaxed"
              data-testid="text-manual-subtitle"
            >
              FC Liber - Porangatu/GO - Guia completo com
              normas academicas, direitos e deveres do corpo discente.
            </p>
          </div>

          <div className="py-6">
            <a
              href={manualPdf}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block group outline-none"
              data-testid="button-manual-link"
              style={{ perspective: "1200px" }}
            >
              <div
                className="relative mx-auto cursor-pointer transition-transform duration-500 ease-out"
                style={{
                  width: "220px",
                  height: "310px",
                  transformStyle: "preserve-3d",
                  transform: "rotateY(-20deg) rotateX(5deg)",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.transform =
                    "rotateY(-30deg) rotateX(3deg) translateY(-10px) scale(1.03)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.transform =
                    "rotateY(-20deg) rotateX(5deg)";
                }}
              >
                <div
                  className="absolute inset-0 rounded-r-md flex flex-col items-center justify-center p-6 text-center"
                  style={{
                    background: "linear-gradient(145deg, #1e3a5f, #0d253f)",
                    boxShadow:
                      "6px 6px 20px rgba(0,0,0,0.4), inset 0 0 30px rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    backfaceVisibility: "hidden",
                  }}
                >
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
                    style={{
                      background: "linear-gradient(135deg, #c9a84c, #e8d48b)",
                      boxShadow: "0 4px 15px rgba(201, 168, 76, 0.4)",
                    }}
                  >
                    <BookOpen className="h-8 w-8" style={{ color: "#0d253f" }} />
                  </div>

                  <div
                    className="text-xs font-bold uppercase tracking-[3px] mb-2"
                    style={{ color: "#c9a84c" }}
                  >
                    FC LIBER
                  </div>

                  <div
                    className="text-lg font-bold leading-tight mb-1"
                    style={{ color: "#ffffff" }}
                  >
                    MANUAL
                  </div>
                  <div
                    className="text-lg font-bold leading-tight mb-3"
                    style={{ color: "#ffffff" }}
                  >
                    DO ALUNO
                  </div>

                  <div
                    className="w-12 h-[2px] mb-3"
                    style={{ background: "linear-gradient(90deg, transparent, #c9a84c, transparent)" }}
                  />

                  <div
                    className="text-[10px] uppercase tracking-[2px]"
                    style={{ color: "rgba(201,168,76,0.7)" }}
                  >
                    Porangatu - 2024
                  </div>
                </div>

                <div
                  className="absolute top-0 left-0 h-full rounded-l-sm"
                  style={{
                    width: "30px",
                    background: "linear-gradient(90deg, #0a1929, #1e3a5f)",
                    transform: "rotateY(90deg) translateZ(0px) translateX(-15px)",
                    transformOrigin: "left",
                    boxShadow: "inset -2px 0 5px rgba(0,0,0,0.3)",
                  }}
                >
                  <div
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[8px] font-bold tracking-wider"
                    style={{
                      color: "#c9a84c",
                      writingMode: "vertical-rl",
                      textOrientation: "mixed",
                      whiteSpace: "nowrap",
                    }}
                  >
                    MANUAL DO ALUNO
                  </div>
                </div>

                <div
                  className="absolute inset-0 rounded-r-md opacity-0 transition-opacity duration-500 group-hover:opacity-100 pointer-events-none"
                  style={{
                    background: "linear-gradient(135deg, rgba(201,168,76,0.15), transparent 60%)",
                  }}
                />
              </div>

              <div
                className="mt-6 flex items-center justify-center gap-2 font-bold transition-all duration-300 group-hover:gap-3"
                style={{
                  fontSize: "0.95rem",
                  color: "#c9a84c",
                  textShadow: "0 2px 10px rgba(201,168,76,0.3)",
                  letterSpacing: "1.5px",
                }}
                data-testid="text-abrir-manual"
              >
                <span>ABRIR MANUAL COMPLETO</span>
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </a>
          </div>

          <div
            className="flex flex-wrap justify-center gap-4"
            data-testid="destaques-container"
          >
            {destaques.map((item, i) => (
              <Card
                key={i}
                className="p-5 min-w-[220px] max-w-[280px] flex-1 text-left"
                style={{ borderColor: "rgba(201,168,76,0.25)" }}
                data-testid={`card-destaque-${i}`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="flex items-center justify-center w-9 h-9 rounded-md shrink-0"
                    style={{ backgroundColor: "rgba(201,168,76,0.12)", color: "#c9a84c" }}
                  >
                    <item.icon className="h-4 w-4" />
                  </div>
                  <h3 className="text-sm font-semibold">{item.titulo}</h3>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {item.descricao}
                </p>
              </Card>
            ))}
          </div>

          <div className="pb-8">
            <p className="text-xs text-muted-foreground">
              Documento oficial da FC Liber - Porangatu/GO, 2024
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
