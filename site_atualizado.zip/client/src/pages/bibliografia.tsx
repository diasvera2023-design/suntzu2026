import { BookOpen } from "lucide-react";
import mirabetePdf from "@assets/manual-de-direito-penal-parte-especial-arts-121o-a-234-do-cp-3_1770568309008.pdf";
import pedrosoPdf from "@assets/AmoDireito-DirPenal-Especial_degustacao_02_1770568314544.pdf";
import rodriguesPdf from "@assets/manual-de-direito-penal-4a-ed-2024-220278-1_03_1770568320589.pdf";

interface BookData {
  title: string;
  author: string;
  edition: string;
  publisher: string;
  year: string;
  color: string;
  spineColor: string;
  accentColor: string;
  pdfUrl: string;
}

const books: BookData[] = [
  {
    title: "Manual de Direito Penal",
    author: "Julio Fabbrini Mirabete & Renato N. Fabbrini",
    edition: "37a Edicao - Parte Especial",
    publisher: "Editora Foco",
    year: "2024",
    color: "#1a365d",
    spineColor: "#0f2440",
    accentColor: "#c9a84c",
    pdfUrl: mirabetePdf,
  },
  {
    title: "Direito Penal - Parte Especial",
    author: "Fernando Gentil Gizzi de Almeida Pedroso",
    edition: "Colecao Amo Direito",
    publisher: "Editora Amo Direito",
    year: "2022",
    color: "#7b1fa2",
    spineColor: "#4a0072",
    accentColor: "#e1bee7",
    pdfUrl: pedrosoPdf,
  },
  {
    title: "Manual de Direito Penal",
    author: "Cristiano Rodrigues",
    edition: "4a Edicao",
    publisher: "Editora Foco",
    year: "2024",
    color: "#b71c1c",
    spineColor: "#7f0000",
    accentColor: "#ffcdd2",
    pdfUrl: rodriguesPdf,
  },
];

function Book3D({ book, index }: { book: BookData; index: number }) {
  return (
    <a
      href={book.pdfUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="group block outline-none"
      data-testid={`button-book-${index}`}
      style={{ perspective: "1200px" }}
    >
      <div
        className="relative mx-auto transition-transform duration-500 ease-out"
        style={{
          width: "200px",
          height: "280px",
          transformStyle: "preserve-3d",
          transform: "rotateY(-25deg) rotateX(5deg)",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLElement).style.transform =
            "rotateY(-35deg) rotateX(3deg) translateY(-8px) scale(1.02)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLElement).style.transform =
            "rotateY(-25deg) rotateX(5deg)";
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "2px 8px 8px 2px",
            background: `linear-gradient(135deg, ${book.color} 0%, ${book.spineColor} 100%)`,
            boxShadow: `
              8px 8px 20px rgba(0,0,0,0.35),
              2px 2px 8px rgba(0,0,0,0.2),
              inset -2px 0 4px rgba(255,255,255,0.1)
            `,
            transformStyle: "preserve-3d",
            backfaceVisibility: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "20px",
              left: "16px",
              right: "16px",
              bottom: "20px",
              border: `1px solid ${book.accentColor}40`,
              borderRadius: "2px",
            }}
          />

          <div
            style={{
              position: "absolute",
              top: "10px",
              left: "12px",
              right: "12px",
              height: "2px",
              background: `linear-gradient(90deg, transparent, ${book.accentColor}80, transparent)`,
            }}
          />
          <div
            style={{
              position: "absolute",
              bottom: "10px",
              left: "12px",
              right: "12px",
              height: "2px",
              background: `linear-gradient(90deg, transparent, ${book.accentColor}80, transparent)`,
            }}
          />

          <div
            style={{
              position: "absolute",
              top: "36px",
              left: "24px",
              right: "24px",
              display: "flex",
              flexDirection: "column",
              gap: "8px",
            }}
          >
            <div
              style={{
                width: "32px",
                height: "32px",
                borderRadius: "50%",
                background: `${book.accentColor}30`,
                border: `1px solid ${book.accentColor}60`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <BookOpen style={{ width: "16px", height: "16px", color: book.accentColor }} />
            </div>

            <h3
              style={{
                color: "#ffffff",
                fontSize: "14px",
                fontWeight: 700,
                lineHeight: "1.3",
                fontFamily: "var(--font-serif)",
                textShadow: "0 1px 2px rgba(0,0,0,0.3)",
                marginTop: "4px",
              }}
            >
              {book.title}
            </h3>

            <div
              style={{
                width: "40px",
                height: "2px",
                background: book.accentColor,
                borderRadius: "1px",
              }}
            />

            <p
              style={{
                color: `${book.accentColor}cc`,
                fontSize: "10px",
                fontWeight: 500,
                lineHeight: "1.4",
                letterSpacing: "0.02em",
              }}
            >
              {book.edition}
            </p>
          </div>

          <div
            style={{
              position: "absolute",
              bottom: "28px",
              left: "24px",
              right: "24px",
            }}
          >
            <p
              style={{
                color: "#ffffffcc",
                fontSize: "9px",
                fontWeight: 600,
                lineHeight: "1.4",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
              }}
            >
              {book.author}
            </p>
            <div
              style={{
                marginTop: "6px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span
                style={{
                  color: `${book.accentColor}90`,
                  fontSize: "8px",
                  fontWeight: 500,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}
              >
                {book.publisher}
              </span>
              <span
                style={{
                  color: `${book.accentColor}90`,
                  fontSize: "8px",
                  fontWeight: 500,
                }}
              >
                {book.year}
              </span>
            </div>
          </div>
        </div>

        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "36px",
            height: "100%",
            background: `linear-gradient(90deg, ${book.spineColor} 0%, ${book.color} 60%, ${book.spineColor} 100%)`,
            transform: "rotateY(-90deg) translateX(-18px)",
            transformOrigin: "left center",
            borderRadius: "2px 0 0 2px",
            boxShadow: "inset 0 0 8px rgba(0,0,0,0.4)",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%) rotate(-90deg)",
              whiteSpace: "nowrap",
              color: `${book.accentColor}cc`,
              fontSize: "7px",
              fontWeight: 700,
              letterSpacing: "0.15em",
              textTransform: "uppercase",
              textShadow: "0 1px 2px rgba(0,0,0,0.5)",
            }}
          >
            {book.title.length > 20 ? book.title.substring(0, 20) + "..." : book.title}
          </div>

          <div
            style={{
              position: "absolute",
              top: "8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "16px",
              height: "2px",
              background: `${book.accentColor}60`,
              borderRadius: "1px",
            }}
          />
          <div
            style={{
              position: "absolute",
              bottom: "8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "16px",
              height: "2px",
              background: `${book.accentColor}60`,
              borderRadius: "1px",
            }}
          />
        </div>

        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "36px",
            background: `linear-gradient(180deg, ${book.color}40, ${book.spineColor}20)`,
            transform: "rotateX(90deg) translateY(-18px)",
            transformOrigin: "top center",
          }}
        />

        <div
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            width: "100%",
            height: "36px",
            background: `linear-gradient(0deg, ${book.color}60, ${book.spineColor}30)`,
            transform: "rotateX(-90deg) translateY(18px)",
            transformOrigin: "bottom center",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "2px",
              left: "4px",
              right: "4px",
              bottom: "2px",
              background: "repeating-linear-gradient(90deg, #f5f0e6 0px, #f5f0e6 1px, #e8dcc8 1px, #e8dcc8 2px)",
              borderRadius: "1px",
              opacity: 0.6,
            }}
          />
        </div>

        <div
          className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{
            position: "absolute",
            bottom: "-32px",
            left: "50%",
            transform: "translateX(-50%)",
            whiteSpace: "nowrap",
            color: "hsl(var(--primary))",
            fontSize: "11px",
            fontWeight: 600,
            letterSpacing: "0.05em",
          }}
        >
          Abrir PDF
        </div>
      </div>
    </a>
  );
}

export default function Bibliografia() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-5xl mx-auto px-4 py-8 sm:px-6">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
              <BookOpen className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <h1
            className="text-3xl font-serif font-bold tracking-tight mb-2"
            data-testid="text-bibliografia-title"
          >
            Bibliografia Basica
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Obras de referencia utilizadas na disciplina Direito Penal III.
            Clique em cada livro para acessar o material disponivel.
          </p>
        </div>

        <div
          className="grid gap-16 sm:gap-12 justify-items-center pb-12"
          style={{
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          }}
        >
          {books.map((book, i) => (
            <Book3D key={i} book={book} index={i} />
          ))}
        </div>

        <div className="mt-8 p-4 rounded-md bg-muted text-center">
          <p className="text-xs text-muted-foreground">
            Os materiais disponiveis sao amostras gratuitas fornecidas pelas editoras para fins academicos.
            As obras completas podem ser adquiridas nos sites das respectivas editoras.
          </p>
        </div>
      </div>
    </div>
  );
}
